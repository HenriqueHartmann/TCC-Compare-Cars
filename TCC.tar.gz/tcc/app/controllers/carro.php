<?php
/**
 * Created by PhpStorm.
 * User: aluno
 * Date: 09/04/18
 * Time: 15:53
 */
    if (isset($_GET['acao']) and $_GET['acao'] == 'admin')
    {
        echo "deu certo";
        include_once "../views/template/cabecalho.php";
        include_once "../views/tabela/tabela.php";
        include_once "../views/template/rodape.php";
    }
    else
    {
        echo "deu errado";
    }
?>


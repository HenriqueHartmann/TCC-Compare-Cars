<?php
/**
 * Created by PhpStorm.
 * User: aluno
 * Date: 09/04/18
 * Time: 16:24
 */

    class Comentario
    {
        private $id_comentario;
        private $data_comentario;
        private $texto_comentario;
        private $id_carro;
        private $usuario_id_user;

        public function __construct($id_comentario = null, $data_comentario = null, $texto_comentario = null, $id_carro = null, $usuario_id_user = null)
        {
            $this->id_comentario = $id_comentario;
            $this->data_comentario = $data_comentario;
            $this->texto_comentario = $texto_comentario;
            $this->id_carro = $id_carro;
            $this->usuario_id_user = $usuario_id_user;
        }

        public function getIdComentario()
        {
            return $this->id_comentario;
        }

        public function setIdComentario($id_comentario)
        {
            $this->id_comentario = $id_comentario;
        }

        public function getDataComentario()
        {
            return $this->data_comentario;
        }

        public function setDataComentario($data_comentario)
        {
            $this->data_comentario = $data_comentario;
        }

        public function getTextoComentario()
        {
            return $this->texto_comentario;
        }

        public function setTextoComentario($texto_comentario)
        {
            $this->texto_comentario = $texto_comentario;
        }

        public function getIdCarro()
        {
            return $this->id_carro;
        }

        public function setIdCarro($id_carro)
        {
            $this->id_carro = $id_carro;
        }

        public function getUsuarioIdUser()
        {
            return $this->usuario_id_user;
        }

        public function setUsuarioIdUser($usuario_id_user)
        {
            $this->usuario_id_user = $usuario_id_user;
        }


    }
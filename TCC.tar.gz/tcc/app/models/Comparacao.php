<?php
/**
 * Created by PhpStorm.
 * User: aluno
 * Date: 09/04/18
 * Time: 16:25
 */

    class Comparacao
    {
        private $idcomparacao;
        private $idcarro;

        public function __construct($idcomparacao = null, $idcarro = null)
        {
            $this->idcomparacao = $idcomparacao;
            $this->idcarro = $idcarro;
        }

        public function getIdcomparacao()
        {
            return $this->idcomparacao;
        }

        public function setIdcomparacao($idcomparacao)
        {
            $this->idcomparacao = $idcomparacao;
        }

        public function getIdcarro()
        {
            return $this->idcarro;
        }

        public function setIdcarro($idcarro)
        {
            $this->idcarro = $idcarro;
        }


    }
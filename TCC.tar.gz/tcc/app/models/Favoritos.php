<?php
/**
 * Created by PhpStorm.
 * User: aluno
 * Date: 09/04/18
 * Time: 16:25
 */

    class Favoritos
    {
        private $idfavoritos;
        private $datafavoritos;
        private $idcomparacao;
        private $usuario_id_user;

        public function __construct($idfavoritos = null, $datafavoritos = null, $idcomparacao = null, $usuario_id_user = null)
        {
            $this->idfavoritos = $idfavoritos;
            $this->datafavoritos = $datafavoritos;
            $this->idcomparacao = $idcomparacao;
            $this->usuario_id_user = $usuario_id_user;
        }

        public function getIdfavoritos()
        {
            return $this->idfavoritos;
        }

        public function setIdfavoritos($idfavoritos)
        {
            $this->idfavoritos = $idfavoritos;
        }

        public function getDatafavoritos()
        {
            return $this->datafavoritos;
        }

        public function setDatafavoritos($datafavoritos)
        {
            $this->datafavoritos = $datafavoritos;
        }

        public function getIdcomparacao()
        {
            return $this->idcomparacao;
        }

        public function setIdcomparacao($idcomparacao)
        {
            $this->idcomparacao = $idcomparacao;
        }

        public function getUsuarioIdUser()
        {
            return $this->usuario_id_user;
        }

        public function setUsuarioIdUser($usuario_id_user)
        {
            $this->usuario_id_user = $usuario_id_user;
        }


    }
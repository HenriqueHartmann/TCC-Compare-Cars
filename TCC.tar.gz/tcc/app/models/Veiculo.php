<?php
/**
 * Created by PhpStorm.
 * User: aluno
 * Date: 09/04/18
 * Time: 16:26
 */

class Veiculo
{
    private $idcarro;
    private $carro;
    private $potencia;
    private $portas;
    private $preco;
    private $altura;
    private $comprimento;
    private $largura;
    private $cambio;
    private $velocidade;
    private $tanque_combustivel;
    private $tip_combustivel;
    private $porta_malas;
    private $tip_direcao;
    private $consumo_urb;
    private $consumo_rod;
    private $marcha;
    private $tip_tracao;
    private $porte;
    private $ocupantes;
    private $tip_freio;
    private $tip_veiculo;
    private $idusuario_id_user;
    private $versao_id_versao;

    public function __construct($idcarro = null, $carro = null, $potencia = null, $portas = null, $preco = null, $altura = null, $comprimento = null, $largura = null, $cambio = null,
                                $velocidade = null, $tanque_combustivel = null, $tip_combustivel = null, $porta_malas = null, $tip_direcao = null, $consumo_urb = null, $consumo_rod = null,
                                $marcha =null, $tip_tracao = null, $porte = null, $ocupantes = null, $tip_freio = null, $tip_veiculo = null, $idusuario_id_user = null, $versao_id_versao = null)
    {
        $this->idcarro = $idcarro;
        $this->carro = $carro;
        $this->potencia = $potencia;
        $this->portas = $portas;
        $this->preco = $preco;
        $this->altura = $altura;
        $this->comprimento = $comprimento;
        $this->largura = $largura;
        $this->cambio= $cambio;
        $this->velocidade = $velocidade;
        $this->tanque_combustivel = $tanque_combustivel;
        $this->tip_combustivel = $tip_combustivel;
        $this->porta_malas = $porta_malas;
        $this->tip_direcao = $tip_direcao;
        $this->consumo_urb = $consumo_urb;
        $this->consumo_rod = $consumo_rod;
        $this->marcha = $marcha;
        $this->tip_tracao = $tip_tracao;
        $this->porte = $porte;
        $this->ocupantes = $ocupantes;
        $this->tip_freio = $tip_freio;
        $this->tip_veiculo = $tip_veiculo;
        $this->idusuario_id_user = $idusuario_id_user;
        $this->versao_id_versao = $versao_id_versao;
    }

    public function getIdcarro()
    {
        return $this->idcarro;
    }

    public function setIdcarro($idcarro)
    {
        $this->idcarro = $idcarro;
    }

    public function getCarro()
    {
        return $this->carro;
    }

    public function setCarro($carro)
    {
        $this->carro = $carro;
    }

    public function getPotencia()
    {
        return $this->potencia;
    }

    public function setPotencia($potencia)
    {
        $this->potencia = $potencia;
    }

    public function getPortas()
    {
        return $this->portas;
    }

    public function setPortas($portas)
    {
        $this->portas = $portas;
    }

    public function getPreco()
    {
        return $this->preco;
    }

    public function setPreco($preco)
    {
        $this->preco = $preco;
    }

    public function getAltura()
    {
        return $this->altura;
    }

    public function setAltura($altura)
    {
        $this->altura = $altura;
    }

    public function getComprimento()
    {
        return $this->comprimento;
    }

    public function setComprimento($comprimento)
    {
        $this->comprimento = $comprimento;
    }

    public function getLargura()
    {
        return $this->largura;
    }

    public function setLargura($largura)
    {
        $this->largura = $largura;
    }

    public function getCambio()
    {
        return $this->cambio;
    }

    public function setCambio($cambio)
    {
        $this->cambio = $cambio;
    }

    public function getVelocidade()
    {
        return $this->velocidade;
    }

    public function setVelocidade($velocidade)
    {
        $this->velocidade = $velocidade;
    }

    public function getTanqueCombustivel()
    {
        return $this->tanque_combustivel;
    }

    public function setTanqueCombustivel($tanque_combustivel)
    {
        $this->tanque_combustivel = $tanque_combustivel;
    }

    public function getTipCombustivel()
    {
        return $this->tip_combustivel;
    }

    public function setTipCombustivel($tip_combustivel)
    {
        $this->tip_combustivel = $tip_combustivel;
    }

    public function getPortaMalas()
    {
        return $this->porta_malas;
    }

    public function setPortaMalas($porta_malas)
    {
        $this->porta_malas = $porta_malas;
    }

    public function getTipDirecao()
    {
        return $this->tip_direcao;
    }

    public function setTipDirecao($tip_direcao)
    {
        $this->tip_direcao = $tip_direcao;
    }

    public function getConsumoUrb()
    {
        return $this->consumo_urb;
    }

    public function setConsumoUrb($consumo_urb)
    {
        $this->consumo_urb = $consumo_urb;
    }

    public function getConsumoRod()
    {
        return $this->consumo_rod;
    }

    public function setConsumoRod($consumo_rod)
    {
        $this->consumo_rod = $consumo_rod;
    }

    public function getMarcha()
    {
        return $this->marcha;
    }

    public function setMarcha($marcha)
    {
        $this->marcha = $marcha;
    }

    public function getTipTracao()
    {
        return $this->tip_tracao;
    }

    public function setTipTracao($tip_tracao)
    {
        $this->tip_tracao = $tip_tracao;
    }

    public function getPorte()
    {
        return $this->porte;
    }

    public function setPorte($porte)
    {
        $this->porte = $porte;
    }

    public function getOcupantes()
    {
        return $this->ocupantes;
    }

    public function setOcupantes($ocupantes)
    {
        $this->ocupantes = $ocupantes;
    }

    public function getTipFreio()
    {
        return $this->tip_freio;
    }

    public function setTipFreio($tip_freio)
    {
        $this->tip_freio = $tip_freio;
    }

    public function getTipVeiculo()
    {
        return $this->tip_veiculo;
    }

    public function setTipVeiculo($tip_veiculo)
    {
        $this->tip_veiculo = $tip_veiculo;
    }

    public function getIdusuarioIdUser()
    {
        return $this->idusuario_id_user;
    }

    public function setIdusuarioIdUser($idusuario_id_user)
    {
        $this->idusuario_id_user = $idusuario_id_user;
    }

    public function getVersaoIdVersao()
    {
        return $this->versao_id_versao;
    }

    public function setVersaoIdVersao($versao_id_versao)
    {
        $this->versao_id_versao = $versao_id_versao;
    }


}
<?php
/**
 * Created by PhpStorm.
 * User: aluno
 * Date: 09/04/18
 * Time: 16:24
 */

    class Ano
    {
        private $id_ano;
        private $ano;
        private $modelo_id_modelo;

    public function __construct($id_ano = null, $ano = null, $modelo_id_modelo = null)
    {
        $this->id_ano = $id_ano;
        $this->ano = $ano;
        $this->modelo_id_modelo = $modelo_id_modelo;
    }

    public function getId()
    {
        return $this->id_ano;
    }

    public function setId($id_ano)
    {
        $this->id_ano = $id_ano;
    }

    public function getAno()
    {
        return $this->ano;
    }

    public function setAno($ano)
    {
        $this->ano = $ano;
    }

    public function getModeloIdModelo()
    {
        return $this->modelo_id_modelo;
    }

    public function setModeloIdModelo($modelo_id_modelo)
    {
        $this->modelo_id_modelo = $modelo_id_modelo;
    }

}
?>
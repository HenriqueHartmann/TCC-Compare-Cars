<br>
<br>
<br>
<div class="row">
    <div class="span12" style="text-align:center; margin: 0 auto;">
<form id="form" class="form-horizontal form-control" style="width: 400px; margin: 0 auto;" method="post" action="app/controllers/controladorAcao.php?acao=login">
	<fieldset>
	<legend>LOGIN</legend>

<!-- Text input-->
	<div class="control-group">
  		<label class="col-xs-12 col-md-4 col-lg-4 control-label" for="login">Nome</label>
  		<div class="control">
  		<input id="login" maxlength="100" name="nome" type="text" placeholder="Digite o seu nome" class="form-control input-large">
  		</div>
	</div>

<!-- Password input-->
	<div class="control-group">
		<label class="col-xs-12 col-md-4 col-lg-4 control-label" for="passwordinput">Senha</label>
  		<div class="control">
    	<input id="passwordinput" maxlength="100" name="senha" type="password" placeholder="Digite sua senha" class="form-control input-large">
        <?php
            if (@$_GET['erro'] == 1){?>
            <div class="error-text" style="color: red">Nome ou Senha incorreto. Por Favor Tente novamente</div>
         <?php } ?>
  		</div>
	</div>
<br>
<!-- Button -->
	<div class="control-group">
  		<div class="control">
    	<input type="submit" name="logar" id="singlebutton" class="btn btn-success">
  		</div>
	</div>

	</fieldset>
</form>
</div>
</div>

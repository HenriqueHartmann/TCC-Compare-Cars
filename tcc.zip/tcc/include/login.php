<br>
<br>
<br>
<div class="ui middle aligned center aligned grid">
    <div class="column">
        <h2 class="ui teal image header">
            <img src="node_modules/semantic-ui/logo.png" class="image">
            <div class="content">
                Log-in na sua conta
            </div>
        </h2>
<form class="ui large form" style="width: 400px; margin: 0 auto;" method="post" action="app/controllers/controladorAcao.php?action=login">
<div class="ui stacked segment">


<!-- Text input-->
  		<label>Nome</label>
  		<div class="ui left icon input">
        <i class="user icon"></i>
  		<input maxlength="100" name="nome" type="text" placeholder="Digite o seu nome">
  		</div>
<br>
<br>
<!-- Password input-->
		<label>Senha</label>
  		<div class="ui left icon input">
        <i class="lock icon"></i>
    	<input maxlength="100" name="senha" type="password" placeholder="Digite sua senha">
  		</div>
<br>
<br>
<!-- Button -->
  		<div class="field">
    	<input type="submit" name="logar" id="singlebutton" class="ui fluid large blue button">
  		</div>
<br>
        Novo por aqui? <a href="index.php?action=cadastrar">Crie uma conta</a>
</div>
    <div>
        <?php
        if (@$_GET['erro'] == 1){?>
            <div class="error-text" style="color: red">Nome ou Senha incorreto. Por Favor Tente novamente</div>
        <?php } ?>
    </div>
</form>
</div>
</div>

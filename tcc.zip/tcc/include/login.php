<br>
<br>
<br>
<div class="row">
    <div class="span12" style="text-align:center; margin: 0 auto;">
<form id="form" class="form-horizontal form-control" style="width: 400px; margin: 0 auto;" method="post" action="app/controllers/controladorAcao.php?acao=login">
	<fieldset>
<br>
	<legend>LOGIN</legend>
<br>
<!-- Text input-->
  		<label>Nome</label>
  		<div class="ui input">
  		<input maxlength="100" name="nome" type="text" placeholder="Digite o seu nome">
  		</div>
<br>
<br>
<!-- Password input-->
		<label>Senha</label>
  		<div class="ui input">
    	<input maxlength="100" name="senha" type="password" placeholder="Digite sua senha">
        <?php
            if (@$_GET['erro'] == 1){?>
            <div class="error-text" style="color: red">Nome ou Senha incorreto. Por Favor Tente novamente</div>
         <?php } ?>
  		</div>
<br>
<br>
<!-- Button -->
  		<div class="field">
    	<input type="submit" name="logar" id="singlebutton" class="ui blue button">
  		</div>
<br>
	</fieldset>
</form>
</div>
</div>

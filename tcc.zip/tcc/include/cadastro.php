<br>
<br>
<br>
<div class="span12" style="text-align:center; margin: 0 auto;">
<form id="form" class="form segment" style="width: 400px; margin: 0 auto;" method="post" action="app/controllers/controladorAcao.php?acao=cadastrar">
	<fieldset>
<br>
	<legend>CADASTRO</legend>

<!-- Text input-->
<br>
  		<label>Nome</label>
  		<div class="ui input">
  		<input maxlength="100" name="nome" type="text" placeholder="Digite o seu nome">
  		</div>
<br>
<br>
<!-- Email input-->
        <label>Email</label>
        <div class="ui input">
        <input maxlength="100" name="email" type="email" placeholder="Digite seu Email">
        </div>
<br>
<br>
<!-- Password input-->
		<label>Senha</label>
  		<div class="ui input">
    	<input maxlength="100" name="senha" type="password" placeholder="Digite sua senha">
  		</div>
<br>
<br>
<!-- Button -->
  		<div class="field">
    	<input class="ui blue button" type="submit" name="logar">
  		</div>
<br>
	</fieldset>
</form>
</div>
</div>


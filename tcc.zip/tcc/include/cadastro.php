<br>
<br>
<br>
<div class="span12" style="text-align:center; margin: 0 auto;">
<form id="form" class="form segment" style="width: 400px; margin: 0 auto;" method="post" action="app/controllers/controladorAcao.php?acao=cadastrar">
	<fieldset>
	<legend>CADASTRO</legend>

<!-- Text input-->
	<div class="field">
  		<label for="cadastro">Nome</label>
  		<div class="field">
  		<input id="cadastro" maxlength="100" name="nome" type="text" placeholder="Digite o seu nome" class="form-control input-large">
  		</div>
	</div>

<!-- Email input-->
    <div class="field">
        <label for="emailinput">Email</label>
        <div class="field">
        <input id="emailinput" maxlength="100" name="email" type="email" placeholder="Digite seu Email" class="form-control input-large">
        </div>
    </div>

<!-- Password input-->
	<div class="field">
		<label for="passwordinput">Senha</label>
  		<div class="field">
    	<input id="passwordinput" maxlength="100" name="senha" type="password" placeholder="Digite sua senha" class="form-control input-large">
  		</div>
	</div>
<br>
<!-- Button -->
	<div class="field">
  		<div class="field">
    	<input class="ui blue button" type="submit" name="logar" id="singlebutton">
  		</div>
	</div>

	</fieldset>
</form>
</div>
</div>


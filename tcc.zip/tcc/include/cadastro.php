<br>
<br>
<br>
<div class="ui middle aligned center aligned grid">
    <div class="column">
        <h2 class="ui teal image header">
           <img src="node_modules/semantic-ui/logo.png" class="image">
            <div class="content">
                Cadastre uma conta
            </div>
        </h2>

<form class="ui large form" style="width: 400px; margin: 0 auto;" method="post" action="app/controllers/controladorAcao.php?action=cadastrar">
<div class="ui stacked segment">


<!-- Text input-->
<br>
  		<label>Nome</label>
  		<div class="ui left icon input">
        <i class="user icon"></i>
  		<input maxlength="100" name="nome" type="text" placeholder="Digite o seu nome">
  		</div>
<br>
<br>
<!-- Email input-->
        <label>Email</label>
        <div class="ui left icon input">
        <i class="user icon"></i>
        <input maxlength="100" name="email" type="email" placeholder="Digite seu Email">
        </div>
<br>
<br>
<!-- Password input-->
		<label>Senha</label>
  		<div class="ui left icon input">
        <i class="lock icon"></i>
    	<input maxlength="100" name="senha" type="password" placeholder="Digite sua senha">
  		</div>
<br>
<br>
<!-- Button -->
  		<div class="field">
    	<input class="ui fluid large blue button" type="submit" name="logar">
  		</div>
<br>
    Já possui uma conta? <a href="index.php?ac=login">Log-in na sua conta</a>
</div>
</form>
</div>
</div>


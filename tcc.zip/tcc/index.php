<?php
/**
 * Created by PhpStorm.
 * User: aluno
 * Date: 19/03/18
 * Time: 16:00
 */
session_start();
?>
<!DOCTYPE html>
<html>
<head>
    <title>Página Inicial</title>
    <meta charset="utf-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge,chrome=1">
    <meta name="viewport" content="width=device-width, initial-scale=1.0, maximum-scale=1.0">
    <link rel="stylesheet" type="text/css" href="node_modules/semantic-ui/dist/semantic.min.css">
    <link rel="stylesheet" type="text/css" href="assets/css/menu.css">
	<script
  		src="https://code.jquery.com/jquery-3.1.1.min.js"
  		integrity="sha256-hVVnYaiADRTO2PzUGmuLJr8BLUSjGIZsDYGmIJLv2b8="
  		crossorigin="anonymous"></script>
	<script src="node_modules/semantic-ui/dist/semantic.min.js"></script>
    <script type="text/javascript">
        //ao carregar a pagina, fica sempre pronto pra executar
        $(function(){

            ///////////////////AQUI COMEÇA O CARRO 1////////////////////////////

            $('#marca').change(function(){
                if( $(this).val() ) {
                    $('#modelo').hide();
                    $('.carregando').show();


                    //http://localhost/tcc/app/controllers/controladorTab.php?marca=$(this).val()

                    $.getJSON('http://fipeapi.appspot.com/api/1/carros/veiculos/'+$(this).val()+'.json', function(j){
                            var options = '<option value="">Selecione...</option>';
                            for (var i = 0; i < j.length; i++) {
                                options += '<option value="' +
                                    j[i].id + '">' +
                                    j[i].name + '</option>';
                            }
                            $('#modelo').html(options).show();
                            $('.carregando').hide();
                        });
                } else {
                    $('#modelo').html(
                        '<option value="">-- Escolha uma montadora --</option>'
                    );
                }
            });

            $('#modelo').change(function(){
                if( $(this).val() ) {
                    $('#ano').hide();
                    $('.carregando').show();
                    $.getJSON(
                        'http://fipeapi.appspot.com/api/1/carros/veiculo/'+$('#marca').val()+'/'+$(this).val()+'.json', function(j){
                            var options = '<option value="">Selecione...</option>';
                            for (var i = 0; i < j.length; i++) {
                                options += '<option value="' +
                                    j[i].id + '">' +
                                    j[i].name + '</option>';
                            }
                            $('#ano').html(options).show();
                            $('.carregando').hide();
                        });
                } else {
                    $('#ano').html(
                        '<option value="">-- Escolha um modelo --</option>'
                    );
                }
            });
            ///////////////////////////////AQUI COMEÇA O CARRO 2////////////////////////////////////

            $('#marca1').change(function(){
                if( $(this).val() ) {
                    $('#modelo1').hide();
                    $('.carregando').show();


                    //http://localhost/tcc/app/controllers/controladorTab.php?marca=$(this).val()

                    $.getJSON('http://fipeapi.appspot.com/api/1/carros/veiculos/'+$(this).val()+'.json', function(j){
                        var options = '<option value="">Selecione...</option>';
                        for (var i = 0; i < j.length; i++) {
                            options += '<option value="' +
                                j[i].id + '">' +
                                j[i].name + '</option>';
                        }
                        $('#modelo1').html(options).show();
                        $('.carregando').hide();
                    });
                } else {
                    $('#modelo1').html(
                        '<option value="">-- Escolha uma montadora --</option>'
                    );
                }
            });

            $('#modelo1').change(function(){
                if( $(this).val() ) {
                    $('#ano1').hide();
                    $('.carregando').show();
                    $.getJSON(
                        'http://fipeapi.appspot.com/api/1/carros/veiculo/'+$('#marca1').val()+'/'+$(this).val()+'.json', function(j){
                            var options = '<option value="">Selecione...</option>';
                            for (var i = 0; i < j.length; i++) {
                                options += '<option value="' +
                                    j[i].id + '">' +
                                    j[i].name + '</option>';
                            }
                            $('#ano1').html(options).show();
                            $('.carregando').hide();
                        });
                } else {
                    $('#ano1').html(
                        '<option value="">-- Escolha um modelo --</option>'
                    );
                }
            });

            /////////////////////////////////////AQUI COMEÇA O CARRO 3///////////////////////////////////////

            $('#marca2').change(function(){
                if( $(this).val() ) {
                    $('#modelo2').hide();
                    $('.carregando').show();


                    //http://localhost/tcc/app/controllers/controladorTab.php?marca=$(this).val()

                    $.getJSON('http://fipeapi.appspot.com/api/1/carros/veiculos/'+$(this).val()+'.json', function(j){
                        var options = '<option value="">Selecione...</option>';
                        for (var i = 0; i < j.length; i++) {
                            options += '<option value="' +
                                j[i].id + '">' +
                                j[i].name + '</option>';
                        }
                        $('#modelo2').html(options).show();
                        $('.carregando').hide();
                    });
                } else {
                    $('#modelo2').html(
                        '<option value="">-- Escolha uma montadora --</option>'
                    );
                }
            });

            $('#modelo2').change(function(){
                if( $(this).val() ) {
                    $('#ano').hide();
                    $('.carregando').show();
                    $.getJSON(
                        'http://fipeapi.appspot.com/api/1/carros/veiculo/'+$('#marca2').val()+'/'+$(this).val()+'.json', function(j){
                            var options = '<option value="">Selecione...</option>';
                            for (var i = 0; i < j.length; i++) {
                                options += '<option value="' +
                                    j[i].id + '">' +
                                    j[i].name + '</option>';
                            }
                            $('#ano2').html(options).show();
                            $('.carregando').hide();
                        });
                } else {
                    $('#ano2').html(
                        '<option value="">-- Escolha um modelo --</option>'
                    );
                }
            });

            //AQUI COMEÇA O CARRO 4

            $('#marca3').change(function(){
                if( $(this).val() ) {
                    $('#modelo3').hide();
                    $('.carregando').show();


                    //http://localhost/tcc/app/controllers/controladorTab.php?marca=$(this).val()

                    $.getJSON('http://fipeapi.appspot.com/api/1/carros/veiculos/'+$(this).val()+'.json', function(j){
                        var options = '<option value="">Selecione...</option>';
                        for (var i = 0; i < j.length; i++) {
                            options += '<option value="' +
                                j[i].id + '">' +
                                j[i].name + '</option>';
                        }
                        $('#modelo3').html(options).show();
                        $('.carregando').hide();
                    });
                } else {
                    $('#modelo3').html(
                        '<option value="">-- Escolha uma montadora --</option>'
                    );
                }
            });

            $('#modelo3').change(function(){
                if( $(this).val() ) {
                    $('#ano3').hide();
                    $('.carregando').show();
                    $.getJSON(
                        'http://fipeapi.appspot.com/api/1/carros/veiculo/'+$('#marca3').val()+'/'+$(this).val()+'.json', function(j){
                            var options = '<option value="">Selecione...</option>';
                            for (var i = 0; i < j.length; i++) {
                                options += '<option value="' +
                                    j[i].id + '">' +
                                    j[i].name + '</option>';
                            }
                            $('#ano3').html(options).show();
                            $('.carregando').hide();
                        });
                } else {
                    $('#ano3').html(
                        '<option value="">-- Escolha um modelo --</option>'
                    );
                }
            });

        })

    </script>
    <style type="text/css">
    	@media only screen and (max-width: 700px) {
    		.ui.fixed.menu {
    			display: none !important;
    		}
    	}
    </style>
</head>
<body>
<div class="ui massive attached stackable container top menu">
    <div class="item left floated">
        <h1>VERSUS X</h1>
    </div>            
                <a class="item" href="index.php">Início</a>
                <a class="item" href="">Comentários</a>
            <?php
            if (!isset($_SESSION['logado'])){?>
                <a class="item" href="?action=login">Logar</a>
                <a class="item" href="?action=cadastrar">Cadastrar</a>
            <?php }
            ?><a class="item" href="?action=sobre">Sobre e Contatos</a>
            <?php
            if (isset($_SESSION['logado'])){?>
<!--                <a class="item" href="#">Perfil</a>-->
                <a class="item" href="app/controllers/controladorAcao.php?action=sair">Sair</a>
            <?php
            if (isset($_SESSION['logado']) and isset($_SESSION['tipo'])){?>
                <a class="item" href="app/controllers/controladorAcao.php?action=index">Admin</a>
            <?php } ?>
            <?php } ?>
    </div>
<br>
<br>
<br>

<?php
if (!isset($_SESSION['logado']) and isset($_GET['action']) and $_GET['action'] == 'login') {
    include_once "include/login.php";
}elseif (!isset($_SESSION['logado']) and isset($_GET['action']) and $_GET['action'] == 'cadastrar'){
    include_once "include/cadastro.php";
}elseif (isset($_GET['action']) and $_GET['action'] == 'sobre') {
    include_once "include/sobre.php";
}elseif (!isset($_GET['action'])) {
?>

    <div class="ui middle aligned center aligned grid">
        <div class="column">
            <div class="content">
                <h2 style="color: white;">COMPARE OS CARROS AQUI</h2>
            </div>
<br>
<br>
<form class="ui large form" method="post" action="app/controllers/controladorComp.php">
    <div class="fields">
    <div id="select" class="field">
    <div class="ui stacked segment borda">


<?php
    $url = 'http://fipeapi.appspot.com/api/1/carros/marcas.json'; // marcas

//http://fipeapi.appspot.com/api/1/carros/veiculos/21.json // veiculos da marca 21

    $data = file_get_contents($url); // put the contents of the file into a variable
    $marcas = json_decode($data); // decode the JSON feed

    echo '<select name="marca" id="marca" >';
    echo '<option selected>Selecione...</option>';
    foreach ($marcas as $marca) {
        echo '<option value="'.$marca->id.'">'.$marca->name.'</option>';
    }

    echo '</select>';
    ?>
    <select name="modelo" id="modelo">
        <option>selecione...</option>
    </select>


    <select name="ano" id="ano">
        <option>selecione...</option>
    </select>

        <div class="carregando" style="color: white;"><h3>Carregando...</h3></div>

    </div>
    </div>
    <div id="select" class="field">
        <div class="ui stacked segment borda">

            <?php

            echo '<select name="marca1" id="marca1" >';
            echo '<option selected>Selecione...</option>';
            foreach ($marcas as $marca) {
                echo '<option value="'.$marca->id.'">'.$marca->name.'</option>';
            }

            echo '</select>';
            ?>
            <select name="modelo1" id="modelo1">
                <option>selecione...</option>
            </select>

            <select name="ano1" id="ano1">
                <option>selecione...</option>
            </select>

            <div class="carregando" style="color: white;"><h3>Carregando...</h3></div>
    </div>
    </div>
    <br>

    <div id="select" class="field">
        <div class="ui stacked segment borda">

            <?php

            echo '<select name="marca2" id="marca2" >';
            echo '<option selected>Selecione...</option>';
            foreach ($marcas as $marca) {
                echo '<option value="'.$marca->id.'">'.$marca->name.'</option>';
            }

            echo '</select>';
            ?>
            <select name="modelo2" id="modelo2">
                <option>selecione...</option>
            </select>

            <select name="ano2" id="ano2">
                <option>selecione...</option>
            </select>

            <div class="carregando" style="color: white;"><h3>Carregando...</h3></div>
    </div>
    </div>

    <br>

    <div id="select" class="field">
        <div class="ui stacked segment borda">

            <?php

            echo '<select name="marca3" id="marca3" >';
            echo '<option selected>Selecione...</option>';
            foreach ($marcas as $marca) {
                echo '<option value="'.$marca->id.'">'.$marca->name.'</option>';
            }

            echo '</select>';
            ?>
            <select name="modelo3" id="modelo3">
                <option>selecione...</option>
            </select>

            <select name="ano3" id="ano3">
                <option>selecione...</option>
            </select>

            <div class="carregando" style="color: white;"><h3>Carregando...</h3></div>
    </div>
    </div>
            <button id="certo" class="ui blue button">COMPARAR</button>
    </div>

    </form>

    </div>
    </div>

<?php } ?>

</body>
</html>
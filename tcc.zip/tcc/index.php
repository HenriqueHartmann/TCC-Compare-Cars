<?php
/**
 * Created by PhpStorm.
 * User: aluno
 * Date: 19/03/18
 * Time: 16:00
 */
session_start();
?>
<!DOCTYPE html>
<html>
<head>
    <title>Página Inicial</title>
    <meta charset="utf-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge,chrome=1">
    <meta name="viewport" content="width=device-width, initial-scale=1.0, maximum-scale=1.0">
    <link rel="stylesheet" type="text/css" href="node_modules/semantic-ui/dist/semantic.min.css">
	<script
  		src="https://code.jquery.com/jquery-3.1.1.min.js"
  		integrity="sha256-hVVnYaiADRTO2PzUGmuLJr8BLUSjGIZsDYGmIJLv2b8="
  		crossorigin="anonymous"></script>
	<script src="node_modules/semantic-ui/semantic.min.js"></script>
    <script type="text/javascript">
        //ao carregar a pagina, fica sempre pronto pra executar
        $(function(){
            $('#teste').click(function(){
                alert('clicou em teste');
                $('.carregando').show();
                $('.carregando').html('<h2>Esta é a div carregando</h2>')
            });

            $('#teste').mouseover(function(){
                $('.carregando').show();
                $('.carregando').html('<h2>Tire o mouse daí</h2>')

            });

            $('#teste').mouseout(function(){
                $('.carregando').show();
                $('.carregando').html('<h2>Bom menino</h2>')

            });


            $('#marca').change(function(){
                if( $(this).val() ) {
                    $('#modelo').hide();
                    $('.carregando').show();
                    $.getJSON(
                        'http://fipeapi.appspot.com/api/1/carros/veiculos/'+$(this).val()+'.json', function(j){
                            var options = '<option value="">Selecione...</option>';
                            for (var i = 0; i < j.length; i++) {
                                options += '<option value="' +
                                    j[i].id + '">' +
                                    j[i].name + '</option>';
                            }
                            $('#modelo').html(options).show();
                            $('.carregando').hide();
                        });
                } else {
                    $('#modelo').html(
                        '<option value="">-- Escolha uma montadora --</option>'
                    );
                }
            });

            $('#modelo').change(function(){
                if( $(this).val() ) {
                    $('#ano').hide();
                    $('.carregando').show();
                    $.getJSON(
                        'http://fipeapi.appspot.com/api/1/carros/veiculo/'+$('#marca').val()+'/'+$(this).val()+'.json', function(j){
                            var options = '<option value="">Selecione...</option>';
                            for (var i = 0; i < j.length; i++) {
                                options += '<option value="' +
                                    j[i].id + '">' +
                                    j[i].name + '</option>';
                            }
                            $('#ano').html(options).show();
                            $('.carregando').hide();
                        });
                } else {
                    $('#ano').html(
                        '<option value="">-- Escolha um modelo --</option>'
                    );
                }
            });
            $("#tabela").hide();
            $("#certo").click(function () {
               $("#select").hide();
               $("#tabela").show();
            });



        })

    </script>
    <style type="text/css">
    	@media only screen and (max-width: 700px) {
    		.ui.fixed.menu {
    			display: none !important;
    		}
    	}
    </style>
</head>
<body>
<div class="ui massive attached stackable container inverted top menu" style="background-color: #FF9661 !important;">
    <div class="item">
        <img src="node_modules/semantic-ui/logo.png">
    </div>            
                <a class="item" href="index.php">Início</a>
            <?php
            if (!isset($_SESSION['logado'])){?>
                <a class="item" href="?action=cadastrar">Cadastrar</a>
                <a class="item" href="?action=login">Logar</a>
            <?php }
            if (isset($_SESSION['logado'])){?>
                <a class="item" href="#">Favoritos</a>
                <a class="item" href="#">Perfil</a>
                <a class="item" href="app/controllers/controladorAcao.php?action=sair">Sair</a>
            <?php
            if (isset($_SESSION['logado']) and isset($_SESSION['tipo'])){?>
                <a class="item" href="app/controllers/controladorAcao.php?action=index">Admin</a>
            <?php } ?>
            <?php } ?>
               <a class="item" href="?action=sobre">Sobre e Contatos</a>
    </div>
<br>
<br>
<br>

<?php
if (!isset($_SESSION['logado']) and isset($_GET['action']) and $_GET['action'] == 'login') {
    include_once "include/login.php";
}elseif (!isset($_SESSION['logado']) and isset($_GET['action']) and $_GET['action'] == 'cadastrar'){
    include_once "include/cadastro.php";
}elseif (isset($_GET['action']) and $_GET['action'] == 'sobre') {
    include_once "include/sobre.php";
}elseif (!isset($_GET['action'])) {
?>
    <div id="select">
<?php
    $url = 'http://fipeapi.appspot.com/api/1/carros/marcas.json'; // marcas

//http://fipeapi.appspot.com/api/1/carros/veiculos/21.json // veiculos da marca 21

    $data = file_get_contents($url); // put the contents of the file into a variable
    $marcas = json_decode($data); // decode the JSON feed

    echo '<select name="marca" id="marca">';
    echo '<option selected>Selecione...</option>';
    foreach ($marcas as $marca) {
        echo '<option value="'.$marca->id.'">'.$marca->name.'</option>';
    }

    echo '</select>';
    ?>
    <select name="modelo" id="modelo">
        <option>selecione...</option>
    </select>

    <select name="ano" id="ano">
        <option>selecione...</option>
    </select>


    <button id="teste">Teste</button>
    <button id="certo">Certo</button>

    <div class="carregando">Carregando...</div>
    </div>
<?php } ?>

<div id="tabela">
    <h1>ola mubndio</h1>

    <table>
        <thead>
        <tr>
            <th>potencia</th>
        </tr>
        <tr>
            <th>portas</th>
        </tr>
        <tr>
            <th>preco</th>
        </tr>
        <tr>
            <th>altura</th>
        </tr>
        <tr>
            <th>comprimento</th>
        </tr>
        <tr>
            <th>largura</th>
        </tr>
        <tr>
            <th>cambio</th>
        </tr>
        <tr>
            <th>velocidade</th>
        </tr>
        <tr>
            <th>tanque combustivel</th>
        </tr>
        <tr>
            <th>porta malas</th>
        </tr>
        <tr>
            <th>tipo de direção</th>
        </tr>
        <tr>
            <th>consumo urbano</th>
        </tr>
        <tr>
            <th>consumo rodoviario</th>
        </tr>
        <tr>
            <th>marcha</th>
        </tr>
        <tr>
            <th>tipo de tração</th>
        </tr>
        <tr>
            <th>porte</th>
        </tr>
        <tr>
            <th>ocupantes</th>
        </tr>
        <tr>
            <th>tipo de freio</th>
        </tr>
        <tr>
            <th>tipo do veiculo</th>
        </tr>
        </thead>
        <tbody>
        <?php foreach ($usuarios as $usuario): ?>
            <tr>
                <th scope="row"><?= $usuario->getId() ?></th>
                <td><?=$usuario->getNome() ?></td>
                <td><?=$usuario->getEmail() ?></td>
                <td><?=$usuario->getSenha() ?></td>
                <td><?=$usuario->getTipuser() ?></td>
            </tr>
        <?php endforeach ?>
        </tbody>
    </table>

</div>
</body>
</html>
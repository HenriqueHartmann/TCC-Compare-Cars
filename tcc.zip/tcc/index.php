<?php
/**
 * Created by PhpStorm.
 * User: aluno
 * Date: 19/03/18
 * Time: 16:00
 */
session_start();
?>
<!DOCTYPE html>
<html>
<head>
    <title>Página Inicial</title>
    <meta charset="utf-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge,chrome=1">
    <meta name="viewport" content="width=device-width, initial-scale=1.0, maximum-scale=1.0">
    <link rel="stylesheet" type="text/css" href="node_modules/semantic-ui/dist/semantic.min.css">
    <link rel="stylesheet" type="text/css" href="assets/css/menu.css">
	<script
  		src="https://code.jquery.com/jquery-3.1.1.min.js"
  		integrity="sha256-hVVnYaiADRTO2PzUGmuLJr8BLUSjGIZsDYGmIJLv2b8="
  		crossorigin="anonymous"></script>
	<script src="node_modules/semantic-ui/dist/semantic.min.js"></script>
    <script type="text/javascript">



        //ao carregar a pagina, fica sempre pronto pra executar
        $(function(){
            $(".carregando").hide();
            $(".select-marca").change(function () {
                if ($(this).val()){
                    var elemPai = $(this).parent();
                    elemPai.find(".select-modelo").hide();
                    elemPai.find(".carregando").show();
                    var url = 'http://fipeapi.appspot.com/api/1/carros/veiculos/'+$(this).val()+'.json';
                    $.getJSON(url, function(j){
                        var options = '<option value="">Selecione...</option>';
                        for (var i = 0; i < j.length; i++) {
                            options += '<option value="' +
                                j[i].id + '">' +
                                j[i].name + '</option>';
                        }
                        elemPai.find(".select-modelo").html(options);
                        elemPai.find(".select-modelo").show();
                        elemPai.find(".carregando").hide();
                    });

                }else {
                    $('.select-modelo').html(
                          '<option value="">-- Escolha uma montadora --</option>'
                    );
                }
            });

            $('.select-modelo').change(function(){
                if( $(this).val() ) {
                    var elemPai = $(this).parent();
                    var marca = elemPai.find('.select-marca').val();
                    elemPai.find('.select-ano').hide();
                    elemPai.find('.carregando').show();
                    $.getJSON(
                        'http://fipeapi.appspot.com/api/1/carros/veiculo/'+marca+'/'+$(this).val()+'.json', function(j){
                            var options = '<option value="">Selecione...</option>';
                            for (var i = 0; i < j.length; i++) {
                                options += '<option value="' +
                                    j[i].id + '">' +
                                    j[i].name + '</option>';
                            }
                            elemPai.find('.select-ano').html(options).show();
                            elemPai.find('.carregando').hide();
                        });
                } else {
                    $('.select-ano').html(
                        '<option value="">-- Escolha um modelo --</option>'
                    );
                }
            });

        })

    </script>
    <style type="text/css">
    	@media only screen and (max-width: 700px) {
    		.ui.fixed.menu {
    			display: none !important;
    		}
    	}
    </style>
</head>
<body>
<div class="ui massive attached stackable container top menu">
    <div class="item left floated">
        <h1>VERSUS X</h1>
    </div>            
                <a class="item" href="index.php">Início</a>
                <a class="item" href="">Comentários</a>
            <?php
            if (!isset($_SESSION['logado'])){?>
                <a class="item" href="?action=login">Logar</a>
                <a class="item" href="?action=cadastrar">Cadastrar</a>
            <?php }
            ?><a class="item" href="?action=sobre">Sobre e Contatos</a>
            <?php
            if (isset($_SESSION['logado'])){?>
<!--                <a class="item" href="#">Perfil</a>-->
                <a class="item" href="app/controllers/controladorAcao.php?action=sair">Sair</a>
            <?php
            if (isset($_SESSION['logado']) and isset($_SESSION['tipo'])){?>
                <a class="item" href="app/controllers/controladorAcao.php?action=index">Admin</a>
            <?php } ?>
            <?php } ?>
    </div>
<br>
<br>
<br>

<?php
if (!isset($_SESSION['logado']) and isset($_GET['action']) and $_GET['action'] == 'login') {
    include_once "include/login.php";
}elseif (!isset($_SESSION['logado']) and isset($_GET['action']) and $_GET['action'] == 'cadastrar'){
    include_once "include/cadastro.php";
}elseif (isset($_GET['action']) and $_GET['action'] == 'sobre') {
    include_once "include/sobre.php";
}elseif (!isset($_GET['action'])) {
?>

    <div class="ui middle aligned center aligned grid">
        <div class="column">
            <div class="content">
                <h2 style="color: white;">COMPARE OS CARROS AQUI</h2>
            </div>
<br>
<br>
<form class="ui large form" method="post" action="app/controllers/controladorComp.php">
    <div id="select" class="field">
    <div class="ui stacked segment borda">


<?php
    $url = 'http://fipeapi.appspot.com/api/1/carros/marcas.json'; // marcas

//http://fipeapi.appspot.com/api/1/carros/veiculos/21.json // veiculos da marca 21

    $data = file_get_contents($url); // put the contents of the file into a variable
    $marcas = json_decode($data); // decode the JSON feed

    echo '<select name="marca" id="marca" class="select-marca">';
    echo '<option selected>Selecione...</option>';
    foreach ($marcas as $marca) {
        echo '<option value="'.$marca->id.'">'.$marca->name.'</option>';
    }

    echo '</select>';
    ?>
    <select name="modelo" id="modelo" class="select-modelo">
        <option>selecione...</option>
    </select>


    <select name="ano" id="ano" class="select-ano">
        <option>selecione...</option>
    </select>

        <div class="carregando" style="color: white;"><h3>Carregando...</h3></div>

    </div>
    </div>
    <div id="select" class="field">
        <div class="ui stacked segment borda">

            <?php

            echo '<select name="marca1" id="marca1" class="select-marca">';
            echo '<option selected>Selecione...</option>';
            foreach ($marcas as $marca) {
                echo '<option value="'.$marca->id.'">'.$marca->name.'</option>';
            }

            echo '</select>';
            ?>
            <select name="modelo1" id="modelo1" class="select-modelo">
                <option>selecione...</option>
            </select>

            <select name="ano1" id="ano1" class="select-ano">
                <option>selecione...</option>
            </select>

            <div class="carregando" style="color: white;"><h3>Carregando...</h3></div>
    </div>
    </div>
    <br>

    <div id="select" class="field">
        <div class="ui stacked segment borda">

            <?php

            echo '<select name="marca2" id="marca2" class="select-marca">';
            echo '<option selected>Selecione...</option>';
            foreach ($marcas as $marca) {
                echo '<option value="'.$marca->id.'">'.$marca->name.'</option>';
            }

            echo '</select>';
            ?>
            <select name="modelo2" id="modelo2" class="select-modelo">
                <option>selecione...</option>
            </select>

            <select name="ano2" id="ano2" class="select-ano">
                <option>selecione...</option>
            </select>

            <div class="carregando" style="color: white;"><h3>Carregando...</h3></div>
    </div>
    </div>

    <br>

    <div id="select" class="field">
        <div class="ui stacked segment borda">

            <?php

            echo '<select name="marca3" id="marca3" class="select-marca">';
            echo '<option selected>Selecione...</option>';
            foreach ($marcas as $marca) {
                echo '<option value="'.$marca->id.'">'.$marca->name.'</option>';
            }

            echo '</select>';
            ?>
            <select name="modelo3" id="modelo3" class="select-modelo">
                <option>selecione...</option>
            </select>

            <select name="ano3" id="ano3" class="select-ano">
                <option>selecione...</option>
            </select>

            <div class="carregando" style="color: white;"><h3>Carregando...</h3></div>
    </div>
    </div>
            <button id="certo" class="ui blue button">COMPARAR</button>

    </form>

    </div>
    </div>

<?php } ?>

</body>
</html>
<div style="background-color: #24292e;">
    <div style="background-color: #24292e;" class="ui large stackable menu">
        <h3 style="color: #f40612" class="item header">VERSUS</h3>
        <div class="right menu">
            <a class="ui item" href="controladorUsuario.php?acao=index">Início</a>
            <?php

            if (!esta_logado()){?>
                <a style="<?=($_GET['acaoi'] == 'login') ? 'color: #f40612!important;' : ''?>" class="ui item" href="controladorUsuario.php?acaoi=login">Logar</a>
                <a style="<?=($_GET['acaoi'] == 'cadastrar') ? 'color: #f40612!important;' : ''?>" class="ui item" href="controladorUsuario.php?acaoi=cadastrar">Cadastrar</a>
                <a style="<?=($_GET['acaoi'] == 'sobre') ? 'color: #f40612!important;' : ''?>" class="ui item" href="controladorUsuario.php?acaoi=sobre">Sobre e Contatos</a>
            <?php }

            if (esta_logado()){?>
                <!--                <a class="item" href="#">Perfil</a>-->
                <a style="<?=($_GET['acaoi'] == 'comentario') ? 'color: #f40612!important;' : '' ?>" class="ui item" href="controladorUsuario.php?acaoi=comentario&user=<?php if(esta_logado()) { echo $_SESSION['id'];}else{'nada';} ?>"">Comentários</a>
                <a class="ui item" href="controladorUsuario.php?acao=logout">Logout</a>
                <?php
                if (e_admin()){?>
                    <a class="ui item" href="controladorAdmin.php?acao=decisao">Admin</a>
                <?php }
            } ?>
        </div>
    </div>
</div>
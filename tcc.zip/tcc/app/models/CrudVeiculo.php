<?php
/**
 * Created by PhpStorm.
 * User: aluno
 * Date: 14/05/18
 * Time: 16:51
 */
    require_once "DBConexao.php";
class CrudVeiculo
{
    private $conexao;

    public function __construct()
    {
        $this->conexao = DBConexao::getConexao();
    }

    public function getMontadora($nome){
        $sql = $this->conexao->prepare("SELECT nome FROM montadora Where nome_montadora =". $nome);
        $sql->execute();
        $count = $sql->rowCount();
        try {
            return $count;
        } catch (PDOException $e) {
            return $e->getMessage();
        }
    }
}
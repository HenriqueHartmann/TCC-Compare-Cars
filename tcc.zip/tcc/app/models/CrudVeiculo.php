<?php
/**
 * Created by PhpStorm.
 * User: aluno
 * Date: 14/05/18
 * Time: 16:51
 */
    require_once "DBConexao.php";
class CrudVeiculo
{
    private $conexao;

    public function __construct()
    {
        $this->conexao = DBConexao::getConexao();
    }

    public function getVeiculo($id){

    }
}
<?php
/**
 * Created by PhpStorm.
 * User: aluno
 * Date: 14/05/18
 * Time: 16:51
 */
    require_once "DBConexao.php";
    require_once "Veiculo.php";
class CrudVeiculo
{
    private $conexao;

    public function __construct()
    {
        $this->conexao = DBConexao::getConexao();
    }

    public function getMontadora($idmont){
        $sql = $this->conexao->prepare("SELECT montadora FROM montadora WHERE idmontadora=". $idmont);
        $sql->execute();
        $count = $sql->rowCount();
        try {
            return $count;
        } catch (PDOException $e) {
            return $e->getMessage();
        }
    }

    public function getModelo($idmod){
        $sql = $this->conexao->prepare("SELECT nome_modelo FROM modelo WHERE idmodelo=". $idmod);
        $sql->execute();
        $count = $sql->rowCount();
        try {
            return $count;
        } catch (PDOException $e) {
            return $e->getMessage();
        }
    }

    public function getModelAno($idmont, $idmod, $idAno){
        $sql = $this->conexao->prepare("SELECT ano,potencia,portas,preco,altura,comprimento,largura,cambio,velocidade,tanque_combustivel,tip_combustivel,porta_malas,tip_direcao,consumo_urb,consumo_rod,marcha,tip_tracao,porte,ocupantes,tip_freio,tip_veiculo FROM modelo_ano, modelo WHERE idveiculo='{$idAno}',idmodelo='{$idmod}', montadora_idmontadora=". $idmont);
        $sql->execute();
        $count = $sql->rowCount();
        try {
            return $count;
        } catch (PDOException $e) {
            return $e->getMessage();
        }
    }
}
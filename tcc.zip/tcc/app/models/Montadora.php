<?php
/**
 * Created by PhpStorm.
 * User: aluno
 * Date: 09/04/18
 * Time: 16:26
 */

class Montadora
{
    private $idmontadora;
    private $nome_montadora;

    public function __construct($idmontadora = null, $nome_montadora = null)
    {
        $this->idmontadora = $idmontadora;
        $this->nome_montadora = $nome_montadora;
    }

    public function getIdmontadora()
    {
        return $this->idmontadora;
    }

    public function setIdmontadora($idmontadora)
    {
        $this->idmontadora = $idmontadora;
    }

    public function getNomeMontadora()
    {
        return $this->nome_montadora;
    }

    public function setNomeMontadora($nome_montadora)
    {
        $this->nome_montadora = $nome_montadora;
    }


}
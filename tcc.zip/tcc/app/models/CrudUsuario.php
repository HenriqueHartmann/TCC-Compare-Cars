.<?php

    require_once "Usuario.php";
    require_once "DBConexao.php";

    class CrudUsuario
    {
        private $conexao;

        public function __construct()
        {
            $this->conexao = DBConexao::getConexao();
        }

        public function getUsuario($nome)
        {
            $sql = "SELECT * FROM usuario WHERE id_user =" . $nome;
            $resultado = $this->conexao->query($sql);
            $user = $resultado->fetch(PDO::FETCH_ASSOC);

            $objUser = new Usuario($user['id_user'], $user['nome'], $user['email'], $user['senha'], $user['tip_user']);
            return $objUser;
        }

        public function insertUsuario(Usuario $user)
        {

            $this->conexao = DBConexao::getConexao();

            $sql = "INSERT INTO usuario (nome, email, senha, tip_user) VALUES ('{$user->getNome()}','{$user->getEmail()}','{$user->getSenha()}','{$user->getTipuser()}')";
            try {
                $this->conexao->exec($sql);
            } catch (PDOException $e) {
                return $e->getMessage();
            }
        }

        public function verificaTipo($user)
        {
            $sql = "SELECT tip_user FROM usuario WHERE nome = '{$user->getNome()}' AND senha = '{$user->getSenha()}'";
            $resultado = $this->conexao->query($sql);
            $info = $resultado->fetch(PDO::FETCH_ASSOC);

            $objInfo = new Usuario($info['id_user'], $info['nome'], $info['email'], $info['tip_user']);
            $tipo = $objInfo ->getTipuser();
            return $tipo;

        }

        public function loginUser(Usuario $user)
        {
               $sql = $this->conexao->prepare("SELECT id_user, email, nome, senha, tip_user FROM usuario WHERE nome = '{$user->getNome()}' AND senha = '{$user->getSenha()}'");
               $sql->execute();
               $count = $sql->rowCount();

            try {
                return $count;
            } catch (PDOException $e) {
                return $e->getMessage();
            }
        }
    }
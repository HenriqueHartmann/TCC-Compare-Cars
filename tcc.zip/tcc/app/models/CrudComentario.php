<?php
/**
 * Created by PhpStorm.
 * User: aluno
 * Date: 19/06/18
 * Time: 08:29
 */

    require_once "DBConexao.php";

class CrudComentario
{
    private $conexao;

    public function __construct(){
        $this->conexao = DBConexao::getConexao();
    }

    public function getComentario($id){
        $sql = "SELECT * FROM comentario WHERE idcoment=".$id;
        $result = $this->conexao->query($sql);
        $coment = $result->fetch(PDO::FETCH_ASSOC);
        $objcoment = new Comentario($coment['nome'], $coment['texto'], $coment['data']);
        return $objcoment;
    }

    public function getComentarios(){
        $sql = "SELECT * FROM comentario";
        $result = $this->conexao->query($sql);
        $comentarios = $result->fetchAll(PDO::FETCH_ASSOC);
        foreach ($comentarios as $comentario){
            $id = $comentario['idcoment'];
            $nome = $comentario['nome'];
            $texto = $comentario['texto'];
            $data = $comentario['data'];
            $comentario_cod = $comentario['comentario_cod'];
            $obj = new Comentario($id, $nome, $texto, $data, $comentario_cod);
            $listacomentarios[] = $obj;
        }
        return $obj;
    }

    public function insertComentario(Comentario $comentario){
        $sql = "INSERT INTO comentario (nome, texto, data) VALUES ('{$comentario->getNome()}', '{$comentario->getTexto()}', '{$comentario->getData()}')";
        try{
            $this->conexao->exec($sql);
        }catch (PDOException $e){
            return $e->getMessage();
        }
    }

    public function verificaComentario(Comentario $comentario){
        if (strlen($comentario->getNome()) >=5 && strlen($comentario->getNome()) <= 50){
            if (strlen($comentario->setTexto()) >=1 && strlen($comentario->getTexto()) <=500){
                return $this->getComentario($comentario);
            }else{
                return false;
            }
        }else{
            return false;
        }
    }

}
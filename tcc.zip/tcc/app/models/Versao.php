<?php
/**
 * Created by PhpStorm.
 * User: aluno
 * Date: 09/04/18
 * Time: 16:27
 */

class Versao
{
    private $id_versao;
    private $versao;
    private $ano_id_ano;

    public function __construct($id_versao = null, $versao = null, $ano_id_ano = null)
    {
        $this->id_versao = $id_versao;
        $this->versao = $versao;
        $this->ano_id_ano = $ano_id_ano;
    }

    public function getIdVersao()
    {
        return $this->id_versao;
    }

    public function setIdVersao($id_versao)
    {
        $this->id_versao = $id_versao;
    }

    public function getVersao()
    {
        return $this->versao;
    }

    public function setVersao($versao)
    {
        $this->versao = $versao;
    }

    public function getAnoIdAno()
    {
        return $this->ano_id_ano;
    }

    public function setAnoIdAno($ano_id_ano)
    {
        $this->ano_id_ano = $ano_id_ano;
    }


}
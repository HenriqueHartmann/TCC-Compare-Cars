<div class="ui segment">
</br>
</br>
    <img class="ui centered medium image" src="../../assets/images/adminlogo.png">
</div>
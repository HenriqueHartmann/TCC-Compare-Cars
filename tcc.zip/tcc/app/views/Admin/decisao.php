<div class="ui two column page grid">
<div class="column">
    <div class="ui teal vertical menu segment">
        <div class="item">
            <div class="header">ADMIN</div>
            <div class="menu">
                <a class="item lic" href="controladorUsuario.php?&user=<?= $_SESSION['id'] ?>">Index</a>
            </div>
        </div>
        <div class="item">
            <div class="header">USUARIOS</div>
            <div class="menu">
                <a class="item lic" href="?acao=cadastro">Cadastrar</a>
                <a class="item lic" href="?acao=lista">Tabela</a>
                <a class="item lic">Comentários</a>
            </div>
        </div>
        <div class="item">
            <div class="header">VEÍCULOS</div>
            <div class="menu">
                <a class="item lic">Montadoras</a>
                <a class="item lic">Modelos</a>
                <a class="item lic">Especificações</a>
            </div>
        </div>
    </div>
</div>

<br>
<br>
<?php $coments->getComentarios();
foreach ($coments as $coment): ?>
<div class="ui comments centered centered card">
    <div class="comment">
        <a class="avatar">
            <img src="../../steve.jpg">
        </a>
        <div class="content">
            <a class="author"><</a>
            <div class="metadata">
                <div class="date">2 days ago</div>
            </div>
            <div class="text">
                Revolutionary!
            </div>
            <div class="actions">
                <a class="reply active">Reply</a>
            </div>
        </div>
    </div>
</div>
<?php endforeach; ?>
<br>
<form class="ui reply form">
    <div class="field">
        <textarea></textarea>
    </div>
    <div class="ui primary submit labeled icon button">
        <i class="icon edit"></i> Add Reply
    </div>
</form>

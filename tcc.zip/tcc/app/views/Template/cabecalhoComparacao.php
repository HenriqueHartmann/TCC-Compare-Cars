<!DOCTYPE html>
<html>
<head>
    <title>Página Inicial</title>
    <meta charset="utf-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge,chrome=1">
    <meta name="viewport" content="width=device-width, initial-scale=1.0, maximum-scale=1.0">
    <link rel="stylesheet" type="text/css" href="../../node_modules/semantic-ui/dist/semantic.min.css">
    <link rel="stylesheet" type="text/css" href="../../assets/css/comp.css">
    <script
        src="https://code.jquery.com/jquery-3.1.1.min.js"
        integrity="sha256-hVVnYaiADRTO2PzUGmuLJr8BLUSjGIZsDYGmIJLv2b8="
        crossorigin="anonymous"></script>
    <script src="../../node_modules/semantic-ui/dist/semantic.min.js"></script>
    <style type="text/css">
        @media only screen and (max-width: 700px) {
            .ui.fixed.menu {
                display: none !important;
            }
        }
        .footer {
            position: relative;
            margin-top: -70px;
            height: 70px;
            clear: both;
        }
    </style>
</head>
<body>

<div style="background-color: #24292e;">
    <div style="background-color: #24292e;" class="ui large stackable menu">
        <h3 style="color: #f40612" class="item header">VERSUS</h3>
        <div class="right menu">
            <a class="ui item" href="controladorUsuario.php?acao=index">Início</a>
            <?php

            if (!esta_logado()){?>
                <a style="<?=($_GET['acaoi'] == 'login') ? 'color: #f40612!important;' : ''?>" class="ui item" href="?acaoi=login">Logar</a>
                <a style="<?=($_GET['acaoi'] == 'cadastrar') ? 'color: #f40612!important;' : ''?>" class="ui item" href="controladorUsuario.php?acaoi=cadastrar">Cadastrar</a>
                <a style="<?=($_GET['acaoi'] == 'sobre') ? 'color: #f40612!important;' : ''?>" class="ui item" href="controladorUsuario.php?acaoi=sobre">Sobre e Contatos</a>
            <?php }

            if (esta_logado()){?>
                <!--                <a class="item" href="#">Perfil</a>-->
                <a style="<?=($_GET['acaoi'] == 'comentario') ? 'color: #f40612!important;' : '' ?>" class="ui item" href="controladorUsuario.php?acaoi=comentario&user=<?php if(esta_logado()) { echo $_SESSION['id'];}else{'nada';} ?>"">Comentários</a>
                <a class="ui item" href="controladorUsuario.php?acao=logout">Logout</a>
                <?php
                if (e_admin()){?>
                    <a class="ui item" href="controladorAdmin.php?acao=decisao">Admin</a>
                <?php }
            } ?>
        </div>
    </div>
</div>

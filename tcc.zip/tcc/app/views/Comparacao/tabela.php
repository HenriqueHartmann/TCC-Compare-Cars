<div id="tabela">
    <table class="ui small green table">
        <thead>
        <tr>
            <th>nº Carro </th>
            <th>Carro1</th>
            <th>Carro2</th>
            <th>Carro3</th>
            <th>Carro4</th>
        </tr>
        <tr>
            <th>id</th>
            <th><?= $auto1->getIdveiculo(); ?></th>
            <th><?= $auto2->getIdveiculo(); ?></th>
            <th><?= $auto3->getIdveiculo(); ?></th>
            <th><?= $auto4->getIdveiculo(); ?></th>
        </tr>
        <tr>

            <!--            ANO-->
            <th>ano</th>

            <?php $melhorAno = ano($auto1->getAno(), $auto2->getAno(), $auto3->getAno(), $auto4->getAno()); ?>

            <th><i id="ano1" class="<?= ($auto1->getAno() == $melhorAno) ? "large green checkmark icon" : "large red close icon"; ?>"></i><?= $auto1->getAno(); ?> </th>
            <th><i id="ano2" class="<?= ($auto2->getAno() == $melhorAno) ? "large green checkmark icon" : "large red close icon"; ?>"></i><?= $auto2->getAno(); ?> </th>
            <th><i id="ano3" class="<?= ($auto3->getAno() == $melhorAno) ? "large green checkmark icon" : "large red close icon"; ?>"></i><?= $auto3->getAno(); ?> </th>
            <th><i id="ano4" class="<?= ($auto4->getAno() == $melhorAno) ? "large green checkmark icon" : "large red close icon"; ?>"></i><?= $auto4->getAno(); ?> </th>
        </tr>
        <tr>


            <!--           POTENCIA-->
            <th>potencia</th>

            <?php $melhorPot = potencia($auto1->getPotencia(), $auto2->getPotencia(), $auto3->getPotencia(), $auto4->getPotencia());
            $pot1 = substr($auto1->getPotencia(), 10, 4);
            $pot2 = substr($auto2->getPotencia(), 10, 4);
            $pot3 = substr($auto3->getPotencia(), 10, 4);
            $pot4 = substr($auto4->getPotencia(), 10, 4);
            ?>

            <th><i id="pot1" class="<?= ($pot1 == $melhorPot) ? "large green checkmark icon" : "large red close icon"; ?>"></i><?= $auto1->getPotencia(); ?> </th>
            <th><i id="pot2" class="<?= ($pot2 == $melhorPot) ? "large green checkmark icon" : "large red close icon"; ?>"></i><?= $auto2->getPotencia(); ?> </th>
            <th><i id="pot3" class="<?= ($pot3 == $melhorPot) ? "large green checkmark icon" : "large red close icon"; ?>"></i><?= $auto3->getPotencia(); ?> </th>
            <th><i id="pot4" class="<?= ($pot4 == $melhorPot) ? "large green checkmark icon" : "large red close icon"; ?>"></i><?= $auto4->getPotencia(); ?> </th>
        </tr>
        <tr>
            <th>portas</th>
            <th><?= $auto1->getPortas(); ?> <i class="large green checkmark icon"></i></th>
            <th><?= $auto2->getPortas(); ?> <i class="large red close icon"></i></th>
            <th><?= $auto3->getPortas(); ?> <i class="large red close icon"></i></th>
            <th><?= $auto4->getPortas(); ?> <i class="large red close icon"></i></th>
        </tr>
        <tr>
            <th>preco</th>
            <th><?= $auto1->getPreco(); ?> <i class="large green checkmark icon"></i></th>
            <th><?= $auto2->getPreco(); ?> <i class="large red close icon"></i></th>
            <th><?= $auto3->getPreco(); ?> <i class="large red close icon"></i></th>
            <th><?= $auto4->getPreco(); ?> <i class="large red close icon"></i></th>
        </tr>
        <tr>
            <th>altura</th>
            <th><?= $auto1->getAltura(); ?> <i class="large green checkmark icon"></i></th>
            <th><?= $auto2->getAltura(); ?> <i class="large red close icon"></i></th>
            <th><?= $auto3->getAltura(); ?> <i class="large red close icon"></i></th>
            <th><?= $auto4->getAltura(); ?> <i class="large red close icon"></i></th>
        </tr>
        <tr>
            <th>comprimento</th>
            <th><?= $auto1->getComprimento(); ?> <i class="large green checkmark icon"></i></th>
            <th><?= $auto2->getComprimento(); ?> <i class="large red close icon"></i></th>
            <th><?= $auto3->getComprimento(); ?> <i class="large red close icon"></i></th>
            <th><?= $auto4->getComprimento(); ?> <i class="large red close icon"></i></th>
        </tr>
        <tr>
            <th>largura</th>
            <th><?= $auto1->getLargura(); ?> <i class="large green checkmark icon"></i></th>
            <th><?= $auto2->getLargura(); ?> <i class="large red close icon"></i></th>
            <th><?= $auto3->getLargura(); ?> <i class="large red close icon"></i></th>
            <th><?= $auto4->getLargura(); ?> <i class="large red close icon"></i></th>
        </tr>
        <tr>
            <th>cambio</th>
            <th><?= $auto1->getCambio(); ?> <i class="large green checkmark icon"></i></th>
            <th><?= $auto2->getCambio(); ?> <i class="large red close icon"></i></th>
            <th><?= $auto3->getCambio(); ?> <i class="large red close icon"></i></th>
            <th><?= $auto4->getCambio(); ?> <i class="large red close icon"></i></th>
        </tr>
        <tr>
            <th>velocidade</th>
            <th><?= $auto1->getVelocidade(); ?> <i class="large green checkmark icon"></i></th>
            <th><?= $auto2->getVelocidade(); ?> <i class="large red close icon"></i></th>
            <th><?= $auto3->getVelocidade(); ?> <i class="large red close icon"></i></th>
            <th><?= $auto4->getVelocidade(); ?> <i class="large red close icon"></i></th>
        </tr>
        <tr>
            <th>tanque combustivel</th>
            <th><?= $auto1->getTanqueCombustivel(); ?> <i class="large green checkmark icon"></i></th>
            <th><?= $auto2->getTanqueCombustivel(); ?> <i class="large red close icon"></i></th>
            <th><?= $auto3->getTanqueCombustivel(); ?> <i class="large red close icon"></i></th>
            <th><?= $auto4->getTanqueCombustivel(); ?> <i class="large red close icon"></i></th>
        </tr>
        <tr>
            <th>Tipo combustivel</th>
            <th><?= $auto1->getTipCombustivel(); ?> <i class="large green checkmark icon"></i></th>
            <th><?= $auto2->getTipCombustivel(); ?> <i class="large red close icon"></i></th>
            <th><?= $auto3->getTipCombustivel(); ?> <i class="large red close icon"></i></th>
            <th><?= $auto4->getTipCombustivel(); ?> <i class="large red close icon"></i></th>
        </tr>
        <tr>
            <th>porta malas</th>
            <th><?= $auto1->getPortaMalas(); ?> <i class="large green checkmark icon"></i></th>
            <th><?= $auto2->getPortaMalas(); ?> <i class="large red close icon"></i></th>
            <th><?= $auto3->getPortaMalas(); ?> <i class="large red close icon"></i></th>
            <th><?= $auto4->getPortaMalas(); ?> <i class="large red close icon"></i></th>
        </tr>
        <tr>
            <th>tipo de direção</th>
            <th><?= $auto1->getTipDirecao(); ?> <i class="large green checkmark icon"></i></th>
            <th><?= $auto2->getTipDirecao(); ?> <i class="large red close icon"></i></th>
            <th><?= $auto3->getTipDirecao(); ?> <i class="large red close icon"></i></th>
            <th><?= $auto4->getTipDirecao(); ?> <i class="large red close icon"></i></th>
        </tr>
        <tr>
            <th>consumo urbano</th>
            <th><?= $auto1->getConsumoUrb(); ?> <i class="large green checkmark icon"></i></th>
            <th><?= $auto2->getConsumoUrb(); ?> <i class="large red close icon"></i></th>
            <th><?= $auto3->getConsumoUrb(); ?> <i class="large red close icon"></i></th>
            <th><?= $auto4->getConsumoUrb(); ?> <i class="large red close icon"></i></th>
        </tr>
        <tr>
            <th>consumo rodoviario</th>
            <th><?= $auto1->getConsumoRod(); ?> <i class="large green checkmark icon"></i></th>
            <th><?= $auto2->getConsumoRod(); ?> <i class="large red close icon"></i></th>
            <th><?= $auto3->getConsumoRod(); ?> <i class="large red close icon"></i></th>
            <th><?= $auto4->getConsumoRod(); ?> <i class="large red close icon"></i></th>
        </tr>
        <tr>
            <th>marcha</th>
            <th><?= $auto1->getMarcha(); ?> <i class="large green checkmark icon"></i></th>
            <th><?= $auto2->getMarcha(); ?> <i class="large red close icon"></i></th>
            <th><?= $auto3->getMarcha(); ?> <i class="large red close icon"></i></th>
            <th><?= $auto4->getMarcha(); ?> <i class="large red close icon"></i></th>
        </tr>
        <tr>
            <th>tipo de tração</th>
            <th><?= $auto1->getTipTracao(); ?> <i class="large green checkmark icon"></i></th>
            <th><?= $auto2->getTipTracao(); ?> <i class="large red close icon"></i></th>
            <th><?= $auto3->getTipTracao(); ?> <i class="large red close icon"></i></th>
            <th><?= $auto4->getTipTracao(); ?> <i class="large red close icon"></i></th>
        </tr>
        <tr>
            <th>porte</th>
            <th><?= $auto1->getPorte(); ?> <i class="large green checkmark icon"></i></th>
            <th><?= $auto2->getPorte(); ?> <i class="large red close icon"></i></th>
            <th><?= $auto3->getPorte(); ?><i class="large red close icon"></i></th>
            <th><?= $auto4->getPorte(); ?> <i class="large red close icon"></i></th>
        </tr>
        <tr>
            <th>ocupantes</th>
            <th><?= $auto1->getOcupantes(); ?> <i class="large green checkmark icon"></i></th>
            <th><?= $auto2->getOcupantes(); ?> <i class="large red close icon"></i></th>
            <th><?= $auto3->getOcupantes(); ?> <i class="large red close icon"></i></th>
            <th><?= $auto4->getOcupantes(); ?> <i class="large red close icon"></i></th>
        </tr>
        <tr>
            <th>tipo de freio</th>
            <th><?= $auto1->getTipFreio(); ?> <i class="large green checkmark icon"></i></th>
            <th><?= $auto2->getTipFreio(); ?> <i class="large red close icon"></i></th>
            <th><?= $auto3->getTipFreio(); ?> <i class="large red close icon"></i></th>
            <th><?= $auto4->getTipFreio(); ?> <i class="large red close icon"></i></th>
        </tr>
        <tr>
            <th>tipo do veiculo</th>
            <th><?= $auto1->getTipVeiculo(); ?> <i class="large green checkmark icon"></i></th>
            <th><?= $auto2->getTipVeiculo(); ?> <i class="large red close icon"></i></th>
            <th><?= $auto3->getTipVeiculo(); ?> <i class="large red close icon"></i></th>
            <th><?= $auto4->getTipVeiculo(); ?> <i class="large red close icon"></i></th>
        </tr>
        </thead>
    </table>
</div>
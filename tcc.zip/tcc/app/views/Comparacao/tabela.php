<div id="tabela">
    <table class="ui small green table">
        <thead>
        <tr>
            <th>nº Carro </th>
            <th>Carro1</th>
            <th>Carro2</th>
            <th>Carro3</th>
            <th>Carro4</th>
        </tr>
        <tr>
            <th>id</th>
            <th><?= $auto1->getIdveiculo(); ?></th>
            <th><?= $auto2->getIdveiculo(); ?></th>
            <th><?= $auto3->getIdveiculo(); ?></th>
            <th><?= $auto4->getIdveiculo(); ?></th>
        </tr>
        <tr>

            <!--            ANO-->
            <th>Ano</th>

            <?php $melhorAno = ano($auto1->getAno(), $auto2->getAno(), $auto3->getAno(), $auto4->getAno()); ?>

            <th><i id="ano1" class="<?= ($auto1->getAno() == $melhorAno) ? "large green checkmark icon" : "large red close icon"; ?>"></i><?= $auto1->getAno(); ?> </th>
            <th><i id="ano2" class="<?= ($auto2->getAno() == $melhorAno) ? "large green checkmark icon" : "large red close icon"; ?>"></i><?= $auto2->getAno(); ?> </th>
            <th><i id="ano3" class="<?= ($auto3->getAno() == $melhorAno) ? "large green checkmark icon" : "large red close icon"; ?>"></i><?= $auto3->getAno(); ?> </th>
            <th><i id="ano4" class="<?= ($auto4->getAno() == $melhorAno) ? "large green checkmark icon" : "large red close icon"; ?>"></i><?= $auto4->getAno(); ?> </th>
        </tr>
        <tr>


            <!--           POTENCIA-->
            <th>Potencia</th>

            <?php $melhorPot = potencia($auto1->getPotencia(), $auto2->getPotencia(), $auto3->getPotencia(), $auto4->getPotencia());
            $pot1 = substr($auto1->getPotencia(), 10, 4);
            $pot2 = substr($auto2->getPotencia(), 10, 4);
            $pot3 = substr($auto3->getPotencia(), 10, 4);
            $pot4 = substr($auto4->getPotencia(), 10, 4);
            ?>

            <th><i id="pot1" class="<?= ($pot1 == $melhorPot) ? "large green checkmark icon" : "large red close icon"; ?>"></i><?= $auto1->getPotencia(); ?> </th>
            <th><i id="pot2" class="<?= ($pot2 == $melhorPot) ? "large green checkmark icon" : "large red close icon"; ?>"></i><?= $auto2->getPotencia(); ?> </th>
            <th><i id="pot3" class="<?= ($pot3 == $melhorPot) ? "large green checkmark icon" : "large red close icon"; ?>"></i><?= $auto3->getPotencia(); ?> </th>
            <th><i id="pot4" class="<?= ($pot4 == $melhorPot) ? "large green checkmark icon" : "large red close icon"; ?>"></i><?= $auto4->getPotencia(); ?> </th>
        </tr>
        <tr>


            <th>Portas</th>

            <?php $melhorPort = portas($auto1->getPortas(), $auto2->getPortas(), $auto3->getPortas(), $auto4->getPortas());
            $port1 = substr($auto1->getPortas(), 0, 1);
            $port2 = substr($auto2->getPortas(), 0, 1);
            $port3 = substr($auto3->getPortas(), 0, 1);
            $port4 = substr($auto4->getPortas(), 0, 1);
            ?>

            <th><i id="port1" class="<?= ($port1 == $melhorPort) ? "large green checkmark icon" : "large red close icon"; ?>"></i><?= $auto1->getPortas(); ?> </th>
            <th><i id="port2" class="<?= ($port2 == $melhorPort) ? "large green checkmark icon" : "large red close icon"; ?>"></i><?= $auto2->getPortas(); ?> </th>
            <th><i id="port3" class="<?= ($port3 == $melhorPort) ? "large green checkmark icon" : "large red close icon"; ?>"></i><?= $auto3->getPortas(); ?> </th>
            <th><i id="port4" class="<?= ($port4 == $melhorPort) ? "large green checkmark icon" : "large red close icon"; ?>"></i><?= $auto4->getPortas(); ?> </th>
        </tr>
        <tr>


            <th>Preco</th>

            <?php $melhorPreco = preco($auto1->getPreco(), $auto2->getPreco(), $auto3->getPreco(), $auto4->getPreco());
            $preco1 = substr($auto1->getPreco(), 3,15);
            $preco2 = substr($auto2->getPreco(), 3,15);
            $preco3 = substr($auto3->getPreco(), 3,15);
            $preco4 = substr($auto4->getPreco(), 3,15);
            ?>

            <th><i id="preco1" class="<?= ($preco1 == $melhorPreco) ? "large green checkmark icon" : "large red close icon"; ?>"></i><?= $auto1->getPreco(); ?> </th>
            <th><i id="preco2" class="<?= ($preco2 == $melhorPreco) ? "large green checkmark icon" : "large red close icon"; ?>"></i><?= $auto2->getPreco(); ?> </th>
            <th><i id="preco3" class="<?= ($preco3 == $melhorPreco) ? "large green checkmark icon" : "large red close icon"; ?>"></i><?= $auto3->getPreco(); ?> </th>
            <th><i id="preco4" class="<?= ($preco4 == $melhorPreco) ? "large green checkmark icon" : "large red close icon"; ?>"></i><?= $auto4->getPreco(); ?> </th>
        </tr>
        <tr>
            <th>Altura</th>

            <?php $melhorAlt = altura($auto1->getAltura(), $auto2->getAltura(), $auto3->getAltura(), $auto4->getAltura());
            $alt1 = substr($auto1->getAltura(), 0,4);
            $alt2 = substr($auto2->getAltura(), 0,4);
            $alt3 = substr($auto3->getAltura(), 0,4);
            $alt4 = substr($auto4->getAltura(), 0,4);
            ?>

            <th><i id="alt1" class="<?= ($alt1 == $melhorAlt) ? "large green checkmark icon" : "large red close icon"; ?>"></i><?= $auto1->getAltura(); ?> </th>
            <th><i id="alt2" class="<?= ($alt2 == $melhorAlt) ? "large green checkmark icon" : "large red close icon"; ?>"></i><?= $auto2->getAltura(); ?> </th>
            <th><i id="alt3" class="<?= ($alt3 == $melhorAlt) ? "large green checkmark icon" : "large red close icon"; ?>"></i><?= $auto3->getAltura(); ?> </th>
            <th><i id="alt4" class="<?= ($alt4 == $melhorAlt) ? "large green checkmark icon" : "large red close icon"; ?>"></i><?= $auto4->getAltura(); ?> </th>
        </tr>
        <tr>


            <th>Comprimento</th>

            <?php $melhorCom = comprimento($auto1->getComprimento(), $auto2->getComprimento(), $auto3->getComprimento(), $auto4->getComprimento());
            $com1 = substr($auto1->getComprimento(), 0,4);
            $com2 = substr($auto2->getComprimento(), 0,4);
            $com3 = substr($auto3->getComprimento(), 0,4);
            $com4 = substr($auto4->getComprimento(), 0,4);
            ?>

            <th><i id="com1" class="<?= ($com1 == $melhorCom) ? "large green checkmark icon" : "large red close icon"; ?>"></i><?= $auto1->getComprimento(); ?> </th>
            <th><i id="com2" class="<?= ($com2 == $melhorCom) ? "large green checkmark icon" : "large red close icon"; ?>"></i><?= $auto2->getComprimento(); ?> </th>
            <th><i id="com3" class="<?= ($com3 == $melhorCom) ? "large green checkmark icon" : "large red close icon"; ?>"></i><?= $auto3->getComprimento(); ?> </th>
            <th><i id="com4" class="<?= ($com4 == $melhorCom) ? "large green checkmark icon" : "large red close icon"; ?>"></i><?= $auto4->getComprimento(); ?> </th>
        </tr>
        <tr>


            <th>Largura</th>

            <?php $melhorLar = largura($auto1->getLargura(), $auto2->getLargura(), $auto3->getLargura(), $auto4->getLargura());
            $lar1 = substr($auto1->getLargura(), 0,4);
            $lar2 = substr($auto2->getLargura(), 0,4);
            $lar3 = substr($auto3->getLargura(), 0,4);
            $lar4 = substr($auto4->getLargura(), 0,4);
            ?>

            <th><i id="lar1" class="<?= ($lar1 == $melhorLar) ? "large green checkmark icon" : "large red close icon"; ?>"></i><?= $auto1->getLargura(); ?> </th>
            <th><i id="lar2" class="<?= ($lar2 == $melhorLar) ? "large green checkmark icon" : "large red close icon"; ?>"></i><?= $auto2->getLargura(); ?> </th>
            <th><i id="lar3" class="<?= ($lar3 == $melhorLar) ? "large green checkmark icon" : "large red close icon"; ?>"></i><?= $auto3->getLargura(); ?> </th>
            <th><i id="lar4" class="<?= ($lar4 == $melhorLar) ? "large green checkmark icon" : "large red close icon"; ?>"></i><?= $auto4->getLargura(); ?> </th>
        </tr>
        <tr>


            <th>Câmbio</th>

            <?php $melhorLar = largura($auto1->getLargura(), $auto2->getLargura(), $auto3->getLargura(), $auto4->getLargura());
            $lar1 = substr($auto1->getLargura(), 0,4);
            $lar2 = substr($auto2->getLargura(), 0,4);
            $lar3 = substr($auto3->getLargura(), 0,4);
            $lar4 = substr($auto4->getLargura(), 0,4);
            ?>

            <th><i id="cam1" class=""></i><?= $auto1->getCambio(); ?></th>
            <th><i id="cam2" class=""></i><?= $auto2->getCambio(); ?> </th>
            <th><i id="cam3" class=""></i><?= $auto3->getCambio(); ?> </th>
            <th><i id="cam4" class=""></i><?= $auto4->getCambio(); ?> </th>
        </tr>
        <tr>
            <th>velocidade</th>
            <th><?= $auto1->getVelocidade(); ?> <i class="large green checkmark icon"></i></th>
            <th><?= $auto2->getVelocidade(); ?> <i class="large red close icon"></i></th>
            <th><?= $auto3->getVelocidade(); ?> <i class="large red close icon"></i></th>
            <th><?= $auto4->getVelocidade(); ?> <i class="large red close icon"></i></th>
        </tr>
        <tr>
            <th>tanque combustivel</th>
            <th><?= $auto1->getTanqueCombustivel(); ?> <i class="large green checkmark icon"></i></th>
            <th><?= $auto2->getTanqueCombustivel(); ?> <i class="large red close icon"></i></th>
            <th><?= $auto3->getTanqueCombustivel(); ?> <i class="large red close icon"></i></th>
            <th><?= $auto4->getTanqueCombustivel(); ?> <i class="large red close icon"></i></th>
        </tr>
        <tr>
            <th>Tipo combustivel</th>
            <th><?= $auto1->getTipCombustivel(); ?> <i class="large green checkmark icon"></i></th>
            <th><?= $auto2->getTipCombustivel(); ?> <i class="large red close icon"></i></th>
            <th><?= $auto3->getTipCombustivel(); ?> <i class="large red close icon"></i></th>
            <th><?= $auto4->getTipCombustivel(); ?> <i class="large red close icon"></i></th>
        </tr>
        <tr>
            <th>porta malas</th>
            <th><?= $auto1->getPortaMalas(); ?> <i class="large green checkmark icon"></i></th>
            <th><?= $auto2->getPortaMalas(); ?> <i class="large red close icon"></i></th>
            <th><?= $auto3->getPortaMalas(); ?> <i class="large red close icon"></i></th>
            <th><?= $auto4->getPortaMalas(); ?> <i class="large red close icon"></i></th>
        </tr>
        <tr>
            <th>tipo de direção</th>
            <th><?= $auto1->getTipDirecao(); ?> <i class="large green checkmark icon"></i></th>
            <th><?= $auto2->getTipDirecao(); ?> <i class="large red close icon"></i></th>
            <th><?= $auto3->getTipDirecao(); ?> <i class="large red close icon"></i></th>
            <th><?= $auto4->getTipDirecao(); ?> <i class="large red close icon"></i></th>
        </tr>
        <tr>
            <th>consumo urbano</th>
            <th><?= $auto1->getConsumoUrb(); ?> <i class="large green checkmark icon"></i></th>
            <th><?= $auto2->getConsumoUrb(); ?> <i class="large red close icon"></i></th>
            <th><?= $auto3->getConsumoUrb(); ?> <i class="large red close icon"></i></th>
            <th><?= $auto4->getConsumoUrb(); ?> <i class="large red close icon"></i></th>
        </tr>
        <tr>
            <th>consumo rodoviario</th>
            <th><?= $auto1->getConsumoRod(); ?> <i class="large green checkmark icon"></i></th>
            <th><?= $auto2->getConsumoRod(); ?> <i class="large red close icon"></i></th>
            <th><?= $auto3->getConsumoRod(); ?> <i class="large red close icon"></i></th>
            <th><?= $auto4->getConsumoRod(); ?> <i class="large red close icon"></i></th>
        </tr>
        <tr>
            <th>marcha</th>
            <th><?= $auto1->getMarcha(); ?> <i class="large green checkmark icon"></i></th>
            <th><?= $auto2->getMarcha(); ?> <i class="large red close icon"></i></th>
            <th><?= $auto3->getMarcha(); ?> <i class="large red close icon"></i></th>
            <th><?= $auto4->getMarcha(); ?> <i class="large red close icon"></i></th>
        </tr>
        <tr>
            <th>tipo de tração</th>
            <th><?= $auto1->getTipTracao(); ?> <i class="large green checkmark icon"></i></th>
            <th><?= $auto2->getTipTracao(); ?> <i class="large red close icon"></i></th>
            <th><?= $auto3->getTipTracao(); ?> <i class="large red close icon"></i></th>
            <th><?= $auto4->getTipTracao(); ?> <i class="large red close icon"></i></th>
        </tr>
        <tr>
            <th>porte</th>
            <th><?= $auto1->getPorte(); ?> <i class="large green checkmark icon"></i></th>
            <th><?= $auto2->getPorte(); ?> <i class="large red close icon"></i></th>
            <th><?= $auto3->getPorte(); ?><i class="large red close icon"></i></th>
            <th><?= $auto4->getPorte(); ?> <i class="large red close icon"></i></th>
        </tr>
        <tr>
            <th>ocupantes</th>
            <th><?= $auto1->getOcupantes(); ?> <i class="large green checkmark icon"></i></th>
            <th><?= $auto2->getOcupantes(); ?> <i class="large red close icon"></i></th>
            <th><?= $auto3->getOcupantes(); ?> <i class="large red close icon"></i></th>
            <th><?= $auto4->getOcupantes(); ?> <i class="large red close icon"></i></th>
        </tr>
        <tr>
            <th>tipo de freio</th>
            <th><?= $auto1->getTipFreio(); ?> <i class="large green checkmark icon"></i></th>
            <th><?= $auto2->getTipFreio(); ?> <i class="large red close icon"></i></th>
            <th><?= $auto3->getTipFreio(); ?> <i class="large red close icon"></i></th>
            <th><?= $auto4->getTipFreio(); ?> <i class="large red close icon"></i></th>
        </tr>
        <tr>
            <th>tipo do veiculo</th>
            <th><?= $auto1->getTipVeiculo(); ?> <i class="large green checkmark icon"></i></th>
            <th><?= $auto2->getTipVeiculo(); ?> <i class="large red close icon"></i></th>
            <th><?= $auto3->getTipVeiculo(); ?> <i class="large red close icon"></i></th>
            <th><?= $auto4->getTipVeiculo(); ?> <i class="large red close icon"></i></th>
        </tr>
        </thead>
    </table>
</div>
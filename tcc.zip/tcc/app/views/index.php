<?php
session_start();
?>
<!DOCTYPE html>
<html>
<head>
    <title>Página Inicial</title>
    <link rel="shortut icon" href="../../assets/images/Vs_black.png" type="image/x-icon">
    <meta charset="utf-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge,chrome=1">
    <meta name="viewport" content="width=device-width, initial-scale=1.0, maximum-scale=1.0">
    <link rel="stylesheet" type="text/css" href="../../node_modules/semantic-ui/dist/semantic.min.css">
    <link rel="stylesheet" type="text/css" href="../../assets/css/menu.css">
	<script
  		src="https://code.jquery.com/jquery-3.1.1.min.js"
  		integrity="sha256-hVVnYaiADRTO2PzUGmuLJr8BLUSjGIZsDYGmIJLv2b8="
  		crossorigin="anonymous"></script>
	<script src="../../node_modules/semantic-ui/dist/semantic.min.js"></script>
    <script src="../../assets/java%20script/select.js"></script>
    <style type="text/css">
    	@media only screen and (max-width: 700px) {
    		.ui.fixed.menu {
    			display: none !important;
    		}
    	}
    </style>
</head>
<body>
<div class="ui massive attached stackable container top menu">
    <div class="item left floated">
        <h1>VERSUS</h1>
    </div>            
                <a class="item bg" href="?action=index">Início</a>
            <?php
                if (!isset($_SESSION['logado'])){?>
                    <a class="item bg" href="?actioni=login">Logar</a>
                    <a class="item bg" href="?actioni=cadastrar">Cadastrar</a>
            <?php } ?>
                    <a class="item bg" href="?actioni=sobre&user=<?php if(isset($_SESSION['logado'])) { echo $_SESSION['nome'];}else{'nada';} ?>">Sobre e Contatos</a>
            <?php
                if (isset($_SESSION['logado'])){?>
<!--                <a class="item" href="#">Perfil</a>-->
                    <a class="item bg" href="?actioni=comentario&user=<?php if(isset($_SESSION['logado'])) { echo $_SESSION['nome'];}else{'nada';} ?>"">Comentários</a>
                    <a class="item bg" href="?action=sair">Sair</a>
            <?php
            if (isset($_SESSION['logado']) and isset($_SESSION['tipo'])){?>
                <a class="item bg" href="?action=listausuario">Admin</a>
            <?php }
             } ?>
    </div>
<br>
<br>
<?php
if (!isset($_SESSION['logado']) and isset($_GET['actioni']) and $_GET['actioni'] == 'login') {
    include_once "../views/form/login.php";
}elseif (!isset($_SESSION['logado']) and isset($_GET['actioni']) and $_GET['actioni'] == 'cadastrar'){
    include_once "../views/form/cadastro.php";
}elseif (isset($_GET['actioni']) and $_GET['actioni'] == 'sobre') {
    include_once "../views/tab/about us.php";
}elseif (isset($_GET['actioni']) and $_GET['actioni'] == 'comentario') {
    include_once "../views/tab/comment.php";
}elseif (!isset($_GET['actioni'])) {
    include_once "../views/form/select.php";
} ?>
<div<?php include_once "../views/template/rodape.php";?><div></div>
</body>
</html>
<div class="ui large menu">
    <h3 style="color: #f40612" class="item header">VERSUS</h3>
    <a id="jo" class="item">Cadastrar</a>
    <a id="jo" class="item">Login</a>
    <a id="jo" class="item">Sobre</a>
</div>
<?php
/**
 * Created by PhpStorm.
 * User: aluno
 * Date: 15/05/18
 * Time: 13:21
 */

require '../models/DBConexao.php';

$x = DBConexao::getConexao();


// $todasMarcas = file_get_contents("http://fipeapi.appspot.com/api/1/carros/marcas.json");
// $todasMarcas = json_decode($todasMarcas, true);


// foreach ($todasMarcas as $marca) {
// 	$idMarca = $marca['id'];
// 	$nome = $marca['fipe_name'];

// 	$x->exec("INSERT INTO montadora (idmontadora, nome_montadora) VALUES ($idMarca, '$nome')");
// }

// $y = $_GET['marca'];
// // echo "SELECT * FROM montadora WHERE 'nome_montadora'=$y;";
// $dados = $x->query("SELECT * FROM montadora WHERE nome_montadora='$y'")->fetchAll(PDO::FETCH_ASSOC);

// print_r($dados);

// echo json_encode($dados);




$idMarca = $_POST['marca'];
$idModelo = $_POST['modelo'];
$idAno = $_POST['ano'];


//marca
$marcas = file_get_contents("http://fipeapi.appspot.com/api/1/carros/veiculos/$idMarca.json");

$marcas = json_decode($marcas, true);
echo '<pre>'
print_r($marcas[0]['fipe_marca']
'</pre>';
echo '<pre>';
print_r($marcas[0]['fipe_name']);
echo '</pre>';

//modelo
$modelos = file_get_contents("http://fipeapi.appspot.com/api/1/carros/veiculo/$idMarca/$idModelo.json");
$modelos = json_decode($modelos, true);
echo '<pre>';
print_r($modelos[0]['name']);
echo '</pre>';

<?php
/**
 * Created by PhpStorm.
 * User: aluno
 * Date: 15/05/18
 * Time: 13:21
 */
$marca = $_POST['marca'];
echo "A marca é $marca";
?>
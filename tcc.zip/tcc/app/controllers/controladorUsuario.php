<?php

    require_once '../models/CrudUsuario.php';
    require_once 'funcoes/sessao.php';

    session_start();

    if (isset($_GET['acao'])){
        $acao = $_GET['acao'];
    }else{
        $acao = 'index';
    }
    switch ($acao){

        case 'index':
            include_once "../views/Template/cabecalho.php";
            include_once "../views/Pagina principal/index.php";
            include_once "../views/Template/rodape.php";
            break;

        case 'cadastrar':
            if (isset($_POST['nome']) and isset($_POST['email']) and isset($_POST['senha'])){
                $user = new Usuario($_POST['nome'], $_POST['email'], $_POST['senha'], 'comum');
                $usercrud = new CrudUsuario();
                if($usercrud->existeUser($user)!= 1) {
                    $usercrud->insertUsuario($user);
                    header('location: ?acaoi=login');
                }else{
                    header('location: ?acaoi=cadastrar&erro=2');
                }
            }else{
                header('location: ?acaoi=cadastrar&erro=1');
            }
            break;

        case 'login':
            if(isset($_POST['email']) and isset($_POST['senha'])) {
            $user = new Usuario(null, $_POST['email'], $_POST['senha'], null);
            $usercrud = new CrudUsuario();
            if ($usercrud->loginUser($user) == 1){
                $_SESSION['logado'] = true;
                $_SESSION['id'] = $usercrud->descobreId($user);
                switch ($usercrud->verificaTipo($user)) {
                    case 'comum':
                        header('location: ?acao=index&id='.$_SESSION['id']);
                    break;

                    case 'admin':
                        $_SESSION['admin'] = true;
                        header('location: ?acao=index&id='.$_SESSION['id']);
                    break;
                }
            } else {
                header('location: ?acaoi=login&erro=1');
            }
            }
        break;

        case 'logout':
            session_destroy();
            header('location: ?acao=index');
        break;

        case 'comentar':

        break;
    }
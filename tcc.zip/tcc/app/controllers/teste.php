<?php

$teste1 = $_SESSION['id'];
$teste = $_POST['comentario_campo'];

echo $teste;
echo $teste1;
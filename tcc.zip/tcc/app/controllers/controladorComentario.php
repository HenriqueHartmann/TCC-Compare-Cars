<?php

    if (isset($_GET['action'])){
        $action = $_GET['action'];
    }else{
        $action = 'index';
    }

    switch ($action){

        case 'index':
            include_once "../views/index.php";
        break;

        case 'comentario':
            $coment = new CrudComentario();
            $coment->insertComentario();
    }
<?php

        require_once "../models/CrudUsuario.php";
        require_once "../models/CrudVeiculo.php";
        require_once "funcoes/sessao.php";

        session_start();

        if (esta_logado() and e_admin()) {
            if (isset($_GET['acao'])) {
                $acao = $_GET['acao'];
            } else {
                $acao = 'decisao';
            }

            switch ($acao) {
                case 'decisao':
                    include_once "../views/Template/cabecalhoAdmin.php";
                    include_once "../views/Admin/decisao.php";
                    break;

                case 'lista':
                    $crud = new CrudUsuario();
                    $usuarios = $crud->getUsuarios();
                    include_once "../views/Template/cabecalhoAdmin.php";
                    include_once '../views/Admin/decisao.php';
                    include_once "../views/Admin/lista.php";
                    break;

                case 'cadastro':
                    include_once "../views/Template/cabecalhoAdmin.php";
                    include_once "../views/Admin/decisao.php";
                    include_once "../views/Admin/cadastraadmin.php";
                    break;

                case 'cadastraadmin':
                    $user = new Usuario($_POST['nome'], $_POST['email'], $_POST['senha'], $_POST['tipo']);
                    $usercrud = new CrudUsuario();
                    $usercrud->insertUsuario($user);
                    header('location: ?acao=lista');
                    break;

                case 'editar':
                    $usercrud = new CrudUsuario();
                    $codigo = $_GET['codigo'];
                    $usuario = $usercrud->getUsuario($codigo);
                    include_once "../views/Template/cabecalhoAdmin.php";
                    include_once "../views/Admin/decisao.php";
                    include_once "../views/Admin/editaruser.php";
                    break;

                case 'update':
                    $usercrud = new CrudUsuario();
                    $codigo = $_GET['codigo'];
                    $user = new Usuario($_POST['nome'], $_POST['email'], $_POST['senha'], $_POST['tipo'], $codigo);
                    $usercrud->updateUsuario($user);
                    header('location: ?acao=lista');
                    break;

                case 'excluir':
                    $codigo = $_GET['codigo'];
                    $usercrud = new CrudUsuario();
                    $usercrud->excluirUsuario($codigo);
                    header('location: ?acao=lista');
                    break;
            }
        }else{
            if(esta_logado()) {
                session_destroy();
            }
            header('location: controladorUsuario.php');
        }
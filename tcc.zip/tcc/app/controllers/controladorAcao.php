<?php
/**
 * Created by PhpStorm.
 * User: Henrique Hartmann
 * Date: 02/04/2018
 * Time: 20:08
 */
require_once '../models/CrudUsuario.php';

if (isset($_GET['acao']) and $_GET['acao'] == 'cadastrar')
{
    $user = new Usuario($_POST['nome'], $_POST['email'], $_POST['senha'], 'comum');

    $usercrud = new CrudUsuario();

    $usercrud->insertUsuario($user);

    header('location: ../../index.php?acao=login');
}
elseif (isset($_GET['acao']) and $_GET['acao'] == 'login' and isset($_POST['nome']) and isset($_POST['senha'])) {
    $user = new Usuario($_POST['nome'], '@gmail.com', $_POST['senha']);

    $usercrud = new CrudUsuario();

//    $usercrud->loginUser($user);

    if ($usercrud->loginUser($user) == 1){
        session_start();
        $_SESSION['logado'] = 'sim';
        switch ($usercrud->verificaTipo($user)) {

            case 'comum':
                header('location: ../../index.php');
                break;

            case 'admin':
                $_SESSION['tipo'] = 'admin';
                header('location: ../../index.php');
                break;
        }
    } else {
        header('location: ../../index.php?acao=login&erro=1');
    }
}
elseif (isset($_GET['acao']) and $_GET['acao'] == 'sair')
{
    session_start();

    session_destroy();

    header('location:../../index.php');
}
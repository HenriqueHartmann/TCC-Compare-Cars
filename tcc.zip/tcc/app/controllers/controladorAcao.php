<?php
/**
 * Created by PhpStorm.
 * User: Henrique Hartmann
 * Date: 02/04/2018
 * Time: 20:08
 */
require_once '../models/CrudUsuario.php';

if (isset($_GET['action'])){
    $action = $_GET['action'];
}else{
    $action = 'index';
}
    switch ($action){

        case 'index':
            $crud = new CrudUsuario();
            $usuarios = $crud->getUsuarios();
            require_once "../views/tabela/userlist.php";
break;

        case 'cadastrar':
            $user = new Usuario($_POST['nome'], $_POST['email'], $_POST['senha'], 'comum');
            $usercrud = new CrudUsuario();
            $usercrud->insertUsuario($user);
                header('location: ../../index.php?action=login');
break;

        case 'adcadastrar':
            $user = new Usuario($_POST['nome'], $_POST['email'], $_POST['senha'], $_POST['tipo']);
            $usercrud = new CrudUsuario();
            $usercrud->insertUsuario($user);
            header('location: ?action=index');

break;

        case 'editar':
            $usercrud = new CrudUsuario();
            $codigo = $_GET['codigo'];

            if(!isset($_POST['gravar'])){//ainda nao preencheu o formulario
                $usuario = $usercrud->getUsuario($codigo);
                include "../views/form/editaruser.php";

            }else{
                $user = new Usuario( $_POST['nome'], $_POST['email'], $_POST['senha'], $_POST['tipo'], $codigo);
                $usercrud->updateUsuario($user);
                header('location: controladorAcao.php?action=index');

            }

break;

        case 'excluir':
            $codigo = $_GET['codigo'];
            $usercrud = new CrudUsuario();
            $usercrud->excluirUsuario($codigo);
            header('location: controladorAcao.php?action=index');
break;

        case 'login':

            if(isset($_POST['nome']) and isset($_POST['senha'])) {
            $user = new Usuario($_POST['nome'], '@gmail.com', $_POST['senha']);
            $usercrud = new CrudUsuario();
            if ($usercrud->loginUser($user) == 1){
                session_start();
                $_SESSION['logado'] = 'sim';
            switch ($usercrud->verificaTipo($user)) {
                case 'comum':
                    header('location: ../../index.php');
                break;

                case 'admin':
                    $_SESSION['tipo'] = 'admin';
                    header('location: ../../index.php');
                break;
            }
            } else {
                    header('location: ../../index.php?action=login&erro=1');
            }
            }
break;

        case 'sair':
            session_start();
            session_destroy();
            header('location:../../index.php');
break;
}
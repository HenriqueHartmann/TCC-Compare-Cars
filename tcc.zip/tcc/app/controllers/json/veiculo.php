<?php

// Conectando
require_once '../../models/DBConexao.php';

$con = new DBConexao();
$res = $con->getConexao();

// Executando consulta SQL
$query = 'SELECT * FROM veiculo WHERE idcarro =1';
$resultado = $res->query($query)->fetchAll(PDO::FETCH_ASSOC);
$json = json_encode($resultado, JSON_PRETTY_PRINT);
echo "$json";
//foreach ($resultado as $r) {


//}

<?php

// Conectando
require_once '../../models/DBConexao.php';

$con = new DBConexao();
$res = $con->getConexao();

// Executando consulta SQL
$query = 'SELECT * FROM veiculo WHERE idcarro =1';
$resultado = $res->query($query)->fetchAll(PDO::FETCH_ASSOC);
utf8_encode($resultado);
$json = json_encode($resultado, JSON_PRETTY_PRINT, JSON_UNESCAPED_SLASHES | JSON_UNESCAPED_UNICODE);
echo "$json";
//foreach ($resultado as $r) {


//}

<!--[-->
<!--    {-->
<!--        "idcarro": "",-->
<!--        "potencia": "",-->
<!--        "portas": "",-->
<!--        "preco": "",-->
<!--        "altura": "",-->
<!--        "comprimento": "",-->
<!--        "largura": "",-->
<!--        "cambio": "",-->
<!--        "velocidade": "",-->
<!--        "tanque_combustivel": "",-->
<!--        "tip_combustivel": "",-->
<!--        "porta_malas": "",-->
<!--        "tip_direcao": "",-->
<!--        "consumo_urb": "",-->
<!--        "consumo_rod": "",-->
<!--        "marcha": "",-->
<!--        "tip_tracao": "",-->
<!--        "porte": "",-->
<!--        "ocupantes": "",-->
<!--        "tip_freio": "",-->
<!--        "tip_veiculo": "",-->
<!---->
<!--    }-->
<!--]-->
<?php

// Conectando
require_once '../../models/DBConexao.php';

$con = new DBConexao();
$con->getConexao();

// Executando consulta SQL
$query = 'SELECT * FROM veiculo';


$json = json_encode($result);
echo "$json";
?>
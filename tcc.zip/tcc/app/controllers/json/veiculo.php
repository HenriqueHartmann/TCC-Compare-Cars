<?php

// Conectando
require_once '../../models/DBConexao.php';

$con = new DBConexao();
$res = $con->getConexao();

// Executando consulta SQL
$query = 'SELECT * FROM veiculo';
$resultado = $res->query($query)->fetchAll(PDO::FETCH_ASSOC);

foreach ($resultado as $r) {
    $jr = json_encode($r);
    echo "$jr";
}
echo "$jr";

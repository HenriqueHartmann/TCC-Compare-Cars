<?php
    require_once "../models/CrudVeiculo.php";
    require_once "../models/CrudUsuario.php";
    require_once "comparação/comp.php";

    session_start()
?>
<!DOCTYPE html>
<html>
<head>
    <title>Página Inicial</title>
    <meta charset="utf-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge,chrome=1">
    <meta name="viewport" content="width=device-width, initial-scale=1.0, maximum-scale=1.0">
    <link rel="stylesheet" type="text/css" href="../../node_modules/semantic-ui/dist/semantic.min.css">
    <link rel="stylesheet" type="text/css" href="../../assets/css/comp.css">
    <script
        src="https://code.jquery.com/jquery-3.1.1.min.js"
        integrity="sha256-hVVnYaiADRTO2PzUGmuLJr8BLUSjGIZsDYGmIJLv2b8="
        crossorigin="anonymous"></script>
    <script src="../../node_modules/semantic-ui/dist/semantic.min.js"></script>
    <style type="text/css">
        @media only screen and (max-width: 700px) {
            .ui.fixed.menu {
                display: none !important;
            }
        }
    </style>
</head>
<body>

<div class="ui massive attached stackable container top menu">
    <div class="item left floated">
        <h1 style="color: #fff">VERSUS X</h1>
    </div>
    <a class="item" href="controladorAcao.php?action=index">Início</a>
    <?php
    if (!isset($_SESSION['logado'])){?>
        <a class="item" href="?actioni=login">Logar</a>
        <a class="item" href="?actioni=cadastrar">Cadastrar</a>
    <?php }
    ?>
    <?php
    if (isset($_SESSION['logado'])){?>
        <a class="item" href="controladorAcao.php?action=index&actioni=comment">Comentários</a>
        <a class="item" href="controladorAcao.php?action=sair">Sair</a>
    <?php } ?>
</div>

<?php
if (!isset($_SESSION['logado']) and isset($_GET['actioni']) and $_GET['actioni'] == 'login') {
    header('location: controladorAcao.php?action=index&actioni=login');
}elseif (!isset($_SESSION['logado']) and isset($_GET['actioni']) and $_GET['actioni'] == 'cadastrar'){
    header('location: controladorAcao.php?action=index&actioni=cadastrar');
}elseif (isset($_GET['actioni']) and $_GET['actioni'] == 'sobre') {
    header('location: controladorAcao.php?action=index&actioni=sobre');
}elseif (isset($_GET['actioni']) and $_GET['actioni'] == 'comment') {
    header('location: controladorAcao.php?action=index&actioni=comment');
} ?>
<div id="tabela">
    <?php

    $crudauto = new CrudVeiculo();

    //CARRO-1
    if ((isset($_POST['marca'])) and (isset($_POST['modelo'])) and
        (isset($_POST['ano'])) and ($_POST['marca']!='Selecione...') and
        ($_POST['modelo']) and ($_POST['ano'])) {
        $idMarca = $_POST['marca'];
        $idModelo = $_POST['modelo'];
        $idAno = $_POST['ano'];
        $anos = file_get_contents("http://fipeapi.appspot.com/api/1/carros/veiculo/$idMarca/$idModelo/$idAno.json");
        $anos = json_decode($anos, true);
        $auto1 = $crudauto->getModelAno($idMarca, $idModelo, $anos['ano_modelo']);
//        echo "<p style='color:red;'>Carro1</p>";
//        echo "montadora :$idMarca\n";
//        echo "modelo    :$idModelo\n";
//        echo "ano       :".$anos['ano_modelo']."\n";

    }else{
//        echo "<p style='color:red;'>Carro-1 não selecionado</p>";
        $auto1 = new Veiculo();
    }
    //END CARRO-1

    //CARRO-2
    if ((isset($_POST['marca1'])) and (isset($_POST['modelo1'])) and
        (isset($_POST['ano1'])) and ($_POST['marca1']!='Selecione...') and
        ($_POST['modelo1']) and ($_POST['ano1'])) {
        $idMarca1 = $_POST['marca1'];
        $idModelo1 = $_POST['modelo1'];
        $idAno1 = $_POST['ano1'];
        $anos1 = file_get_contents("http://fipeapi.appspot.com/api/1/carros/veiculo/$idMarca1/$idModelo1/$idAno1.json");
        $anos1 = json_decode($anos1, true);
        $auto2 = $crudauto->getModelAno($idMarca1, $idModelo1, $anos1['ano_modelo']);
//        echo "<p style='color:black;'>Carro2</p>";
//        echo "montadora :$idMarca1\n";
//        echo "modelo    :$idModelo1\n";
//        echo "ano       :".$anos1['ano_modelo']."\n";
    }else {
//        echo "<p style='color:black;'>Carro-2 não selecionado</p>";
        $auto2 = new Veiculo();
    }
    //END CARRO-2

    //CARRO-3
    if ((isset($_POST['marca2'])) and (isset($_POST['modelo2'])) and
        (isset($_POST['ano2'])) and ($_POST['marca2']!='Selecione...') and
        ($_POST['modelo2']) and ($_POST['ano2'])) {
        $idMarca2 = $_POST['marca2'];
        $idModelo2 = $_POST['modelo2'];
        $idAno2 = $_POST['ano2'];
        $anos2 = file_get_contents("http://fipeapi.appspot.com/api/1/carros/veiculo/$idMarca2/$idModelo2/$idAno2.json");
        $anos2 = json_decode($anos2, true);
        $auto3 = $crudauto->getModelAno($idMarca2, $idModelo2, $anos2['ano_modelo']);
//        echo "<p style='color:green;'>Carro3</p>";
//        echo "montadora :$idMarca2\n";
//        echo "modelo    :$idModelo2\n";
//        echo "ano       :".$anos2['ano_modelo']."\n";

    }else {
//        echo "<p style='color:green;'>Carro-3 não selecionado</p>";
        $auto3 = new Veiculo();
    }
    //END CARRO-3

    //CARRO-4
    if ((isset($_POST['marca3'])) and (isset($_POST['modelo3'])) and
        (isset($_POST['ano3'])) and ($_POST['marca3']!='Selecione...') and
        ($_POST['modelo3']) and ($_POST['ano3'])) {
        $idMarca3 = $_POST['marca3'];
        $idModelo3 = $_POST['modelo3'];
        $idAno3 = $_POST['ano3'];
        $anos3 = file_get_contents("http://fipeapi.appspot.com/api/1/carros/veiculo/$idMarca3/$idModelo3/$idAno3.json");
        $anos3 = json_decode($anos3, true);
        $auto4 = $crudauto->getModelAno($idMarca3, $idModelo3, $anos3['ano_modelo']);
//        echo "<p style='color:blue;'>Carro4</p>";
//        echo "montadora :$idMarca3\n";
//        echo "modelo    :$idModelo3\n";
//        echo "ano       :".$anos3['ano_modelo']."\n";

    }else {
//        echo "<p style='color:blue;'>Carro-4 não selecionado</p>";
        $auto4 = new Veiculo();
    }
    //END CARRO-4

//        print_r($auto1);
//            echo "<h1>Correto</h1>";

    ?>
    <table class="ui small green table">
        <thead>
        <tr>
            <th>nº Carro </th>
            <th>Carro1</th>
            <th>Carro2</th>
            <th>Carro3</th>
            <th>Carro4</th>
        </tr>
        <tr>
            <th>id</th>
            <th><?= $auto1->getIdveiculo(); ?></th>
            <th><?= $auto2->getIdveiculo(); ?></th>
            <th><?= $auto3->getIdveiculo(); ?></th>
            <th><?= $auto4->getIdveiculo(); ?></th>
        </tr>
        <tr>

<!--            ANO-->
            <th>ano</th>
            <?php $melhorAno = ano($auto1->getAno(), $auto2->getAno(), $auto3->getAno(), $auto4->getAno());
            echo $melhorAno;
            if ($melhorAno == $auto1->getAno()){ ?>
                <script>
                    $(document).ready(function () {
                        $("#ano1").addClass("large green checkmark icon");
                    });
                </script>

            <?php }else{ ?>

                <script>
                    $(document).ready(function () {
                        $("#ano1").addClass("large red close icon");
                    });
                </script>

            <?php }

            if ($melhorAno == $auto2->getAno()){ ?>

                <script>
                    $(document).ready(function () {
                        $("#ano2").addClass("large green checkmark icon");
                    });
                </script>

            <?php }else{ ?>

                <script>
                    $(document).ready(function () {
                        $("#ano2").addClass("large red close icon");
                    });
                </script>

            <?php }

            if ($melhorAno == $auto3->getAno()){ ?>

                <script>
                    $(document).ready(function () {
                        $("#ano3").addClass("large green checkmark icon");
                    });
                </script>

            <?php }else{ ?>

                <script>
                    $(document).ready(function () {
                        $("#ano3").addClass("large red close icon");
                    });
                </script>

            <?php }

            if ($melhorAno == $auto4->getAno()){ ?>

            <script>
                $(document).ready(function () {
                    $("#ano4").addClass("large green checkmark icon");
                });
            </script>

            <?php }else{ ?>

            <script>
                $(document).ready(function () {
                    $("#ano4").addClass("large red close icon");
                });
            </script>

            <?php } ?>

            <th><?= $auto1->getAno(); ?> <i id="ano1" class=""></i></th>
            <th><?= $auto2->getAno(); ?> <i id="ano2" class=""></i></th>
            <th><?= $auto3->getAno(); ?> <i id="ano3" class=""></i></th>
            <th><?= $auto4->getAno(); ?> <i id="ano4" class=""></i></th>
        </tr>
        <tr>


<!--           POTENCIA-->
            <th>potencia</th>

            <?php $melhorPot = potencia($auto1->getPotencia(), $auto2->getPotencia(), $auto3->getPotencia(), $auto4->getPotencia());

            if ($melhorPot == $auto1->getAno()){ ?>
                <script>
                    $(document).ready(function () {
                        $("#pot1").addClass("large green checkmark icon");
                    });
                </script>

            <?php }else{ ?>

                <script>
                    $(document).ready(function () {
                        $("#pot1").addClass("large red close icon");
                    });
                </script>

            <?php }

            if ($melhorPot == $auto2->getAno()){ ?>

                <script>
                    $(document).ready(function () {
                        $("#pot2").addClass("large green checkmark icon");
                    });
                </script>

            <?php }else{ ?>

                <script>
                    $(document).ready(function () {
                        $("#pot2").addClass("large red close icon");
                    });
                </script>

            <?php }

            if ($melhorPot == $auto3->getAno()){ ?>

                <script>
                    $(document).ready(function () {
                        $("#pot3").addClass("large green checkmark icon");
                    });
                </script>

            <?php }else{ ?>

                <script>
                    $(document).ready(function () {
                        $("#pot3").addClass("large red close icon");
                    });
                </script>

            <?php }

            if ($melhorPot == $auto4->getAno()){ ?>

                <script>
                    $(document).ready(function () {
                        $("#pot4").addClass("large green checkmark icon");
                    });
                </script>

            <?php }else{ ?>

            <script>
                $(document).ready(function () {
                    $("#pot4").addClass("large red close icon");
                });
            </script>

            <?php } ?>

            <th><?= $auto1->getPotencia(); ?> <i id="pot1" class=""></i></th>
            <th><?= $auto2->getPotencia(); ?> <i id="pot2" class=""></i></th>
            <th><?= $auto3->getPotencia(); ?> <i id="pot3" class=""></i></th>
            <th><?= $auto4->getPotencia(); ?> <i id="pot4" class=""></i></th>
        </tr>
        <tr>
            <th>portas</th>
            <th><?= $auto1->getPortas(); ?> <i class="large green checkmark icon"></i></th>
            <th><?= $auto2->getPortas(); ?> <i class="large red close icon"></i></th>
            <th><?= $auto3->getPortas(); ?> <i class="large red close icon"></i></th>
            <th><?= $auto4->getPortas(); ?> <i class="large red close icon"></i></th>
        </tr>
        <tr>
            <th>preco</th>
            <th><?= $auto1->getPreco(); ?> <i class="large green checkmark icon"></i></th>
            <th><?= $auto2->getPreco(); ?> <i class="large red close icon"></i></th>
            <th><?= $auto3->getPreco(); ?> <i class="large red close icon"></i></th>
            <th><?= $auto4->getPreco(); ?> <i class="large red close icon"></i></th>
        </tr>
        <tr>
            <th>altura</th>
            <th><?= $auto1->getAltura(); ?> <i class="large green checkmark icon"></i></th>
            <th><?= $auto2->getAltura(); ?> <i class="large red close icon"></i></th>
            <th><?= $auto3->getAltura(); ?> <i class="large red close icon"></i></th>
            <th><?= $auto4->getAltura(); ?> <i class="large red close icon"></i></th>
        </tr>
        <tr>
            <th>comprimento</th>
            <th><?= $auto1->getComprimento(); ?> <i class="large green checkmark icon"></i></th>
            <th><?= $auto2->getComprimento(); ?> <i class="large red close icon"></i></th>
            <th><?= $auto3->getComprimento(); ?> <i class="large red close icon"></i></th>
            <th><?= $auto4->getComprimento(); ?> <i class="large red close icon"></i></th>
        </tr>
        <tr>
            <th>largura</th>
            <th><?= $auto1->getLargura(); ?> <i class="large green checkmark icon"></i></th>
            <th><?= $auto2->getLargura(); ?> <i class="large red close icon"></i></th>
            <th><?= $auto3->getLargura(); ?> <i class="large red close icon"></i></th>
            <th><?= $auto4->getLargura(); ?> <i class="large red close icon"></i></th>
        </tr>
        <tr>
            <th>cambio</th>
            <th><?= $auto1->getCambio(); ?> <i class="large green checkmark icon"></i></th>
            <th><?= $auto2->getCambio(); ?> <i class="large red close icon"></i></th>
            <th><?= $auto3->getCambio(); ?> <i class="large red close icon"></i></th>
            <th><?= $auto4->getCambio(); ?> <i class="large red close icon"></i></th>
        </tr>
        <tr>
            <th>velocidade</th>
            <th><?= $auto1->getVelocidade(); ?> <i class="large green checkmark icon"></i></th>
            <th><?= $auto2->getVelocidade(); ?> <i class="large red close icon"></i></th>
            <th><?= $auto3->getVelocidade(); ?> <i class="large red close icon"></i></th>
            <th><?= $auto4->getVelocidade(); ?> <i class="large red close icon"></i></th>
        </tr>
        <tr>
            <th>tanque combustivel</th>
            <th><?= $auto1->getTanqueCombustivel(); ?> <i class="large green checkmark icon"></i></th>
            <th><?= $auto2->getTanqueCombustivel(); ?> <i class="large red close icon"></i></th>
            <th><?= $auto3->getTanqueCombustivel(); ?> <i class="large red close icon"></i></th>
            <th><?= $auto4->getTanqueCombustivel(); ?> <i class="large red close icon"></i></th>
        </tr>
        <tr>
            <th>Tipo combustivel</th>
            <th><?= $auto1->getTipCombustivel(); ?> <i class="large green checkmark icon"></i></th>
            <th><?= $auto2->getTipCombustivel(); ?> <i class="large red close icon"></i></th>
            <th><?= $auto3->getTipCombustivel(); ?> <i class="large red close icon"></i></th>
            <th><?= $auto4->getTipCombustivel(); ?> <i class="large red close icon"></i></th>
        </tr>
        <tr>
            <th>porta malas</th>
            <th><?= $auto1->getPortaMalas(); ?> <i class="large green checkmark icon"></i></th>
            <th><?= $auto2->getPortaMalas(); ?> <i class="large red close icon"></i></th>
            <th><?= $auto3->getPortaMalas(); ?> <i class="large red close icon"></i></th>
            <th><?= $auto4->getPortaMalas(); ?> <i class="large red close icon"></i></th>
        </tr>
        <tr>
            <th>tipo de direção</th>
            <th><?= $auto1->getTipDirecao(); ?> <i class="large green checkmark icon"></i></th>
            <th><?= $auto2->getTipDirecao(); ?> <i class="large red close icon"></i></th>
            <th><?= $auto3->getTipDirecao(); ?> <i class="large red close icon"></i></th>
            <th><?= $auto4->getTipDirecao(); ?> <i class="large red close icon"></i></th>
        </tr>
        <tr>
            <th>consumo urbano</th>
            <th><?= $auto1->getConsumoUrb(); ?> <i class="large green checkmark icon"></i></th>
            <th><?= $auto2->getConsumoUrb(); ?> <i class="large red close icon"></i></th>
            <th><?= $auto3->getConsumoUrb(); ?> <i class="large red close icon"></i></th>
            <th><?= $auto4->getConsumoUrb(); ?> <i class="large red close icon"></i></th>
        </tr>
        <tr>
            <th>consumo rodoviario</th>
            <th><?= $auto1->getConsumoRod(); ?> <i class="large green checkmark icon"></i></th>
            <th><?= $auto2->getConsumoRod(); ?> <i class="large red close icon"></i></th>
            <th><?= $auto3->getConsumoRod(); ?> <i class="large red close icon"></i></th>
            <th><?= $auto4->getConsumoRod(); ?> <i class="large red close icon"></i></th>
        </tr>
        <tr>
            <th>marcha</th>
            <th><?= $auto1->getMarcha(); ?> <i class="large green checkmark icon"></i></th>
            <th><?= $auto2->getMarcha(); ?> <i class="large red close icon"></i></th>
            <th><?= $auto3->getMarcha(); ?> <i class="large red close icon"></i></th>
            <th><?= $auto4->getMarcha(); ?> <i class="large red close icon"></i></th>
        </tr>
        <tr>
            <th>tipo de tração</th>
            <th><?= $auto1->getTipTracao(); ?> <i class="large green checkmark icon"></i></th>
            <th><?= $auto2->getTipTracao(); ?> <i class="large red close icon"></i></th>
            <th><?= $auto3->getTipTracao(); ?> <i class="large red close icon"></i></th>
            <th><?= $auto4->getTipTracao(); ?> <i class="large red close icon"></i></th>
        </tr>
        <tr>
            <th>porte</th>
            <th><?= $auto1->getPorte(); ?> <i class="large green checkmark icon"></i></th>
            <th><?= $auto2->getPorte(); ?> <i class="large red close icon"></i></th>
            <th><?= $auto3->getPorte(); ?><i class="large red close icon"></i></th>
            <th><?= $auto4->getPorte(); ?> <i class="large red close icon"></i></th>
        </tr>
        <tr>
            <th>ocupantes</th>
            <th><?= $auto1->getOcupantes(); ?> <i class="large green checkmark icon"></i></th>
            <th><?= $auto2->getOcupantes(); ?> <i class="large red close icon"></i></th>
            <th><?= $auto3->getOcupantes(); ?> <i class="large red close icon"></i></th>
            <th><?= $auto4->getOcupantes(); ?> <i class="large red close icon"></i></th>
        </tr>
        <tr>
            <th>tipo de freio</th>
            <th><?= $auto1->getTipFreio(); ?> <i class="large green checkmark icon"></i></th>
            <th><?= $auto2->getTipFreio(); ?> <i class="large red close icon"></i></th>
            <th><?= $auto3->getTipFreio(); ?> <i class="large red close icon"></i></th>
            <th><?= $auto4->getTipFreio(); ?> <i class="large red close icon"></i></th>
        </tr>
        <tr>
            <th>tipo do veiculo</th>
            <th><?= $auto1->getTipVeiculo(); ?> <i class="large green checkmark icon"></i></th>
            <th><?= $auto2->getTipVeiculo(); ?> <i class="large red close icon"></i></th>
            <th><?= $auto3->getTipVeiculo(); ?> <i class="large red close icon"></i></th>
            <th><?= $auto4->getTipVeiculo(); ?> <i class="large red close icon"></i></th>
        </tr>
        </thead>
    </table>
</div>
<?php include_once "../views/template/rodape.php";?>
</body>
</html>

<?php
    require_once "../models/CrudVeiculo.php";
    require_once "../models/CrudUsuario.php";
?>

<!DOCTYPE html>
<html>
<head>
    <title>Página Inicial</title>
    <meta charset="utf-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge,chrome=1">
    <meta name="viewport" content="width=device-width, initial-scale=1.0, maximum-scale=1.0">
    <link rel="stylesheet" type="text/css" href="../../node_modules/semantic-ui/dist/semantic.min.css">
    <script
        src="https://code.jquery.com/jquery-3.1.1.min.js"
        integrity="sha256-hVVnYaiADRTO2PzUGmuLJr8BLUSjGIZsDYGmIJLv2b8="
        crossorigin="anonymous"></script>
    <script src="../../node_modules/semantic-ui/dist/semantic.min.js"></script>
    <style type="text/css">
        @media only screen and (max-width: 700px) {
            .ui.fixed.menu {
                display: none !important;
            }
        }
    </style>
</head>
<body>
<div id="tabela">
    <?php
    $idMarca = $_POST['marca'];
    $idModelo = $_POST['modelo'];
    $idAno = $_POST['ano'];

    $anos = file_get_contents("http://fipeapi.appspot.com/api/1/carros/veiculo/$idMarca/$idModelo/$idAno.json");
    $anos = json_decode($anos, true);

        $crudauto = new CrudVeiculo();
        $auto1 = $crudauto->getModelAno($idMarca, $idModelo, $anos['ano_modelo']);

//        print_r($auto1);
//            echo "<h1>Correto</h1>";
            echo "montadora :$idMarca\n";
            echo "modelo    :$idModelo\n";
            echo "ano       :".$anos['ano_modelo']."\n";

//        }else {
//            echo "<h1>Incorreto</h1>";
//            echo "montadora :$idMarca\n";
//            echo "modelo    :$idModelo\n";
//            echo "ano       :".$anos['ano_modelo']."\n";
//        }
    ?>
    <table>
        <thead>
        <tr>
            <th>id</th>
            <th><?= $auto1->getIdveiculo(); ?></th>
        </tr>
        <tr>
            <th>ano</th>
            <th><?= $auto1->getAno(); ?></th>
        </tr>
        <tr>
            <th>potencia</th>
            <th><?= $auto1->getPotencia(); ?></th>
        </tr>
        <tr>
            <th>portas</th>
            <th><?= $auto1->getPortas(); ?></th>
        </tr>
        <tr>
            <th>preco</th>
            <th><?= $auto1->getPreco(); ?></th>
        </tr>
        <tr>
            <th>altura</th>
            <th><?= $auto1->getAltura(); ?></th>
        </tr>
        <tr>
            <th>comprimento</th>
            <th><?= $auto1->getComprimento(); ?></th>
        </tr>
        <tr>
            <th>largura</th>
            <th><?= $auto1->getLargura(); ?></th>
        </tr>
        <tr>
            <th>cambio</th>
            <th><?= $auto1->getCambio(); ?></th>
        </tr>
        <tr>
            <th>velocidade</th>
            <th><?= $auto1->getVelocidade(); ?></th>
        </tr>
        <tr>
            <th>tanque combustivel</th>
            <th><?= $auto1->getTanqueCombustivel(); ?></th>
        </tr>
        <tr>
            <th>Tipo combustivel</th>
            <th><?= $auto1->getTipCombustivel(); ?></th>
        </tr>
        <tr>
            <th>porta malas</th>
            <th><?= $auto1->getPortaMalas(); ?></th>
        </tr>
        <tr>
            <th>tipo de direção</th>
            <th><?= $auto1->getTipDirecao(); ?></th>
        </tr>
        <tr>
            <th>consumo urbano</th>
            <th><?= $auto1->getConsumoUrb(); ?></th>
        </tr>
        <tr>
            <th>consumo rodoviario</th>
            <th><?= $auto1->getConsumoRod(); ?></th>
        </tr>
        <tr>
            <th>marcha</th>
            <th><?= $auto1->getMarcha(); ?></th>
        </tr>
        <tr>
            <th>tipo de tração</th>
            <th><?= $auto1->getTipTracao(); ?></th>
        </tr>
        <tr>
            <th>porte</th>
            <th><?= $auto1->getPorte(); ?></th>
        </tr>
        <tr>
            <th>ocupantes</th>
            <th><?= $auto1->getOcupantes(); ?></th>
        </tr>
        <tr>
            <th>tipo de freio</th>
            <th><?= $auto1->getTipFreio(); ?></th>
        </tr>
        <tr>
            <th>tipo do veiculo</th>
            <th><?= $auto1->getTipVeiculo(); ?></th>
        </tr>
        </thead>
    </table>

</body>
</html>

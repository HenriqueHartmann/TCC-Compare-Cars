<?php
    require_once "../models/CrudVeiculo.php";
    require_once "../models/CrudUsuario.php";
?>

<!DOCTYPE html>
<html>
<head>
    <title>Página Inicial</title>
    <meta charset="utf-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge,chrome=1">
    <meta name="viewport" content="width=device-width, initial-scale=1.0, maximum-scale=1.0">
    <link rel="stylesheet" type="text/css" href="../../node_modules/semantic-ui/dist/semantic.min.css">
    <script
        src="https://code.jquery.com/jquery-3.1.1.min.js"
        integrity="sha256-hVVnYaiADRTO2PzUGmuLJr8BLUSjGIZsDYGmIJLv2b8="
        crossorigin="anonymous"></script>
    <script src="../../node_modules/semantic-ui/dist/semantic.min.js"></script>
    <style type="text/css">
        @media only screen and (max-width: 700px) {
            .ui.fixed.menu {
                display: none !important;
            }
        }
    </style>
</head>
<body>

<div class="ui massive attached stackable container top menu">
    <div class="item left floated">
        <h1>VERSUS X</h1>
    </div>
    <a class="item" href="controladorAcao.php?action=index">Início</a>
    <?php
    if (!isset($_SESSION['logado'])){?>
        <a class="item" href="?actioni=login">Logar</a>
        <a class="item" href="?actioni=cadastrar">Cadastrar</a>
    <?php }
    ?><a class="item" href="?actioni=sobre">Sobre e Contatos</a>
    <?php
    if (isset($_SESSION['logado'])){?>
        <!--                <a class="item" href="#">Perfil</a>-->
        <a class="item" href="?actioni=comment">Comentários</a>
        <a class="item" href="?action=sair">Sair</a>
        <?php
        if (isset($_SESSION['logado']) and isset($_SESSION['tipo'])){?>
            <a class="item" href="?action=listausuario">Admin</a>
        <?php } ?>
    <?php } ?>
</div>
<br>
<br>
<br>

<?php
if (!isset($_SESSION['logado']) and isset($_GET['actioni']) and $_GET['actioni'] == 'login') {
    include_once "../views/form/login.php";
}elseif (!isset($_SESSION['logado']) and isset($_GET['actioni']) and $_GET['actioni'] == 'cadastrar'){
    include_once "../views/form/cadastro.php";
}elseif (isset($_GET['actioni']) and $_GET['actioni'] == 'sobre') {
    include_once "../views/tab/about us.php";
}elseif (isset($_GET['actioni']) and $_GET['actioni'] == 'comment') {
    include_once "../views/tab/comment.php";
} ?>
<div id="tabela">
    <?php

    $crudauto = new CrudVeiculo();

    //CARRO-1
    if ((isset($_POST['marca'])) and (isset($_POST['modelo'])) and
        (isset($_POST['ano'])) and ($_POST['marca']!='Selecione...') and
        ($_POST['modelo']) and ($_POST['ano'])) {
        $idMarca = $_POST['marca'];
        $idModelo = $_POST['modelo'];
        $idAno = $_POST['ano'];
        $anos = file_get_contents("http://fipeapi.appspot.com/api/1/carros/veiculo/$idMarca/$idModelo/$idAno.json");
        $anos = json_decode($anos, true);
        $auto1 = $crudauto->getModelAno($idMarca, $idModelo, $anos['ano_modelo']);
        echo "<p style='color:red;'>Carro1</p>";
        echo "montadora :$idMarca\n";
        echo "modelo    :$idModelo\n";
        echo "ano       :".$anos['ano_modelo']."\n";

    }else{
        echo "<p style='color:red;'>Carro-1 não selecionado</p>";
        $auto1 = new Veiculo();
    }
    //END CARRO-1

    //CARRO-2
    if ((isset($_POST['marca1'])) and (isset($_POST['modelo1'])) and
        (isset($_POST['ano1'])) and ($_POST['marca1']!='Selecione...') and
        ($_POST['modelo1']) and ($_POST['ano1'])) {
        $idMarca1 = $_POST['marca1'];
        $idModelo1 = $_POST['modelo1'];
        $idAno1 = $_POST['ano1'];
        $anos1 = file_get_contents("http://fipeapi.appspot.com/api/1/carros/veiculo/$idMarca1/$idModelo1/$idAno1.json");
        $anos1 = json_decode($anos1, true);
        $auto2 = $crudauto->getModelAno($idMarca1, $idModelo1, $anos1['ano_modelo']);
        echo "<p style='color:black;'>Carro2</p>";
        echo "montadora :$idMarca1\n";
        echo "modelo    :$idModelo1\n";
        echo "ano       :".$anos1['ano_modelo']."\n";
    }else {
        echo "<p style='color:black;'>Carro-2 não selecionado</p>";
        $auto2 = new Veiculo();
    }
    //END CARRO-2

    //CARRO-3
    if ((isset($_POST['marca2'])) and (isset($_POST['modelo2'])) and
        (isset($_POST['ano2'])) and ($_POST['marca2']!='Selecione...') and
        ($_POST['modelo2']) and ($_POST['ano2'])) {
        $idMarca2 = $_POST['marca2'];
        $idModelo2 = $_POST['modelo2'];
        $idAno2 = $_POST['ano2'];
        $anos2 = file_get_contents("http://fipeapi.appspot.com/api/1/carros/veiculo/$idMarca2/$idModelo2/$idAno2.json");
        $anos2 = json_decode($anos2, true);
        $auto3 = $crudauto->getModelAno($idMarca2, $idModelo2, $anos2['ano_modelo']);
        echo "<p style='color:green;'>Carro3</p>";
        echo "montadora :$idMarca2\n";
        echo "modelo    :$idModelo2\n";
        echo "ano       :".$anos2['ano_modelo']."\n";

    }else {
        echo "<p style='color:green;'>Carro-3 não selecionado</p>";
        $auto3 = new Veiculo();
    }
    //END CARRO-3

    //CARRO-4
    if ((isset($_POST['marca3'])) and (isset($_POST['modelo3'])) and
        (isset($_POST['ano3'])) and ($_POST['marca3']!='Selecione...') and
        ($_POST['modelo3']) and ($_POST['ano3'])) {
        $idMarca3 = $_POST['marca3'];
        $idModelo3 = $_POST['modelo3'];
        $idAno3 = $_POST['ano3'];
        $anos3 = file_get_contents("http://fipeapi.appspot.com/api/1/carros/veiculo/$idMarca3/$idModelo3/$idAno3.json");
        $anos3 = json_decode($anos3, true);
        $auto4 = $crudauto->getModelAno($idMarca3, $idModelo3, $anos3['ano_modelo']);
        echo "<p style='color:blue;'>Carro4</p>";
        echo "montadora :$idMarca3\n";
        echo "modelo    :$idModelo3\n";
        echo "ano       :".$anos3['ano_modelo']."\n";

    }else {
        echo "<p style='color:blue;'>Carro-4 não selecionado</p>";
        $auto4 = new Veiculo();
    }
    //END CARRO-4

//        print_r($auto1);
//            echo "<h1>Correto</h1>";






    ?>
    <table>
        <thead>
        <tr>
            <th>id</th>
            <th><?= $auto1->getIdveiculo(); ?></th>
            <th><?= $auto2->getIdveiculo(); ?></th>
            <th><?= $auto3->getIdveiculo(); ?></th>
            <th><?= $auto4->getIdveiculo(); ?></th>
        </tr>
        <tr>
            <th>ano</th>
            <th><?= $auto1->getAno(); ?></th>
            <th><?= $auto2->getAno(); ?></th>
            <th><?= $auto3->getAno(); ?></th>
            <th><?= $auto4->getAno(); ?></th>
        </tr>
        <tr>
            <th>potencia</th>
            <th><?= $auto1->getPotencia(); ?></th>
            <th><?= $auto2->getPotencia(); ?></th>
            <th><?= $auto3->getPotencia(); ?></th>
            <th><?= $auto4->getPotencia(); ?></th>
        </tr>
        <tr>
            <th>portas</th>
            <th><?= $auto1->getPortas(); ?></th>
            <th><?= $auto2->getPortas(); ?></th>
            <th><?= $auto3->getPortas(); ?></th>
            <th><?= $auto4->getPortas(); ?></th>
        </tr>
        <tr>
            <th>preco</th>
            <th><?= $auto1->getPreco(); ?></th>
            <th><?= $auto2->getPreco(); ?></th>
            <th><?= $auto3->getPreco(); ?></th>
            <th><?= $auto4->getPreco(); ?></th>
        </tr>
        <tr>
            <th>altura</th>
            <th><?= $auto1->getAltura(); ?></th>
            <th><?= $auto2->getAltura(); ?></th>
            <th><?= $auto3->getAltura(); ?></th>
            <th><?= $auto4->getAltura(); ?></th>
        </tr>
        <tr>
            <th>comprimento</th>
            <th><?= $auto1->getComprimento(); ?></th>
            <th><?= $auto2->getComprimento(); ?></th>
            <th><?= $auto3->getComprimento(); ?></th>
            <th><?= $auto4->getComprimento(); ?></th>
        </tr>
        <tr>
            <th>largura</th>
            <th><?= $auto1->getLargura(); ?></th>
            <th><?= $auto2->getLargura(); ?></th>
            <th><?= $auto3->getLargura(); ?></th>
            <th><?= $auto4->getLargura(); ?></th>
        </tr>
        <tr>
            <th>cambio</th>
            <th><?= $auto1->getCambio(); ?></th>
            <th><?= $auto2->getCambio(); ?></th>
            <th><?= $auto3->getCambio(); ?></th>
            <th><?= $auto4->getCambio(); ?></th>
        </tr>
        <tr>
            <th>velocidade</th>
            <th><?= $auto1->getVelocidade(); ?></th>
            <th><?= $auto2->getVelocidade(); ?></th>
            <th><?= $auto3->getVelocidade(); ?></th>
            <th><?= $auto4->getVelocidade(); ?></th>
        </tr>
        <tr>
            <th>tanque combustivel</th>
            <th><?= $auto1->getTanqueCombustivel(); ?></th>
            <th><?= $auto2->getTanqueCombustivel(); ?></th>
            <th><?= $auto3->getTanqueCombustivel(); ?></th>
            <th><?= $auto4->getTanqueCombustivel(); ?></th>
        </tr>
        <tr>
            <th>Tipo combustivel</th>
            <th><?= $auto1->getTipCombustivel(); ?></th>
            <th><?= $auto2->getTipCombustivel(); ?></th>
            <th><?= $auto3->getTipCombustivel(); ?></th>
            <th><?= $auto4->getTipCombustivel(); ?></th>
        </tr>
        <tr>
            <th>porta malas</th>
            <th><?= $auto1->getPortaMalas(); ?></th>
            <th><?= $auto2->getPortaMalas(); ?></th>
            <th><?= $auto3->getPortaMalas(); ?></th>
            <th><?= $auto4->getPortaMalas(); ?></th>
        </tr>
        <tr>
            <th>tipo de direção</th>
            <th><?= $auto1->getTipDirecao(); ?></th>
            <th><?= $auto2->getTipDirecao(); ?></th>
            <th><?= $auto3->getTipDirecao(); ?></th>
            <th><?= $auto4->getTipDirecao(); ?></th>
        </tr>
        <tr>
            <th>consumo urbano</th>
            <th><?= $auto1->getConsumoUrb(); ?></th>
            <th><?= $auto2->getConsumoUrb(); ?></th>
            <th><?= $auto3->getConsumoUrb(); ?></th>
            <th><?= $auto4->getConsumoUrb(); ?></th>
        </tr>
        <tr>
            <th>consumo rodoviario</th>
            <th><?= $auto1->getConsumoRod(); ?></th>
            <th><?= $auto2->getConsumoRod(); ?></th>
            <th><?= $auto3->getConsumoRod(); ?></th>
            <th><?= $auto4->getConsumoRod(); ?></th>
        </tr>
        <tr>
            <th>marcha</th>
            <th><?= $auto1->getMarcha(); ?></th>
            <th><?= $auto2->getMarcha(); ?></th>
            <th><?= $auto3->getMarcha(); ?></th>
            <th><?= $auto4->getMarcha(); ?></th>
        </tr>
        <tr>
            <th>tipo de tração</th>
            <th><?= $auto1->getTipTracao(); ?></th>
            <th><?= $auto2->getTipTracao(); ?></th>
            <th><?= $auto3->getTipTracao(); ?></th>
            <th><?= $auto4->getTipTracao(); ?></th>
        </tr>
        <tr>
            <th>porte</th>
            <th><?= $auto1->getPorte(); ?></th>
            <th><?= $auto2->getPorte(); ?></th>
            <th><?= $auto3->getPorte(); ?></th>
            <th><?= $auto4->getPorte(); ?></th>
        </tr>
        <tr>
            <th>ocupantes</th>
            <th><?= $auto1->getOcupantes(); ?></th>
            <th><?= $auto2->getOcupantes(); ?></th>
            <th><?= $auto3->getOcupantes(); ?></th>
            <th><?= $auto4->getOcupantes(); ?></th>
        </tr>
        <tr>
            <th>tipo de freio</th>
            <th><?= $auto1->getTipFreio(); ?></th>
            <th><?= $auto2->getTipFreio(); ?></th>
            <th><?= $auto3->getTipFreio(); ?></th>
            <th><?= $auto4->getTipFreio(); ?></th>
        </tr>
        <tr>
            <th>tipo do veiculo</th>
            <th><?= $auto1->getTipVeiculo(); ?></th>
            <th><?= $auto2->getTipVeiculo(); ?></th>
            <th><?= $auto3->getTipVeiculo(); ?></th>
            <th><?= $auto4->getTipVeiculo(); ?></th>
        </tr>
        </thead>
    </table>

</body>
</html>

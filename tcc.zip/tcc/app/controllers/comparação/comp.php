<?php

function preco($pre1, $pre2, $pre3=100000000000, $pre4=100000000000){


    if ($pre1 < $pre2 and $pre1 < $pre3 and $pre1 < $pre4){
        $melhorPre = $pre1;
        return $melhorPre;
    } elseif ($pre2 < $pre1 and $pre2 < $pre3 and $pre2 < $pre4){
        $melhorPre = $pre2;
        return $melhorPre;
    } elseif ($pre3 < $pre1 and $pre3 < $pre2 and $pre3 < $pre4){
        $melhorPre = $pre3;
        return $melhorPre;
    } else {
        $melhorPre = $pre4;
        return $melhorPre;
    }

}

function altura($alt1, $alt2, $alt3=null, $alt4=null){


    if ($alt1 > $alt2 and $alt1 > $alt3 and $alt1 > $alt4){
        $melhorAlt = $alt1;
        return $melhorAlt;
    } elseif ($alt2 > $alt1 and $alt2 > $alt3 and $alt2 > $alt4){
        $melhorAlt = $alt2;
        return $melhorAlt;
    } elseif ($alt3 > $alt1 and $alt3 > $alt2 and $alt3 > $alt4){
        $melhorAlt = $alt3;
        return $melhorAlt;
    } else {
        $melhorAlt = $alt4;
        return $melhorAlt;
    }

}

function comprimento($com1, $com2, $com3=null, $com4=null){


    if ($com1 > $com2 and $com1 > $com3 and $com1 > $com4){
        $melhorCom = $com1;
        return $melhorCom;
    } elseif ($com2 > $com1 and $com2 > $com3 and $com2 > $com4){
        $melhorCom = $com2;
        return $melhorCom;
    } elseif ($com3 > $com1 and $com3 > $com2 and $com3 > $com4){
        $melhorCom = $com3;
        return $melhorCom;
    } else {
        $melhorCom = $com4;
        return $melhorCom;
    }

}

function velocidade($vel1, $vel2, $vel3=null, $vel4=null){


    if ($vel1 > $vel2 and $vel1 > $vel3 and $vel1 > $vel4){
        $melhorVel = $vel1;
        return $melhorVel;
    } elseif ($vel2 > $vel1 and $vel2 > $vel3 and $vel2 > $vel4){
        $melhorVel = $vel2;
        return $melhorVel;
    } elseif ($vel3 > $vel1 and $vel3 > $vel2 and $vel3 > $vel4){
        $melhorVel = $vel3;
        return $melhorVel;
    } else {
        $melhorVel = $vel4;
        return $melhorVel;
    }

}

function tq_combustivel($tqc1, $tqc2, $tqc3=null, $tqc4=null){


    if ($tqc1 > $tqc2 and $tqc1 > $tqc3 and $tqc1 > $tqc4){
        $melhorTqc = $tqc1;
        return $melhorTqc;
    } elseif ($tqc2 > $tqc1 and $tqc2 > $tqc3 and $tqc2 > $tqc4){
        $melhorTqc = $tqc2;
        return $melhorTqc;
    } elseif ($tqc3 > $tqc2 and $tqc3 > $tqc1 and $tqc3 > $tqc4){
        $melhorTqc = $tqc3;
        return $melhorTqc;
    } else {
        $melhorTqc = $tqc3;
        return $melhorTqc;
    }

}

function portaMalas($por1, $por2, $por3=null, $por4=null){


    if ($por1 > $por2 and $por1 > $por3 and $por1 > $por4){
        $melhorPor = $por1;
        return $melhorPor;
    } elseif ($por2 > $por1 and $por2 > $por3 and $por2 > $por4){
        $melhorPor = $por2;
        return $melhorPor;
    } elseif ($por3 > $por1 and $por3 > $por2 and $por3 > $por4){
        $melhorPor = $por3;
        return $melhorPor;
    } else {
        $melhorPor = $por4;
        return $melhorPor;
    }

};

function consumoUrb($conu1, $conu2, $conu3=null, $conu4=null){


    if ($conu1 > $conu2 and $conu1 > $conu3 and $conu1 > $conu4) {
        $melhorConu = $conu1;
        return $melhorConu;
    } elseif ($conu2 > $conu1 and $conu2 > $conu3 and $conu2 > $conu4) {
        $melhorConu = $conu2;
        return $melhorConu;
    } elseif ($conu3 > $conu2 and $conu3 > $conu1 and $conu3 > $conu4) {
        $melhorConu = $conu3;
        return $melhorConu;
    } else {
        $melhorConu = $conu4;
        return $melhorConu;
    }

};

function consumoRod($conr1, $conr2, $conr3=null,$conr4=null){


    if ($conr1 > $conr2 and $conr1 > $conr3 and $conr1 > $conr4) {
        $melhorConr = $conr1;
        return $melhorConr;
    } elseif ($conr2 > $conr1 and $conr2 > $conr3 and $conr2 > $conr4) {
        $melhorConr = $conr2;
        return $melhorConr;
    } elseif ($conr3 > $conr2 and $conr3 > $conr1 and $conr3 > $conr4) {
        $melhorConr = $conr3;
        return $melhorConr;
    } else {
        $melhorConr = $conr4;
        return $melhorConr;
    }

};

function largura($lar1, $lar2, $lar3=null, $lar4=null){


    if ($lar1 > $lar2 and $lar1 > $lar3 and $lar1 > $lar4) {
        $melhorLar = $lar1;
        return $melhorLar;
    } elseif ($lar2 > $lar1 and $lar2 > $lar3 and $lar2 > $lar4) {
        $melhorLar = $lar2;
        return $melhorLar;
    } elseif ($lar3 > $lar2 and $lar3 > $lar1 and $lar3 > $lar4) {
        $melhorLar = $lar3;
        return $melhorLar;
    } else {
        $melhorLar = $lar4;
        return $melhorLar;
    }

};

function direcao($d1, $d2, $d3=null, $d4=null){


    $direcoes = [
        1=>['nome'=>'Direção Mecânica', 'peso'=>1],
        2=>['nome'=>'Direção Hidráulica', 'peso'=>2],
        3=>['nome'=>'Direção Elétrica', 'peso'=>3],
        4=>['nome'=>'null', 'peso'=>0]
    ];


    if ($direcoes[$d1]['peso'] > $direcoes[$d2]['peso'] and $direcoes[$d1]['peso'] > $direcoes[$d3]['peso'] and $direcoes[$d1]['peso'] > $direcoes[$d4]['peso']) {
        $melhorDir = $direcoes[$d1];
        return $melhorDir;
    } elseif($direcoes[$d2]['peso'] > $direcoes[$d1]['peso'] and $direcoes[$d2]['peso'] > $direcoes[$d3]['peso'] and $direcoes[$d2]['peso'] > $direcoes[$d4]['peso']) {
        $melhorDir = $direcoes[$d2];
        return $melhorDir;
    } elseif($direcoes[$d3]['peso'] > $direcoes[$d1]['peso'] and $direcoes[$d3]['peso'] > $direcoes[$d2]['peso'] and $direcoes[$d3]['peso'] > $direcoes[$d4]['peso']) {
        $melhorDir = $direcoes[$d3];
        return $melhorDir;
    } else {
        $melhorDir = $direcoes[$d4];
        return $melhorDir;
    }

}

function ano($ano1, $ano2, $ano3=null, $ano4=null){


    ////////////////////////////////////////////////////////1- melhor
    if ($ano1 > $ano2 and $ano1 > $ano3 and $ano1 > $ano4) {
        $melhorAno = $ano1;
        return $melhorAno;
    }

    if ($ano2 > $ano1 and $ano2 > $ano3 and $ano2 > $ano4){
        $MelhorAno = $ano2;
        return $MelhorAno;
    }

    if ($ano3 > $ano1 and $ano3 > $ano2 and $ano3 > $ano4){
        $MelhorAno = $ano3;
        return $MelhorAno;
    }

    if ($ano4 > $ano1 and $ano4 > $ano2 and $ano4 > $ano3){
        $MelhorAno = $ano4;
        return $MelhorAno;
    }
}



function potencia($pot1, $pot2, $pot3=null, $pot4=null){


    if ($pot1 > $pot2 and $pot1 > $pot3 and $pot1 > $pot4) {
        $melhorPot = $pot1;
        return $melhorPot;

    } if ($pot2 > $pot1 and $pot2 > $pot3 and $pot2 > $pot4) {
        $melhorPot = $pot2;
        return $melhorPot;

    } if ($pot3 > $pot2 and $pot3 > $pot1 and $pot3 > $pot4) {
        $melhorPot = $pot3;
        return $melhorPot;

    } if ($pot4 > $pot1 and $pot4 > $pot2 and $pot4 > $pot3) {
        $melhorPot = $pot4;
        return $melhorPot;

    }

}

?>
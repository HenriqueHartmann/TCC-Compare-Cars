<?php

    require_once "../models/CrudModelo.php";
    require_once "../models/CrudVeiculo.php";
    require_once "../models/CrudUsuario.php";
    require_once "funcoes/comparacao.php";
    require_once "funcoes/sessao.php";
    require_once "funcoes/carro.php";

    session_start();
    $acao = $_GET['acao'];

    switch ($acao){

        case 'index':
            $id1 = $auto1->getModeloIdModelo();
            $carro1 = $crud->getModelo($id1);
            $id2 = $auto2->getModeloIdModelo();
            $carro2 = $crud->getModelo($id2);
            $id3 = $auto3->getModeloIdModelo();
            $carro3 = $crud->getModelo($id3);
            $id4 = $auto4->getModeloIdModelo();
            $carro4 = $crud->getModelo($id4);

            include_once "../views/Template/cabecalhoComparacao.php";
            include_once "../views/Comparacao/comparacao menu.php";
            include_once "../views/Comparacao/tabela.php";
            include_once "../views/Template/rodape.php";
            break;

        case 'comp2':
            break;

        case 'comp3':
            break;

        case 'comp4':
            break;

        default:
            header('location: controladorUsuario.php');
            break;
    }
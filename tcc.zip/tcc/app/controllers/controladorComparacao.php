<?php

    require_once "../models/CrudVeiculo.php";
    require_once "../models/CrudUsuario.php";
    require_once "funcoes/comparacao.php";
    require_once "funcoes/sessao.php";
    require_once "funcoes/carro.php";

    session_start();

    if (isset($_GET['acao'])){
        $acao = $_GET['acao'];
    }else{
        $acao = 'index';
    }
    switch ($acao){

        case 'index':
            include_once "../views/Template/cabecalhoComparacao.php";
            include_once "../views/Comparacao/tabela.php";
            include_once "../views/Template/rodape.php";
        break;
    }

<?php
/**
 * Created by PhpStorm.
 * User: Gean Carlos
 * Date: 04/06/2018
 * Time: 16:06
 */

class Comentario
{
    private $idcoment;
    private $nome;
    private $texto;
    private $data;
    private $comentario_cod;

    public function __construct($idcoment = null, $nome = null, $texto = null, $data = null, $comentario_cod = null){
    }

    public function getIdcoment()
    {
        return $this->idcoment;
    }

    public function setIdcoment($idcoment): void
    {
        $this->idcoment = $idcoment;
    }

    public function getNome()
    {
        return $this->nome;
    }

    public function setNome($nome): void
    {
        $this->nome = $nome;
    }

    public function getTexto()
    {
        return $this->texto;
    }

    public function setTexto($texto): void
    {
        $this->texto = $texto;
    }

    public function getData()
    {
        return $this->data;
    }

    public function setData($data): void
    {
        $this->data = $data;
    }

    public function getComentarioCod()
    {
        return $this->comentario_cod;
    }

    public function setComentarioCod($comentario_cod): void
    {
        $this->comentario_cod = $comentario_cod;
    }



}
<?php
/**
 * Created by PhpStorm.
 * User: aluno
 * Date: 09/04/18
 * Time: 16:26
 */

class Montadora
{
    private $idmontadora;
    private $montadora;

    public function __construct($idmontadora = null, $montadora = null)
    {
        $this->idmontadora = $idmontadora;
        $this->montadora = $montadora;
    }

    public function getIdmontadora()
    {
        return $this->idmontadora;
    }

    public function setIdmontadora($idmontadora)
    {
        $this->idmontadora = $idmontadora;
    }

    public function getNomeMontadora()
    {
        return $this->montadora;
    }

    public function setNomeMontadora($montadora)
    {
        $this->montadora = $montadora;
    }


}
-- phpMyAdmin SQL Dump
-- version 4.5.4.1deb2ubuntu2
-- http://www.phpmyadmin.net
--
-- Host: localhost
-- Generation Time: 25-Out-2018 às 17:08
-- Versão do servidor: 5.7.21-0ubuntu0.16.04.1
-- PHP Version: 7.0.22-0ubuntu0.16.04.1

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `banco`
--

-- --------------------------------------------------------

--
-- Estrutura da tabela `comentario`
--

CREATE TABLE `comentario` (
  `idcomentario` int(11) NOT NULL,
  `texto` text,
  `data` timestamp NULL DEFAULT NULL,
  `pendente` int(11) DEFAULT NULL,
  `usuario_idusuario` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

-- --------------------------------------------------------

--
-- Estrutura da tabela `curtida`
--

CREATE TABLE `curtida` (
  `idcurtida` int(11) NOT NULL,
  `modelo_ano_idmodelo_ano` int(11) NOT NULL,
  `usuario_idusuario` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

-- --------------------------------------------------------

--
-- Estrutura da tabela `modelo`
--

CREATE TABLE `modelo` (
  `idmodelo` int(11) NOT NULL,
  `nome_modelo` varchar(45) DEFAULT NULL,
  `montadora_idmontadora` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

-- --------------------------------------------------------

--
-- Estrutura da tabela `modelo_ano`
--

CREATE TABLE `modelo_ano` (
  `idmodelo_ano` int(11) NOT NULL,
  `ano` varchar(45) DEFAULT NULL,
  `potencia` varchar(45) DEFAULT NULL,
  `portas` varchar(45) DEFAULT NULL,
  `preco` varchar(45) DEFAULT NULL,
  `altura` varchar(45) DEFAULT NULL,
  `comprimento` varchar(45) DEFAULT NULL,
  `largura` varchar(45) DEFAULT NULL,
  `cambio` varchar(45) DEFAULT NULL,
  `velocidade` varchar(45) DEFAULT NULL,
  `tanque_combustivel` varchar(45) DEFAULT NULL,
  `tip_combustivel` varchar(45) DEFAULT NULL,
  `porta_malas` varchar(45) DEFAULT NULL,
  `tip_direcao` varchar(45) DEFAULT NULL,
  `consumo_urb_gas` varchar(45) DEFAULT NULL,
  `consumo_urb_alc` varchar(45) DEFAULT NULL,
  `consumo_rod_gas` varchar(45) DEFAULT NULL,
  `consumo_rod_alc` varchar(45) DEFAULT NULL,
  `marcha` varchar(45) DEFAULT NULL,
  `tip_tracao` varchar(45) DEFAULT NULL,
  `porte` varchar(45) DEFAULT NULL,
  `ocupantes` varchar(45) DEFAULT NULL,
  `tip_freio` varchar(45) DEFAULT NULL,
  `tip_veiculo` varchar(45) DEFAULT NULL,
  `modelo_idmodelo` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

-- --------------------------------------------------------

--
-- Estrutura da tabela `montadora`
--

CREATE TABLE `montadora` (
  `idmontadora` int(11) NOT NULL,
  `montadora` varchar(45) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

-- --------------------------------------------------------

--
-- Estrutura da tabela `usuario`
--

CREATE TABLE `usuario` (
  `idusuario` int(11) NOT NULL,
  `nome` varchar(45) DEFAULT NULL,
  `email` varchar(45) DEFAULT NULL,
  `senha` varchar(45) DEFAULT NULL,
  `tip_usuario` varchar(45) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Indexes for dumped tables
--

--
-- Indexes for table `comentario`
--
ALTER TABLE `comentario`
  ADD PRIMARY KEY (`idcomentario`),
  ADD KEY `fk_comentario_usuario1_idx` (`usuario_idusuario`);

--
-- Indexes for table `curtida`
--
ALTER TABLE `curtida`
  ADD PRIMARY KEY (`idcurtida`),
  ADD KEY `fk_curtida_modelo_ano1_idx` (`modelo_ano_idmodelo_ano`),
  ADD KEY `fk_curtida_usuario1_idx` (`usuario_idusuario`);

--
-- Indexes for table `modelo`
--
ALTER TABLE `modelo`
  ADD PRIMARY KEY (`idmodelo`),
  ADD KEY `fk_modelo_montadora_idx` (`montadora_idmontadora`);

--
-- Indexes for table `modelo_ano`
--
ALTER TABLE `modelo_ano`
  ADD PRIMARY KEY (`idmodelo_ano`),
  ADD KEY `fk_modelo_ano_modelo1_idx` (`modelo_idmodelo`);

--
-- Indexes for table `montadora`
--
ALTER TABLE `montadora`
  ADD PRIMARY KEY (`idmontadora`);

--
-- Indexes for table `usuario`
--
ALTER TABLE `usuario`
  ADD PRIMARY KEY (`idusuario`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `comentario`
--
ALTER TABLE `comentario`
  MODIFY `idcomentario` int(11) NOT NULL AUTO_INCREMENT;
--
-- AUTO_INCREMENT for table `curtida`
--
ALTER TABLE `curtida`
  MODIFY `idcurtida` int(11) NOT NULL AUTO_INCREMENT;
--
-- AUTO_INCREMENT for table `modelo`
--
ALTER TABLE `modelo`
  MODIFY `idmodelo` int(11) NOT NULL AUTO_INCREMENT;
--
-- AUTO_INCREMENT for table `modelo_ano`
--
ALTER TABLE `modelo_ano`
  MODIFY `idmodelo_ano` int(11) NOT NULL AUTO_INCREMENT;
--
-- AUTO_INCREMENT for table `montadora`
--
ALTER TABLE `montadora`
  MODIFY `idmontadora` int(11) NOT NULL AUTO_INCREMENT;
--
-- AUTO_INCREMENT for table `usuario`
--
ALTER TABLE `usuario`
  MODIFY `idusuario` int(11) NOT NULL AUTO_INCREMENT;
--
-- Constraints for dumped tables
--

--
-- Limitadores para a tabela `comentario`
--
ALTER TABLE `comentario`
  ADD CONSTRAINT `fk_comentario_usuario1` FOREIGN KEY (`usuario_idusuario`) REFERENCES `usuario` (`idusuario`) ON DELETE NO ACTION ON UPDATE NO ACTION;

--
-- Limitadores para a tabela `curtida`
--
ALTER TABLE `curtida`
  ADD CONSTRAINT `fk_curtida_modelo_ano1` FOREIGN KEY (`modelo_ano_idmodelo_ano`) REFERENCES `modelo_ano` (`idmodelo_ano`) ON DELETE NO ACTION ON UPDATE NO ACTION,
  ADD CONSTRAINT `fk_curtida_usuario1` FOREIGN KEY (`usuario_idusuario`) REFERENCES `usuario` (`idusuario`) ON DELETE NO ACTION ON UPDATE NO ACTION;

--
-- Limitadores para a tabela `modelo`
--
ALTER TABLE `modelo`
  ADD CONSTRAINT `fk_modelo_montadora` FOREIGN KEY (`montadora_idmontadora`) REFERENCES `montadora` (`idmontadora`) ON DELETE NO ACTION ON UPDATE NO ACTION;

--
-- Limitadores para a tabela `modelo_ano`
--
ALTER TABLE `modelo_ano`
  ADD CONSTRAINT `fk_modelo_ano_modelo1` FOREIGN KEY (`modelo_idmodelo`) REFERENCES `modelo` (`idmodelo`) ON DELETE NO ACTION ON UPDATE NO ACTION;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;

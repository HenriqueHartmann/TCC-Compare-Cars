        <div class="ui landing fluid">
            <img src="../../assets/images/bg.png" class="ui fluid image"/>
        </div>
        <!-- MAIN CONTENT -->
        <div class="ui container index" >
            <h1 class="ui header center aligned">Ranking</h1>
            <div id="tabela" class="reload-rank">

            </div>
        </div>


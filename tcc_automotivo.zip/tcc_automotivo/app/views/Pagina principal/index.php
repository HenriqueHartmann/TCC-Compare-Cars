        <div class="ui landing fluid">
            <img src="../../assets/images/teste.jpg" class="ui fluid image"/>
        </div>
        <!-- MAIN CONTENT -->
        <div class="ui container index" >
            <h1 class="ui header">Ranking</h1>
            <div class="reload">

            </div>
            <h1 class="ui header">Objetivo Geral</h1>
            <p>Compare Cars, possibilita que o usuário possa comparar diferentes modelos de veículos, auxiliando as pessos na tomada de
                decisão sobre troca ou compra de um novo veículo.</p>
            <h1 class="ui header">Tutorial</h1>
            <p>Então vamos começar com o nosso tutorial rápido e simples.</p>
            <p><span style="color: #21ba45;">1° Passo</span>, ir para a seleção da quantidade de veículos a serem comparados.
                Vá em qualquer uma das págians, basta você ir para o menu e clicar em cima de comparação.
                Pronto você está na página de seleção da quantidade de veículos a serem comparados.</p>
            <img class="ui centered large image rounded" data-src="../../../assets/images/tutorial1.png" src="../../assets/images/tut1.png">
            <p><span style="color: #21ba45;">2° Passo</span>, agora você está na página de seleção da quantidade de veículos a serem comparados.
                Então você tem a opção, de comparar 2,3 ou até 4 veículos.</p>
            <img class="ui centered large image rounded" data-src="../../../assets/images/tut2.png" src="../../assets/images/tut2.png">
            <p><span style="color: #21ba45;">3° Passo</span>, após a sua escolha você será direcionado a uma página de seleção dos modelos,
                você irá escolher a marca, modelo e o ano desejado, então clique em "Enviar".</p>
            <img class="ui centered large image rounded" data-src="../../../assets/images/tut3.png" src="../../assets/images/tut3.png">
            <p><span style="color: #21ba45;">4° Passo</span>, agora basta curtir a sua comparação.</p>
            <img class="ui centered large image rounded" data-src="../../../assets/images/tut4.png" src="../../assets/images/tut4.png">
        </div>


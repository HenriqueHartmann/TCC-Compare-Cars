<?php

    $codigo = $_GET['codigo'];
?>

    <div class="ui middle aligned center aligned grid">
        <div class="column">
            <h2 class="ui teal image header">
                <div class="content">
                    <h1 style="color: #ff5627;">Editar Especificação</h1>
                </div>
            </h2>
            <form class="ui large form" style="width: 400px; margin: 0 auto;" method="post" action="controladorAdmin.php?acao=updateespec&codigo=<?=$codigo ?>">
                <div class="ui stacked segment">

                    <div class="ui left icon input">
                        <i class="hashtag icon"></i>
                        <input name="idveiculo" type="text" value="<?= $espec->getIdveiculo() ?>">
                    </div>
                    <br>
                    <br>

                    <div class="ui left icon input">
                        <i class="car icon"></i>
                        <input name="ano" type="text" value="<?= $espec->getAno() ?>">
                    </div>
                    <br>
                    <br>

                    <div class="ui left icon input">
                        <i class="car icon"></i>
                        <input name="potencia" type="text" value="<?= $espec->getPotencia() ?>">
                    </div>
                    <br>
                    <br>

                    <div class="ui left icon input">
                        <i class="car icon"></i>
                        <input name="portas" type="text" value="<?= $espec->getPortas() ?>">
                    </div>
                    <br>
                    <br>

                    <div class="ui left icon input">
                        <i class="car icon"></i>
                        <input name="preco" type="text" value="<?= $espec->getPreco() ?>">
                    </div>
                    <br>
                    <br>

                    <div class="ui left icon input">
                        <i class="car icon"></i>
                        <input name="altura" type="text" value="<?= $espec->getAltura() ?>">
                    </div>
                    <br>
                    <br>

                    <div class="ui left icon input">
                        <i class="car icon"></i>
                        <input name="comprimento" type="text" value="<?= $espec->getComprimento() ?>">
                    </div>
                    <br>
                    <br>

                    <div class="ui left icon input">
                        <i class="car icon"></i>
                        <input name="largura" type="text" value="<?= $espec->getLargura() ?>">
                    </div>
                    <br>
                    <br>

                    <div class="ui left icon input">
                        <i class="car icon"></i>
                        <input name="cambio" type="text" value="<?= $espec->getCambio() ?>">
                    </div>
                    <br>
                    <br>

                    <div class="ui left icon input">
                        <i class="car icon"></i>
                        <input name="velocidade" type="text" value="<?= $espec->getVelocidade() ?>">
                    </div>
                    <br>
                    <br>

                    <div class="ui left icon input">
                        <i class="car icon"></i>
                        <input name="tanque_combustivel" type="text" value="<?= $espec->getTanqueCombustivel() ?>">
                    </div>
                    <br>
                    <br>

                    <div class="ui left icon input">
                        <i class="car icon"></i>
                        <input name="tip_combustivel" type="text" value="<?= $espec->getTipCombustivel() ?>">
                    </div>
                    <br>
                    <br>

                    <div class="ui left icon input">
                        <i class="car icon"></i>
                        <input name="porta_malas" type="text" value="<?= $espec->getPortaMalas() ?>">
                    </div>
                    <br>
                    <br>

                    <div class="ui left icon input">
                        <i class="car icon"></i>
                        <input name="tip_direcao" type="text" value="<?= $espec->getTipDirecao() ?>">
                    </div>
                    <br>
                    <br>

                    <div class="ui left icon input">
                        <i class="car icon"></i>
                        <input name="consumo_urb_gas" type="text" value="<?= $espec->getConsumoUrbGas() ?>">
                    </div>
                    <br>
                    <br>

                    <div class="ui left icon input">
                        <i class="car icon"></i>
                        <input name="consumo_urb_alc" type="text" value="<?= $espec->getConsumoUrbAlc() ?>">
                    </div>
                    <br>
                    <br>

                    <div class="ui left icon input">
                        <i class="car icon"></i>
                        <input name="consumo_rod_gas" type="text" value="<?= $espec->getConsumoRodGas() ?>">
                    </div>
                    <br>
                    <br>

                    <div class="ui left icon input">
                        <i class="car icon"></i>
                        <input name="consumo_rod_alc" type="text" value="<?= $espec->getConsumoRodAlc() ?>">
                    </div>
                    <br>
                    <br>

                    <div class="ui left icon input">
                        <i class="car icon"></i>
                        <input name="marcha" type="text" value="<?= $espec->getMarcha() ?>">
                    </div>
                    <br>
                    <br>

                    <div class="ui left icon input">
                        <i class="car icon"></i>
                        <input name="tip_tracao" type="text" value="<?= $espec->getTipTracao() ?>">
                    </div>
                    <br>
                    <br>

                    <div class="ui left icon input">
                        <i class="car icon"></i>
                        <input name="porte" type="text" value="<?= $espec->getPorte() ?>">
                    </div>
                    <br>
                    <br>

                    <div class="ui left icon input">
                        <i class="car icon"></i>
                        <input name="ocupantes" type="text" value="<?= $espec->getOcupantes() ?>">
                    </div>
                    <br>
                    <br>

                    <div class="ui left icon input">
                        <i class="car icon"></i>
                        <input name="tip_freio" type="text" value="<?= $espec->getTipFreio() ?>">
                    </div>
                    <br>
                    <br>

                    <div class="ui left icon input">
                        <i class="car icon"></i>
                        <input name="tip_veiculo" type="text" value="<?= $espec->getTipVeiculo() ?>">
                    </div>
                    <br>
                    <br>

                    <!-- Button -->
                    <div class="field">
                        <input type="submit" name="editar" id="singlebutton" class="ui fluid large teal button">
                    </div>
                    <br>
                </div>
            </form>
        </div>
    </div>
<div id="container" class="ui container">
    <div class="ui comments small">
        <h1 class="ui header center aligned">Comentários: </h1>
        <form method="post" class="ui form" action="controladorAdmin.php?acao=pagpendencias">
            <input type="hidden" name="acao" value="comentar" >

        </form>
        <?php
        $comentarioo = new CrudComentario();
        $comentarios = $comentarioo->getComentarios();
        $pend = $comentarios[0]->getPendente();
        if($pend[0] == 3){
            echo('<h1 class="ui header center aligned">Sem comentários</h1>');
        }
        else {
            foreach ($comentarios as $comentario): ?>
                <div class="ui divider"></div>
                <div class="comment">
                    <div>
                        <?php $id = $comentario->getUsuarioIdusuario() ?>
                        <p><?= $comentarioo->getUsuarioEmail($id) ?></p>
                        <div class="metadata">
                            <p><?= $comentario->getData() ?></p>
                            <p> Código <?= $comentario->getPendente() ?></p>
                        </div>
                        <div class="text">
                            <p><?= $comentario->getTexto() ?></p>
                        </div>

                        <?php
                        if (esta_logado() && e_admin()) {
                            ?>
                            <a href="controladorAdmin.php?acao=excluircomentario&codigocom=<?=$comentario->getIdcomentario()?>"
                               class="ui submit icon labeled mini red button">
                                <i class="trash alternate outline icon large"></i>Excluir
                            </a>
                            <?php
                        } ?>
                    </div>
                </div>
            <?php endforeach;
        }?>


    </div>
</div>
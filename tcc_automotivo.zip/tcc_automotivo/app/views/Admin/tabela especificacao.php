    <table class="ui compact celled padded table">
        <thead>
        </thead>
        <tbody>
        <?php

        if($veiculos != null) {
            foreach ($veiculos as $veiculo): ?>
                <tr id="principal">
                    <!--                colocar os get de especificações-->
                <tr><td>Id</td><td scope="row"><?= $veiculo->getIdveiculo() ?></td></tr>
                <tr><td>Ano</td><td><?= $veiculo->getAno() ?></td></tr>
                <tr><td>Potencia</td><td><?= $veiculo->getPotencia() ?></td></tr>
                <tr><td>Portas</td><td><?= $veiculo->getPortas() ?> portas</td></tr>
                <tr><td>Preço</td><td>R$ <?= $veiculo->getPreco() ?>.00</td></tr>
                <tr><td>Altura</td><td><?= $veiculo->getAltura() ?> mm</td></tr>
                <tr><td>Comprimento</td><td><?= $veiculo->getComprimento() ?> mm</td></tr>
                <tr><td>Largura</td><td><?= $veiculo->getLargura() ?> mm</td></tr>
                <tr><td>Câmbio</td><td><?= $veiculo->getCambio() ?></td></tr>
                <tr><td>Velocidade</td><td><?= $veiculo->getVelocidade() ?> km/h</td></tr>
                <tr><td>Tanque Combustivel</td><td><?= $veiculo->getTanqueCombustivel() ?> litros</td></tr>
                <tr><td>Combustivel</td><td><?= $veiculo->getTipCombustivel() ?></td></tr>
                <tr><td>Porta Malas</td><td><?= $veiculo->getPortaMalas() ?> litros</td></tr>
                <tr><td>Direção</td><td><?= $veiculo->getTipDirecao() ?></td></tr>
                <tr><td>Consumo Urbano Gasolina</td><td><?= $veiculo->getConsumoUrbGas() ?> km/l (G)</td></tr>
                <tr><td>Consumo Urbano Alcool</td><td><?= $veiculo->getConsumoUrbAlc() ?> km/l (A)</td></tr>
                <tr><td>Consumo Rodoviario Gasolina</td><td><?= $veiculo->getConsumoRodGas() ?> km/l (G)</td></tr>
                <tr><td>Consumo Rodoviario Alcool</td><td><?= $veiculo->getConsumoRodAlc() ?> km/l (A)</td></tr>
                <tr><td>Marcha</td><td><?= $veiculo->getMarcha() ?> marchas</td></tr>
                <tr><td>Tração</td><td><?= $veiculo->getTipTracao() ?></td></tr>
                <tr><td>Porte</td><td><?= $veiculo->getPorte() ?></td></tr>
                <tr><td>Ocupantes</td><td><?= $veiculo->getOcupantes() ?> passageiros</td></tr>
                <tr><td>Freio</td><td><?= $veiculo->getTipFreio() ?></td></tr>
                <tr><td>Tipo do Veiculo</td><td><?= $veiculo->getTipVeiculo() ?></td></tr>
                <tr><td>Ação</td><td><a class="lic1" href="controladorAdmin.php?acao=editarespec&codigo=<?= $veiculo->getIdveiculo(); ?>"><b>EDITAR</b></a> |
                                     <a class="lic2" href="controladorAdmin.php?acao=excluirespec&codigo=<?= $veiculo->getIdveiculo(); ?>"><b>EXCLUIR</b></a>
                    </td></tr>
                <tr class="" style="background-color: #0f0f10"><td>Space</td><td></td></tr>
                </tr>
            <?php endforeach;
        }else{
            echo "<div class=\"ui middle aligned center aligned grid\">
            <div class=\"column\">
                <div class=\"content\">
                    <h2 class='teal' \">Sem Veiculos existentes</h2>
                </div>";
            $veiculo = new Veiculo();
        }
        ?>
        </tbody>
    </table>
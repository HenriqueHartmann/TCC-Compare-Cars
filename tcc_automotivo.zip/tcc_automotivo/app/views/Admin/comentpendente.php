<div id="container" class="ui container">
    <div class="ui comments center aligned">
        <div class="ui center aligned header">
            <h1>Comentários Pendentes</h1>
        </div>

        <?php
        $comentarioo = new CrudComentario();
        $comentarios = $comentarioo->getComentariospend();
        foreach ($comentarios as $comentario): ?>
            <div class="ui divider"></div>
            <div class="comment">
                <a class="avatar">
                    <img src="https://png.icons8.com/color/1600/avatar.png">
                </a>
                <div>
<!--                    --><?php //$id = $comentario->getUsuarioIdusuario() ?>
<!--                    <p>--><?//= $comentarioo->getUsuario($id); ?><!--</p>-->
                    <div class="metadata">
                        <p><?= $comentario->getData()?></p>
                    </div>
                    <div class="text">
                        <p><?= $comentario->getTexto()?></p>
                    </div>
<!--                    <div class="actions">-->
<!--                        <a class="reply"></a>-->
<!--                    </div>-->
                    <div>
                        <p><?= $comentario->getPendente() ?></p>
                    </div>

                    <?php
                    if (esta_logado() && e_admin()) {
                        ?>
                        <a href="controladorAdmin.php?acao=excluircomentario&codigocom=<?= $comentario->getIdcomentario() ?>" class="ui submit icon labeled red button">
                            <i class="trash alternate outline icon large"></i>Excluir
                        </a>
                        <?php
                    }?>
                </div>
            </div>
        <?php endforeach; ?>

    </div>
</div>
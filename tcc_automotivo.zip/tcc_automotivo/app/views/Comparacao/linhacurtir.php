<?php

    $page = $_POST['page'];
    switch ($page) {
        case 'ranking':
            require_once "../../models/CrudCurtidas.php";

            $crud = new CrudCurtidas();
            $ranking = $crud->Ranking();
            ?>
            <table class="ui green celled striped table large" >
                <thead>
                    <tr>
                        <th>Posição</th>
                        <th>Quantidade de Curtidas</th>
                        <th>Marca</th>
                        <th>Nome</th>
                        <th>Ano</th>
                    </tr>
                </thead>
                <tbody>
                    <tr>
                        <td scope="row"><i class="icon trophy violet"></i> 1º Lugar</td>
                        <td><?= (isset($ranking[0]['qtd'])) ? $ranking[0]['qtd'] : '' ?></td>
                        <td><?= (isset($ranking[0]['montadora'])) ? $ranking[0]['montadora'] : '' ?></td>
                        <td><?= (isset($ranking[0]['nome_modelo'])) ? $ranking[0]['nome_modelo'] : '' ?></td>
                        <td><?= (isset($ranking[0]['ano'])) ? $ranking[0]['ano'] : '' ?></td>
                    </tr>
                    <tr>
                        <td scope="row"><i class="icon trophy teal"></i> 2º Lugar</td>
                        <td><?= (isset($ranking[1]['qtd'])) ? $ranking[1]['qtd'] : '' ?></td>
                        <td><?= (isset($ranking[1]['montadora'])) ? $ranking[1]['montadora'] : '' ?></td>
                        <td><?= (isset($ranking[1]['nome_modelo'])) ? $ranking[1]['nome_modelo'] : '' ?></td>
                        <td><?= (isset($ranking[1]['ano'])) ? $ranking[1]['ano'] : '' ?></td>
                    </tr>
                    <tr>
                        <td scope="row"><i class="icon trophy yellow"></i> 3º Lugar</td>
                        <td><?= (isset($ranking[2]['qtd'])) ? $ranking[2]['qtd'] : '' ?></td>
                        <td><?= (isset($ranking[2]['montadora'])) ? $ranking[2]['montadora'] : '' ?></td>
                        <td><?= (isset($ranking[2]['nome_modelo'])) ? $ranking[2]['nome_modelo'] : '' ?></td>
                        <td><?= (isset($ranking[2]['ano'])) ? $ranking[2]['ano'] : '' ?></td>
                    </tr>
                    <tr>
                        <td scope="row"><i class="icon trophy grey"></i> 4º Lugar</td>
                        <td><?= (isset($ranking[3]['qtd'])) ? $ranking[3]['qtd'] : '' ?></td>
                        <td><?= (isset($ranking[3]['montadora'])) ? $ranking[3]['montadora'] : '' ?></td>
                        <td><?= (isset($ranking[3]['nome_modelo'])) ? $ranking[3]['nome_modelo'] : '' ?></td>
                        <td><?= (isset($ranking[3]['ano'])) ? $ranking[3]['ano'] : '' ?></td>
                    </tr>
                    <tr>
                        <td scope="row"><i class="icon trophy orange"></i> 5º Lugar</td>
                        <td><?= (isset($ranking[4]['qtd'])) ? $ranking[4]['qtd'] : '' ?></td>
                        <td><?= (isset($ranking[4]['montadora'])) ? $ranking[4]['montadora'] : '' ?></td>
                        <td><?= (isset($ranking[4]['nome_modelo'])) ? $ranking[4]['nome_modelo'] : '' ?></td>
                        <td><?= (isset($ranking[4]['ano'])) ? $ranking[4]['ano'] : '' ?></td>
                    </tr>
                </tbody>
            </table>
    <?php
            break;

        case 'curtidas':
    ?>
            <th>Curtir</th>
        <?php
        session_start();
        require_once "../../models/CrudCurtidas.php";

        $state = $_POST['state'];

        $crud = new CrudCurtidas();
        switch ($state) {

            case 'tabela2':
                $post1 = $_POST['idveiculo1'];
                $post2 = $_POST['idveiculo2'];

                $rlt1 = $crud->VerificaCurtida($post1, $_SESSION['id']);
                $qtdcurtidas1 = $crud->NCurtidas($post1);

                $rlt2 = $crud->VerificaCurtida($post2, $_SESSION['id']);
                $qtdcurtidas2 = $crud->NCurtidas($post2);

                ?>
                <th>
                    <?php if ($rlt1['COUNT(idcurtida)'] == 0) { ?>
                        <button class="ui icon button green like" id="<?= $post1 ?>">
                            <i class="icon thumbs up outline"></i>
                        </button>
                        <span class="likes_<?= $post1 ?>"><?= $qtdcurtidas1['COUNT(idcurtida)']; ?> Gostei</span>
                    <?php } else { ?>
                        <button class="ui icon button red like" id="<?= $post1 ?>">
                            <i class="icon thumbs down outline"></i>
                        </button>
                        <span class="likes_<?= $post1 ?>"><?= $qtdcurtidas1['COUNT(idcurtida)']; ?> Não Gostei</span>
                    <?php } ?>
                </th>
                <th>
                    <?php if ($rlt2['COUNT(idcurtida)'] == 0) { ?>
                        <button class="ui icon button green like" id="<?= $post2 ?>">
                            <i class="icon thumbs up outline"></i>
                        </button>
                        <span class="likes_<?= $post2 ?>"><?= $qtdcurtidas2['COUNT(idcurtida)']; ?> Gostei</span>
                    <?php } else { ?>
                        <button class="ui icon button red like" id="<?= $post2 ?>">
                            <i class="icon thumbs down outline"></i>
                        </button>
                        <span class="likes_<?= $post2 ?>"><?= $qtdcurtidas2['COUNT(idcurtida)']; ?> Não Gostei</span>
                    <?php } ?>
                </th>
                <?php break;

            case 'tabela3':
                $post1 = $_POST['idveiculo1'];
                $post2 = $_POST['idveiculo2'];
                $post3 = $_POST['idveiculo3'];

                $rlt1 = $crud->VerificaCurtida($post1, $_SESSION['id']);
                $qtdcurtidas1 = $crud->NCurtidas($post1);


                $rlt2 = $crud->VerificaCurtida($post2, $_SESSION['id']);
                $qtdcurtidas2 = $crud->NCurtidas($post2);


                $rlt3 = $crud->VerificaCurtida($post3, $_SESSION['id']);
                $qtdcurtidas3 = $crud->NCurtidas($post3);

                ?>
                <th>
                    <?php if ($rlt1['COUNT(idcurtida)'] == 0) { ?>
                        <button class="ui icon button green like" id="<?= $post1 ?>">
                            <i class="icon thumbs up outline"></i>
                        </button>
                        <span class="likes_<?= $post1 ?>"><?= $qtdcurtidas1['COUNT(idcurtida)']; ?> Gostei</span>
                    <?php } else { ?>
                        <button class="ui icon button red like" id="<?= $post1 ?>">
                            <i class="icon thumbs down outline"></i>
                        </button>
                        <span class="likes_<?= $post1 ?>"><?= $qtdcurtidas1['COUNT(idcurtida)']; ?> Não Gostei</span>
                    <?php } ?>
                </th>
                <th>
                    <?php if ($rlt2['COUNT(idcurtida)'] == 0) { ?>
                        <button class="ui icon button green like" id="<?= $post2 ?>">
                            <i class="icon thumbs up outline"></i>
                        </button>
                        <span class="likes_<?= $post2 ?>"><?= $qtdcurtidas2['COUNT(idcurtida)']; ?> Gostei</span>
                    <?php } else { ?>
                        <button class="ui icon button red like" id="<?= $post2 ?>">
                            <i class="icon thumbs down outline"></i>
                        </button>
                        <span class="likes_<?= $post2 ?>"><?= $qtdcurtidas2['COUNT(idcurtida)']; ?> Não Gostei</span>
                    <?php } ?>
                </th>
                <th>
                    <?php if ($rlt3['COUNT(idcurtida)'] == 0) { ?>
                        <button class="ui icon button green like" id="<?= $post3 ?>">
                            <i class="icon thumbs up outline"></i>
                        </button>
                        <span class="likes_<?= $post3 ?>"><?= $qtdcurtidas3['COUNT(idcurtida)']; ?> Gostei</span>
                    <?php } else { ?>
                        <button class="ui icon button red like" id="<?= $post3 ?>">
                            <i class="icon thumbs down outline"></i>
                        </button>
                        <span class="likes_<?= $post3 ?>"><?= $qtdcurtidas3['COUNT(idcurtida)']; ?> Não Gostei</span>
                    <?php } ?>
                </th>
                <?php break;

            case 'tabela4':
                $post1 = $_POST['idveiculo1'];
                $post2 = $_POST['idveiculo2'];
                $post3 = $_POST['idveiculo3'];
                $post4 = $_POST['idveiculo4'];

                $rlt1 = $crud->VerificaCurtida($post1, $_SESSION['id']);
                $qtdcurtidas1 = $crud->NCurtidas($post1);


                $rlt2 = $crud->VerificaCurtida($post2, $_SESSION['id']);
                $qtdcurtidas2 = $crud->NCurtidas($post2);


                $rlt3 = $crud->VerificaCurtida($post3, $_SESSION['id']);
                $qtdcurtidas3 = $crud->NCurtidas($post3);


                $rlt4 = $crud->VerificaCurtida($post4, $_SESSION['id']);
                $qtdcurtidas4 = $crud->NCurtidas($post4);

                ?>
                <th>
                    <?php if ($rlt1['COUNT(idcurtida)'] == 0) { ?>
                        <button class="ui icon button green like" id="<?= $post1 ?>">
                            <i class="icon thumbs up outline"></i>
                        </button>
                        <span class="likes_<?= $post1 ?>"><?= $qtdcurtidas1['COUNT(idcurtida)']; ?> Gostei</span>
                    <?php } else { ?>
                        <button class="ui icon button red like" id="<?= $post1 ?>">
                            <i class="icon thumbs down outline"></i>
                        </button>
                        <span class="likes_<?= $post1 ?>"><?= $qtdcurtidas1['COUNT(idcurtida)']; ?> Não Gostei</span>
                    <?php } ?>
                </th>
                <th>
                    <?php if ($rlt2['COUNT(idcurtida)'] == 0) { ?>
                        <button class="ui icon button green like" id="<?= $post2 ?>">
                            <i class="icon thumbs up outline"></i>
                        </button>
                        <span class="likes_<?= $post2 ?>"><?= $qtdcurtidas2['COUNT(idcurtida)']; ?> Gostei</span>
                    <?php } else { ?>
                        <button class="ui icon button red like" id="<?= $post2 ?>">
                            <i class="icon thumbs down outline"></i>
                        </button>
                        <span class="likes_<?= $post2 ?>"><?= $qtdcurtidas2['COUNT(idcurtida)']; ?> Não Gostei</span>
                    <?php } ?>
                </th>
                <th>
                    <?php if ($rlt3['COUNT(idcurtida)'] == 0) { ?>
                        <button class="ui icon button green like" id="<?= $post3 ?>">
                            <i class="icon thumbs up outline"></i>
                        </button>
                        <span class="likes_<?= $post3 ?>"><?= $qtdcurtidas3['COUNT(idcurtida)']; ?> Gostei</span>
                    <?php } else { ?>
                        <button class="ui icon button red like" id="<?= $post3 ?>">
                            <i class="icon thumbs down outline"></i>
                        </button>
                        <span class="likes_<?= $post3 ?>"><?= $qtdcurtidas3['COUNT(idcurtida)']; ?> Não Gostei</span>
                    <?php } ?>
                </th>
                <th>
                    <?php if ($rlt4['COUNT(idcurtida)'] == 0) { ?>
                        <button class="ui icon button green like" id="<?= $post4 ?>">
                            <i class="icon thumbs up outline"></i>
                        </button>
                        <span class="likes_<?= $post4 ?>"><?= $qtdcurtidas4['COUNT(idcurtida)']; ?> Gostei</span>
                    <?php } else { ?>
                        <button class="ui icon button red like" id="<?= $post4 ?>">
                            <i class="icon thumbs down outline"></i>
                        </button>
                        <span class="likes_<?= $post4 ?>"><?= $qtdcurtidas4['COUNT(idcurtida)']; ?> Não Gostei</span>
                    <?php } ?>
                </th>
                <?php break;
        }
            break;

        case 'favoritos':
                require_once "../../models/CrudCurtidas.php";

                session_start();
                $iduser = $_SESSION['id'];
                $crud = new CrudCurtidas();
                $favoritos = $crud->Favoritos($iduser);
                ?>
                <div class="ui center aligned two column grid">
                    <div class="row">
                <?php
                foreach ($favoritos as $favorito){
                    $detalhe = $crud->DetalhesCurtida($favorito['modelo_ano_idmodelo_ano']);
                    ?>
                    <div class="column">
                        <div class="ui vertical fluid menu">
                            <div class="item">
                                <?= $detalhe['nome_modelo'] ?>
                            </div>
                            <div class="item">
                                <?= $detalhe['ano'] ?>
                            </div>
                            <div class="item">
                                <?= $detalhe['montadora'] ?>
                            </div>
                            <div class="item">
                                <button class="ui circular icon button red like" id="<?= $favorito['modelo_ano_idmodelo_ano'] ?>">
                                    <i class="icon close"></i>
                                </button
                            </div>
                        </div>
                    </div>
                    <div><br></div>
                    </div>
                <?php } ?>
                    </div>
                </div>
                <?php
            break;
    }?>
<th>Curtir</th>
<th>
    <!--                <p id="opa1"></p>-->
    <!--                <button id="but1" class="circular ui icon button curtir1">-->
    <!--                    <span class="qtdcurtida1"></span>-->
    <!--                    <i class="icon thumbs up outline"></i>-->
    <!--                </button>-->
    <!--            </th>-->
    <!--            <th>-->
    <?php
    require_once "../../models/CrudCurtidas.php";
    $crud = new CrudCurtidas();
    $rlt = $crud->VerificaCurtida($auto1->getIdveiculo(),$_SESSION['id']);
    $qtdcurtidas = $crud->NCurtidas($auto1->getIdveiculo());
    if($rlt['COUNT(idcurtida)'] == 0) {?>
        <button class="ui icon button green like" id="<?=$auto1->getIdveiculo();?>">
            <i class="icon thumbs up outline"></i>
        </button>
        <span class="likes_<?=$auto1->getIdveiculo();?>"><?=$qtdcurtidas['COUNT(idcurtida)']; ?> Gostei</span>
    <?php }else{ ?>
        <button class="ui icon button red like" id="<?=$auto1->getIdveiculo();?>">
            <i class="icon thumbs down outline"></i>
        </button>
        <span class="likes_<?=$auto1->getIdveiculo();?>"><?=$qtdcurtidas['COUNT(idcurtida)']; ?> Não Gostei</span>
    <?php } ?>
</th>
<th>
    <!--                <button id="but2" class="circular ui icon button curtir2">-->
    <!--                    <span class="qtdcurtida2"></span>-->
    <!--                    <i class="icon thumbs up outline"></i>-->
    <!--                </button>-->
    <p>EM TESTE...</p>
</th>
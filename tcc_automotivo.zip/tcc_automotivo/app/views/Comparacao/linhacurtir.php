<th>Curtir</th>
<?php
    session_start();
    require_once "../../models/CrudCurtidas.php";

    $state = $_POST['state'];

    $crud = new CrudCurtidas();
    switch ($state){

        case 'tabela2':
            $post1 = $_POST['idveiculo1'];
            $post2 = $_POST['idveiculo2'];

            $rlt1 = $crud->VerificaCurtida($post1,$_SESSION['id']);
            $qtdcurtidas1 = $crud->NCurtidas($post1);

            $rlt2 = $crud->VerificaCurtida($post2,$_SESSION['id']);
            $qtdcurtidas2 = $crud->NCurtidas($post2);

            ?>
            <th>
                <?php   if($rlt1['COUNT(idcurtida)'] == 0) {?>
                    <button class="ui icon button green like" id="<?=$post1?>">
                        <i class="icon thumbs up outline"></i>
                    </button>
                    <span class="likes_<?=$post1?>"><?=$qtdcurtidas1['COUNT(idcurtida)']; ?> Gostei</span>
                <?php }else{ ?>
                    <button class="ui icon button red like" id="<?=$post1?>">
                        <i class="icon thumbs down outline"></i>
                    </button>
                    <span class="likes_<?=$post1?>"><?=$qtdcurtidas1['COUNT(idcurtida)']; ?> Não Gostei</span>
                <?php } ?>
            </th>
            <th>
                <?php   if($rlt2['COUNT(idcurtida)'] == 0) {?>
                    <button class="ui icon button green like" id="<?=$post2?>">
                        <i class="icon thumbs up outline"></i>
                    </button>
                    <span class="likes_<?=$post2?>"><?=$qtdcurtidas2['COUNT(idcurtida)']; ?> Gostei</span>
                <?php }else{ ?>
                    <button class="ui icon button red like" id="<?=$post2?>">
                        <i class="icon thumbs down outline"></i>
                    </button>
                    <span class="likes_<?=$post2?>"><?=$qtdcurtidas2['COUNT(idcurtida)']; ?> Não Gostei</span>
                <?php } ?>
            </th>
            <?php break;

        case 'tabela3':
            $post1 = $_POST['idveiculo1'];
            $post2 = $_POST['idveiculo2'];
            $post3 = $_POST['idveiculo3'];

            $rlt1 = $crud->VerificaCurtida($post1,$_SESSION['id']);
            $qtdcurtidas1 = $crud->NCurtidas($post1);


            $rlt2 = $crud->VerificaCurtida($post2,$_SESSION['id']);
            $qtdcurtidas2 = $crud->NCurtidas($post2);


            $rlt3 = $crud->VerificaCurtida($post3,$_SESSION['id']);
            $qtdcurtidas3 = $crud->NCurtidas($post3);

            ?>
            <th>
                <?php   if($rlt1['COUNT(idcurtida)'] == 0) {?>
                    <button class="ui icon button green like" id="<?=$post1?>">
                        <i class="icon thumbs up outline"></i>
                    </button>
                    <span class="likes_<?=$post1?>"><?=$qtdcurtidas1['COUNT(idcurtida)']; ?> Gostei</span>
                <?php }else{ ?>
                    <button class="ui icon button red like" id="<?=$post1?>">
                        <i class="icon thumbs down outline"></i>
                    </button>
                    <span class="likes_<?=$post1?>"><?=$qtdcurtidas1['COUNT(idcurtida)']; ?> Não Gostei</span>
                <?php } ?>
            </th>
            <th>
                <?php   if($rlt2['COUNT(idcurtida)'] == 0) {?>
                    <button class="ui icon button green like" id="<?=$post2?>">
                        <i class="icon thumbs up outline"></i>
                    </button>
                    <span class="likes_<?=$post2?>"><?=$qtdcurtidas2['COUNT(idcurtida)']; ?> Gostei</span>
                <?php }else{ ?>
                    <button class="ui icon button red like" id="<?=$post2?>">
                        <i class="icon thumbs down outline"></i>
                    </button>
                    <span class="likes_<?=$post2?>"><?=$qtdcurtidas2['COUNT(idcurtida)']; ?> Não Gostei</span>
                <?php } ?>
            </th>
            <th>
                <?php   if($rlt3['COUNT(idcurtida)'] == 0) {?>
                    <button class="ui icon button green like" id="<?=$post3?>">
                        <i class="icon thumbs up outline"></i>
                    </button>
                    <span class="likes_<?=$post3?>"><?=$qtdcurtidas3['COUNT(idcurtida)']; ?> Gostei</span>
                <?php }else{ ?>
                    <button class="ui icon button red like" id="<?=$post3?>">
                        <i class="icon thumbs down outline"></i>
                    </button>
                    <span class="likes_<?=$post3?>"><?=$qtdcurtidas3['COUNT(idcurtida)']; ?> Não Gostei</span>
                <?php } ?>
            </th>
            <?php break;

        case 'tabela4':
            $post1 = $_POST['idveiculo1'];
            $post2 = $_POST['idveiculo2'];
            $post3 = $_POST['idveiculo3'];
            $post4 = $_POST['idveiculo4'];

            $rlt1 = $crud->VerificaCurtida($post1,$_SESSION['id']);
            $qtdcurtidas1 = $crud->NCurtidas($post1);


            $rlt2 = $crud->VerificaCurtida($post2,$_SESSION['id']);
            $qtdcurtidas2 = $crud->NCurtidas($post2);


            $rlt3 = $crud->VerificaCurtida($post3,$_SESSION['id']);
            $qtdcurtidas3 = $crud->NCurtidas($post3);


            $rlt4 = $crud->VerificaCurtida($post4,$_SESSION['id']);
            $qtdcurtidas4 = $crud->NCurtidas($post4);

            ?>
            <th>
                <?php   if($rlt1['COUNT(idcurtida)'] == 0) {?>
                    <button class="ui icon button green like" id="<?=$post1?>">
                        <i class="icon thumbs up outline"></i>
                    </button>
                    <span class="likes_<?=$post1?>"><?=$qtdcurtidas1['COUNT(idcurtida)']; ?> Gostei</span>
                <?php }else{ ?>
                    <button class="ui icon button red like" id="<?=$post1?>">
                        <i class="icon thumbs down outline"></i>
                    </button>
                    <span class="likes_<?=$post1?>"><?=$qtdcurtidas1['COUNT(idcurtida)']; ?> Não Gostei</span>
                <?php } ?>
            </th>
            <th>
                <?php   if($rlt2['COUNT(idcurtida)'] == 0) {?>
                    <button class="ui icon button green like" id="<?=$post2?>">
                        <i class="icon thumbs up outline"></i>
                    </button>
                    <span class="likes_<?=$post2?>"><?=$qtdcurtidas2['COUNT(idcurtida)']; ?> Gostei</span>
                <?php }else{ ?>
                    <button class="ui icon button red like" id="<?=$post2?>">
                        <i class="icon thumbs down outline"></i>
                    </button>
                    <span class="likes_<?=$post2?>"><?=$qtdcurtidas2['COUNT(idcurtida)']; ?> Não Gostei</span>
                <?php } ?>
            </th>
            <th>
                <?php   if($rlt3['COUNT(idcurtida)'] == 0) {?>
                    <button class="ui icon button green like" id="<?=$post3?>">
                        <i class="icon thumbs up outline"></i>
                    </button>
                    <span class="likes_<?=$post3?>"><?=$qtdcurtidas3['COUNT(idcurtida)']; ?> Gostei</span>
                <?php }else{ ?>
                    <button class="ui icon button red like" id="<?=$post3?>">
                        <i class="icon thumbs down outline"></i>
                    </button>
                    <span class="likes_<?=$post3?>"><?=$qtdcurtidas3['COUNT(idcurtida)']; ?> Não Gostei</span>
                <?php } ?>
            </th>
            <th>
                <?php   if($rlt4['COUNT(idcurtida)'] == 0) {?>
                    <button class="ui icon button green like" id="<?=$post4?>">
                        <i class="icon thumbs up outline"></i>
                    </button>
                    <span class="likes_<?=$post4?>"><?=$qtdcurtidas4['COUNT(idcurtida)']; ?> Gostei</span>
                <?php }else{ ?>
                    <button class="ui icon button red like" id="<?=$post4?>">
                        <i class="icon thumbs down outline"></i>
                    </button>
                    <span class="likes_<?=$post4?>"><?=$qtdcurtidas4['COUNT(idcurtida)']; ?> Não Gostei</span>
                <?php } ?>
            </th>
            <?php break;
    } ?>
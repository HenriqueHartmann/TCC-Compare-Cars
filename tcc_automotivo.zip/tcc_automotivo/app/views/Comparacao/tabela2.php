<div id="tabela" style="padding: 0 2% 0 2%">
    <table class="ui small red table">
        <thead>
        <tr class="tabela">
            <th style="background-color: rgba(73,227,255,0.1);">Nome Carro </th>
            <th style="background-color: rgba(73,227,255,0.1);" class="id1"><?= $carro1->getNomemodelo() ?></th>
            <th style="background-color: rgba(73,227,255,0.1);" class="id2"><?= $carro2->getNomemodelo() ?></th>
        </tr>


        <tr class="tabela1">
            <th style="background-color: rgba(255,233,115,0.1);">ID</th>
            <th style="background-color: rgba(255,233,115,0.1);" id="carro1"><?= $auto1->getIdveiculo(); ?></th>
            <th style="background-color: rgba(255,233,115,0.1);" id="carro2"><?= $auto2->getIdveiculo(); ?></th>
        </tr>


        <tr>
            <!--            ANO-->
            <th style="background-color: rgba(73,227,255,0.1);">Ano</th>

            <?php $melhorAno = ano($auto1->getAno(), $auto2->getAno()); ?>

            <th style="background-color: rgba(73,227,255,0.1);"><i id="ano1" class="<?= ($auto1->getAno() == $melhorAno) ? "large green checkmark icon" : "large red close icon"; ?>"></i><span class="ano1"><?= $auto1->getAno(); ?></span></th>
            <th style="background-color: rgba(73,227,255,0.1);"><i id="ano2" class="<?= ($auto2->getAno() == $melhorAno) ? "large green checkmark icon" : "large red close icon"; ?>"></i><span class="ano2"><?= $auto2->getAno(); ?></span></th>
        </tr>
        <tr>


            <!--           POTENCIA-->
            <th style="background-color: rgba(255,233,115,0.1);">Potencia</th>

            <?php $melhorPot = potencia($auto1->getPotencia(), $auto2->getPotencia());

            $pot1 = substr($auto1->getPotencia(), 0, 3);
            $pot2 = substr($auto2->getPotencia(), 0, 3);

            ?>

            <th style="background-color: rgba(255,233,115,0.1);"><i id="pot1" class="<?= ($pot1 == $melhorPot) ? "large green checkmark icon" : "large red close icon"; ?>"></i><?= $auto1->getPotencia(); ?> </th>
            <th style="background-color: rgba(255,233,115,0.1);"><i id="pot2" class="<?= ($pot2 == $melhorPot) ? "large green checkmark icon" : "large red close icon"; ?>"></i><?= $auto2->getPotencia(); ?> </th>
        </tr>
        <tr>


            <th style="background-color: rgba(73,227,255,0.1);">Portas</th>

            <?php $melhorPort = portas($auto1->getPortas(), $auto2->getPortas());

            $port1 = $auto1->getPortas();
            $port2 = $auto2->getPortas();

            ?>

            <th style="background-color: rgba(73,227,255,0.1);"><i id="port1" class="<?= ($port1 == $melhorPort) ? "large green checkmark icon" : "large red close icon"; ?>"></i><?= $auto1->getPortas(); ?> portas</th>
            <th style="background-color: rgba(73,227,255,0.1);"><i id="port2" class="<?= ($port2 == $melhorPort) ? "large green checkmark icon" : "large red close icon"; ?>"></i><?= $auto2->getPortas(); ?> portas</th>
        </tr>
        <tr>


            <th style="background-color: rgba(255,233,115,0.1);">Preco</th>

            <?php $melhorPreco = preco2($auto1->getPreco(), $auto2->getPreco());

            $preco1 = $auto1->getPreco();
            $preco2 = $auto2->getPreco();

            ?>

            <th style="background-color: rgba(255,233,115,0.1);"><i id="preco1" class="<?= ($preco1 == $melhorPreco) ? "large green checkmark icon" : "large red close icon"; ?>"></i>R$ <?= number_format($auto1->getPreco()); ?>.00 </th>
            <th style="background-color: rgba(255,233,115,0.1);"><i id="preco2" class="<?= ($preco2 == $melhorPreco) ? "large green checkmark icon" : "large red close icon"; ?>"></i>R$ <?= number_format($auto2->getPreco()); ?>.00 </th>
        </tr>
        <tr>
            <th style="background-color: rgba(73,227,255,0.1);">Altura</th>

            <?php $melhorAlt = altura($auto1->getAltura(), $auto2->getAltura());

            $alt1 = $auto1->getAltura();
            $alt2 = $auto2->getAltura();

            ?>

            <th style="background-color: rgba(73,227,255,0.1);"><i id="alt1" class="<?= ($alt1 == $melhorAlt) ? "large green checkmark icon" : "large red close icon"; ?>"></i><?= $auto1->getAltura(); ?> mm</th>
            <th style="background-color: rgba(73,227,255,0.1);"><i id="alt2" class="<?= ($alt2 == $melhorAlt) ? "large green checkmark icon" : "large red close icon"; ?>"></i><?= $auto2->getAltura(); ?> mm</th>
        </tr>
        <tr>
            <th style="background-color: rgba(255,233,115,0.1);">Comprimento</th>

            <?php $melhorCom = comprimento($auto1->getComprimento(), $auto2->getComprimento());

            $com1 = $auto1->getComprimento();
            $com2 = $auto2->getComprimento();

            ?>

            <th style="background-color: rgba(255,233,115,0.1);"><i id="com1" class="<?= ($com1 == $melhorCom) ? "large green checkmark icon" : "large red close icon"; ?>"></i><?= $auto1->getComprimento(); ?> mm</th>
            <th style="background-color: rgba(255,233,115,0.1);"><i id="com2" class="<?= ($com2 == $melhorCom) ? "large green checkmark icon" : "large red close icon"; ?>"></i><?= $auto2->getComprimento(); ?> mm</th>
        </tr>
        <tr>


            <th style="background-color: rgba(73,227,255,0.1);">Largura</th>

            <?php $melhorLar = largura($auto1->getLargura(), $auto2->getLargura());

            $lar1 = $auto1->getLargura();
            $lar2 = $auto2->getLargura();

            ?>

            <th style="background-color: rgba(73,227,255,0.1);"><i id="lar1" class="<?= ($lar1 == $melhorLar) ? "large green checkmark icon" : "large red close icon"; ?>"></i><?= $auto1->getLargura(); ?> mm</th>
            <th style="background-color: rgba(73,227,255,0.1);"><i id="lar2" class="<?= ($lar2 == $melhorLar) ? "large green checkmark icon" : "large red close icon"; ?>"></i><?= $auto2->getLargura(); ?> mm</th>
        </tr>
        <tr>
            <th style="background-color: rgba(255,233,115,0.1);">Velocidade</th>

            <?php $melhorVel = velocidade($auto1->getVelocidade(), $auto2->getVelocidade());

            $vel1 = $auto1->getVelocidade();
            $vel2 = $auto2->getVelocidade();

            ?>

            <th style="background-color: rgba(255,233,115,0.1);"><i id="vel1" class="<?= ($vel1 == $melhorVel) ? "large green checkmark icon" : "large red close icon"; ?>"></i><?= $auto1->getVelocidade(); ?> km/h</th>
            <th style="background-color: rgba(255,233,115,0.1);"><i id="vel2" class="<?= ($vel2 == $melhorVel) ? "large green checkmark icon" : "large red close icon"; ?>"></i><?= $auto2->getVelocidade(); ?> km/h</th>
        </tr>
        <tr>
            <th style="background-color: rgba(73,227,255,0.1);">Tanque combustivel</th>

            <?php $melhorTqc = tq_combustivel($auto1->getTanqueCombustivel(), $auto2->getTanqueCombustivel());

            $tqc1 = $auto1->getTanqueCombustivel();
            $tqc2 = $auto2->getTanqueCombustivel();

            ?>

            <th style="background-color: rgba(73,227,255,0.1);"><i id="tqc1" class="<?= ($tqc1 == $melhorTqc) ? "large green checkmark icon" : "large red close icon"; ?>"></i><?= $auto1->getTanqueCombustivel(); ?> litros</th>
            <th style="background-color: rgba(73,227,255,0.1);"><i id="tqc2" class="<?= ($tqc2 == $melhorTqc) ? "large green checkmark icon" : "large red close icon"; ?>"></i><?= $auto2->getTanqueCombustivel(); ?> litros</th>
        </tr>
        <tr>
            <th style="background-color: rgba(255,233,115,0.1);">Tipo de direção</th>
            <?php $melhorDir = direcao($auto1->getTipDirecao(), $auto2->getTipDirecao());

            $d1 = $auto1->getTipDirecao();
            $d2 = $auto2->getTipDirecao();

            ?>

            <th style="background-color: rgba(255,233,115,0.1);"><i id="d1" class="<?= ($d1 == $melhorDir) ? "large green checkmark icon" : "large red close icon"; ?>"></i><?= $auto1->getTipDirecao(); ?> </th>
            <th style="background-color: rgba(255,233,115,0.1);"><i id="d2" class="<?= ($d2 == $melhorDir) ? "large green checkmark icon" : "large red close icon"; ?>"></i><?= $auto2->getTipDirecao(); ?> </th>

        </tr>
        <tr>
            <th style="background-color: rgba(73,227,255,0.1);">Tipo combustivel</th>
            <?php $melhorTpc = tp_combustivel($auto1->getTipCombustivel(), $auto2->getTipCombustivel());

            $tpc1 = $auto1->getTipCombustivel();
            $tpc2 = $auto2->getTipCombustivel();

            ?>

            <th style="background-color: rgba(73,227,255,0.1);"><i id="tpc1" class="<?= ($tpc1 == $melhorTpc) ? "large green checkmark icon" : "large red close icon"; ?>"></i><?= $auto1->getTipCombustivel(); ?> </th>
            <th style="background-color: rgba(73,227,255,0.1);"><i id="tpc2" class="<?= ($tpc2 == $melhorTpc) ? "large green checkmark icon" : "large red close icon"; ?>"></i><?= $auto2->getTipCombustivel(); ?> </th>

        </tr>
        <tr>
            <th style="background-color: rgba(255,233,115,0.1);">Porta malas</th>
            <?php $melhorPor = portaMalas($auto1->getPortaMalas(), $auto2->getPortaMalas());

            $por1 = $auto1->getPortaMalas();
            $por2 = $auto2->getPortaMalas();

            ?>

            <th style="background-color: rgba(255,233,115,0.1);"><i id="por1" class="<?= ($por1 == $melhorPor) ? "large green checkmark icon" : "large red close icon"; ?>"></i><?= $auto1->getPortaMalas(); ?> litros</th>
            <th style="background-color: rgba(255,233,115,0.1);"><i id="por2" class="<?= ($por2 == $melhorPor) ? "large green checkmark icon" : "large red close icon"; ?>"></i><?= $auto2->getPortaMalas(); ?> litros </th>
        </tr>

        <tr>
            <th style="background-color: rgba(73,227,255,0.1);">Consumo Urbano Gasolina</th>
            <?php $melhorconuG = consumoUrbGas($auto1->getConsumoUrbGas(), $auto2->getConsumoUrbGas());

            $conuG1 = $auto1->getConsumoUrbGas();
            $conuG2 = $auto2->getConsumoUrbGas();

            ?>

            <th style="background-color: rgba(73,227,255,0.1);"><i id="conG1" class="<?= ($conuG1 == $melhorconuG) ? "large green checkmark icon" : "large red close icon"; ?>"></i><?= $auto1->getConsumoUrbGas();

                if ($conuG1 == null){
                    echo "Não utiliza esse combustivel!";
                } else {
                    echo " km/l (G)";
                }?></th>

            <th style="background-color: rgba(73,227,255,0.1);"><i id="conG2" class="<?= ($conuG2 == $melhorconuG) ? "large green checkmark icon" : "large red close icon"; ?>"></i><?= $auto2->getConsumoUrbGas();

                if ($conuG2 == null){
                    echo "Não utiliza esse combustivel!";
                } else {
                    echo " km/l (G)";
                }?></th>
        </tr>
        <tr>
            <th style="background-color: rgba(255,233,115,0.1);">Consumo Urbano Alcool</th>
            <?php $melhorConuA = consumoUrbAlc($auto1->getConsumoUrbAlc(), $auto2->getConsumoUrbAlc());

            $conuA1 = $auto1->getConsumoUrbAlc();
            $conuA2 = $auto2->getConsumoUrbAlc();

            ?>

            <th style="background-color: rgba(255,233,115,0.1);"><i id="conA1" class="<?= ($conuA1 == $melhorConuA) ? "large green checkmark icon" : "large red close icon"; ?>"></i><?= $auto1->getConsumoUrbAlc();

                if ($conuA1 == null){
                    echo "Não utiliza esse combustivel!";
                } else {
                    echo " km/l (A)";
                }?></th>


            <th style="background-color: rgba(255,233,115,0.1);"><i id="conA2" class="<?= ($conuA2 == $melhorConuA) ? "large green checkmark icon" : "large red close icon"; ?>"></i><?= $auto2->getConsumoUrbAlc();

                if ($conuA2 == null){
                    echo "Não utiliza esse combustivel!";
                } else {
                    echo " km/l (A)";
                }?></th>

        </tr>
        <tr>
            <th style="background-color: rgba(73,227,255,0.1);">Consumo rodoviario Gasolina</th>
            <?php $melhorConrG = consumoRodGas($auto1->getConsumoRodGas(), $auto2->getConsumoRodGas());

            $conrG1 = $auto1->getConsumoRodGas();
            $conrG2 = $auto2->getConsumoRodGas();

            ?>

            <th style="background-color: rgba(73,227,255,0.1);"><i id="rodG1" class="<?= ($conrG1 == $melhorConrG) ? "large green checkmark icon" : "large red close icon"; ?>"></i><?= $auto1->getConsumoRodGas();

                if ($conrG1 == null){
                    echo "Não utiliza esse combustivel!";
                } else {
                    echo " km/l (G)";
                }?></th>

            <th style="background-color: rgba(73,227,255,0.1);"><i id="rodG2" class="<?= ($conrG2 == $melhorConrG) ? "large green checkmark icon" : "large red close icon"; ?>"></i><?= $auto2->getConsumoRodGas();

                if ($conrG2 == null){
                    echo "Não utiliza esse combustivel!";
                } else {
                    echo " km/l (G)";
                }?></th>

        </tr>
        <tr>
            <th style="background-color: rgba(255,233,115,0.1);">Consumo rodoviario Alcool</th>
            <?php $melhorConrA = consumoRodAlc($auto1->getConsumoRodAlc(), $auto2->getConsumoRodAlc());

            $conrA1 = $auto1->getConsumoRodAlc();
            $conrA2 = $auto2->getConsumoRodAlc();

            ?>

            <th style="background-color: rgba(255,233,115,0.1);"><i id="rodA1" class="<?= ($conrA1 == $melhorConrA) ? "large green checkmark icon" : "large red close icon"; ?>"></i><?= $auto1->getConsumoRodAlc();

                if ($conrA1 == null){
                    echo "Não utiliza esse combustivel!";
                } else {
                    echo " km/l (A)";
                }?></th>

            <th style="background-color: rgba(255,233,115,0.1);"><i id="rodA2" class="<?= ($conrA2 == $melhorConrA) ? "large green checkmark icon" : "large red close icon"; ?>"></i><?= $auto2->getConsumoRodAlc();

                if ($conrA2 == null){
                    echo "Não utiliza esse combustivel!";
                } else {
                    echo " km/l (A)";
                }?></th>

        </tr>
        <tr>
            <th style="background-color: rgba(73,227,255,0.1);">Marcha</th>
            <?php $melhorMar = marchas($auto1->getMarcha(), $auto2->getMarcha());

            $mar1 = $auto1->getMarcha();
            $mar2 = $auto2->getMarcha();

            ?>

            <th style="background-color: rgba(73,227,255,0.1);"><i id="mar1" class="<?= ($mar1 == $melhorMar) ? "large green checkmark icon" : "large red close icon"; ?>"></i><?= $auto1->getMarcha(); ?> marchas</th>
            <th style="background-color: rgba(73,227,255,0.1);"><i id="mar2" class="<?= ($mar2 == $melhorMar) ? "large green checkmark icon" : "large red close icon"; ?>"></i><?= $auto2->getMarcha(); ?> marchas</th>
        </tr>
        <tr>
            <th style="background-color: rgba(255,233,115,0.1);">Ocupantes</th>
            <?php $melhorOcu = ocupante($auto1->getOcupantes(), $auto2->getOcupantes());

            $ocu1 = $auto1->getOcupantes();
            $ocu2 = $auto2->getOcupantes();

            ?>

            <th style="background-color: rgba(255,233,115,0.1);"><i id="ocu1" class="<?= ($ocu1 == $melhorOcu) ? "large green checkmark icon" : "large red close icon"; ?>"></i><?= $auto1->getOcupantes(); ?> passageiros</th>
            <th style="background-color: rgba(255,233,115,0.1);"><i id="ocu2" class="<?= ($ocu2 == $melhorOcu) ? "large green checkmark icon" : "large red close icon"; ?>"></i><?= $auto2->getOcupantes(); ?> passageiros</th>
        </tr>
        <tr>
            <th style="background-color: rgba(73,227,255,0.1);">Câmbio</th>

            <th style="background-color: rgba(73,227,255,0.1);"><i id="cam1"></i><?= $auto1->getCambio(); ?></th>
            <th style="background-color: rgba(73,227,255,0.1);"><i id="cam2"></i><?= $auto2->getCambio(); ?> </th>
        </tr>
        <tr>
            <th style="background-color: rgba(255,233,115,0.1);">Tipo de freio</th>
            <th style="background-color: rgba(255,233,115,0.1);"><i id="tipF1"></i><?= $auto1->getTipFreio(); ?></th>
            <th style="background-color: rgba(255,233,115,0.1);"><i id="tipF2"></i><?= $auto2->getTipFreio(); ?> </th>
        </tr>
        <tr>
            <th style="background-color: rgba(73,227,255,0.1);">Tipo do veiculo</th>
            <th style="background-color: rgba(73,227,255,0.1);"><i id="tipV1"></i><?= $auto1->getTipVeiculo(); ?></th>
            <th style="background-color: rgba(73,227,255,0.1);"><i id="tipV2"></i><?= $auto2->getTipVeiculo(); ?> </th>
        </tr>
        <tr>
            <th style="background-color: rgba(255,233,115,0.1);">Tipo de tração</th>
            <th style="background-color: rgba(255,233,115,0.1);"><i id="tipT1"></i><?= $auto1->getTipTracao(); ?></th>
            <th style="background-color: rgba(255,233,115,0.1);"><i id="tipT2"></i><?= $auto2->getTipTracao(); ?> </th>
        </tr>
        <tr>
            <th style="background-color: rgba(73,227,255,0.1);">Porte</th>
            <th style="background-color: rgba(73,227,255,0.1);"><i id="porte1"></i><?= $auto1->getPorte(); ?></th>
            <th style="background-color: rgba(73,227,255,0.1);"><i id="porte2"></i><?= $auto2->getPorte(); ?> </th>
        </tr>
        <?php if(esta_logado()){?>
            <tr class="reload">

            </tr>
        <?php } ?>
        </thead>
    </table>
</div>
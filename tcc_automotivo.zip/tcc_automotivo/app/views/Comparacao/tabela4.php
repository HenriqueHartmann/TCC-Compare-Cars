<div id="tabela" style="padding: 0 2% 0 2%">
    <table class="ui small green table">
        <thead>
        <tr>
            <th>Nome Carro </th>
            <th><?= $carro1->getNomemodelo() ?></th>
            <th><?= $carro2->getNomemodelo() ?></th>
            <th><?= $carro3->getNomemodelo() ?></th>
            <th><?= $carro4->getNomemodelo() ?></th>
        </tr>
        <tr>
            <th>ID</th>
            <th><?= $auto1->getIdveiculo(); ?></th>
            <th><?= $auto2->getIdveiculo(); ?></th>
            <th><?= $auto3->getIdveiculo(); ?></th>
            <th><?= $auto4->getIdveiculo(); ?></th>
        </tr>
        <tr>

            <!--            ANO-->
            <th>Ano</th>

            <?php $melhorAno = ano($auto1->getAno(), $auto2->getAno(), $auto3->getAno(), $auto4->getAno()); ?>

            <th><i id="ano1" class="<?= ($auto1->getAno() == $melhorAno) ? "large green checkmark icon" : "large red close icon"; ?>"></i><?= $auto1->getAno(); ?> </th>
            <th><i id="ano2" class="<?= ($auto2->getAno() == $melhorAno) ? "large green checkmark icon" : "large red close icon"; ?>"></i><?= $auto2->getAno(); ?> </th>
            <th><i id="ano3" class="<?= ($auto3->getAno() == $melhorAno) ? "large green checkmark icon" : "large red close icon"; ?>"></i><?= $auto3->getAno(); ?> </th>
            <th><i id="ano4" class="<?= ($auto4->getAno() == $melhorAno) ? "large green checkmark icon" : "large red close icon"; ?>"></i><?= $auto4->getAno(); ?> </th>
        </tr>
        <tr>


            <!--           POTENCIA-->
            <th>Potencia</th>

            <?php $melhorPot = potencia($auto1->getPotencia(), $auto2->getPotencia(), $auto3->getPotencia(), $auto4->getPotencia());
            $pot1 = substr($auto1->getPotencia(), 0, 3);
            $pot2 = substr($auto2->getPotencia(), 0, 3);
            $pot3 = substr($auto3->getPotencia(), 0, 3);
            $pot4 = substr($auto4->getPotencia(), 0, 3);
            ?>

            <th><i id="pot1" class="<?= ($pot1 == $melhorPot) ? "large green checkmark icon" : "large red close icon"; ?>"></i><?= $auto1->getPotencia(); ?> </th>
            <th><i id="pot2" class="<?= ($pot2 == $melhorPot) ? "large green checkmark icon" : "large red close icon"; ?>"></i><?= $auto2->getPotencia(); ?> </th>
            <th><i id="pot3" class="<?= ($pot3 == $melhorPot) ? "large green checkmark icon" : "large red close icon"; ?>"></i><?= $auto3->getPotencia(); ?> </th>
            <th><i id="pot4" class="<?= ($pot4 == $melhorPot) ? "large green checkmark icon" : "large red close icon"; ?>"></i><?= $auto4->getPotencia(); ?> </th>
        </tr>
        <tr>


            <th>Portas</th>

            <?php $melhorPort = portas($auto1->getPortas(), $auto2->getPortas(), $auto3->getPortas(), $auto4->getPortas());
            $port1 = $auto1->getPortas();
            $port2 = $auto2->getPortas();
            $port3 = $auto3->getPortas();
            $port4 = $auto4->getPortas();
            ?>

            <th><i id="port1" class="<?= ($port1 == $melhorPort) ? "large green checkmark icon" : "large red close icon"; ?>"></i><?= $auto1->getPortas(); ?> </th>
            <th><i id="port2" class="<?= ($port2 == $melhorPort) ? "large green checkmark icon" : "large red close icon"; ?>"></i><?= $auto2->getPortas(); ?> </th>
            <th><i id="port3" class="<?= ($port3 == $melhorPort) ? "large green checkmark icon" : "large red close icon"; ?>"></i><?= $auto3->getPortas(); ?> </th>
            <th><i id="port4" class="<?= ($port4 == $melhorPort) ? "large green checkmark icon" : "large red close icon"; ?>"></i><?= $auto4->getPortas(); ?> </th>
        </tr>
        <tr>


            <th>Preco</th>

            <?php $melhorPreco = preco4($auto1->getPreco(), $auto2->getPreco(), $auto3->getPreco(), $auto4->getPreco());
            $preco1 = $auto1->getPreco();
            $preco2 = $auto2->getPreco();
            $preco3 = $auto3->getPreco();
            $preco4 = $auto4->getPreco();
            ?>

            <th><i id="preco1" class="<?= ($preco1 == $melhorPreco) ? "large green checkmark icon" : "large red close icon"; ?>"></i>R$ <?= number_format($auto1->getPreco()); ?>.00 </th>
            <th><i id="preco2" class="<?= ($preco2 == $melhorPreco) ? "large green checkmark icon" : "large red close icon"; ?>"></i>R$ <?= number_format($auto2->getPreco()); ?>.00 </th>
            <th><i id="preco3" class="<?= ($preco3 == $melhorPreco) ? "large green checkmark icon" : "large red close icon"; ?>"></i>R$ <?= number_format($auto3->getPreco()); ?>.00 </th>
            <th><i id="preco4" class="<?= ($preco4 == $melhorPreco) ? "large green checkmark icon" : "large red close icon"; ?>"></i>R$ <?= number_format($auto4->getPreco()); ?>.00 </th>
        </tr>
        <tr>
            <th>Altura</th>

            <?php $melhorAlt = altura($auto1->getAltura(), $auto2->getAltura(), $auto3->getAltura(), $auto4->getAltura());
            $alt1 = $auto1->getAltura();
            $alt2 = $auto2->getAltura();
            $alt3 = $auto3->getAltura();
            $alt4 = $auto4->getAltura();
            ?>

            <th><i id="alt1" class="<?= ($alt1 == $melhorAlt) ? "large green checkmark icon" : "large red close icon"; ?>"></i><?= $auto1->getAltura(); ?> mm</th>
            <th><i id="alt2" class="<?= ($alt2 == $melhorAlt) ? "large green checkmark icon" : "large red close icon"; ?>"></i><?= $auto2->getAltura(); ?> mm</th>
            <th><i id="alt3" class="<?= ($alt3 == $melhorAlt) ? "large green checkmark icon" : "large red close icon"; ?>"></i><?= $auto3->getAltura(); ?> mm</th>
            <th><i id="alt4" class="<?= ($alt4 == $melhorAlt) ? "large green checkmark icon" : "large red close icon"; ?>"></i><?= $auto4->getAltura(); ?> mm</th>
        </tr>
        <tr>
            <th>Comprimento</th>

            <?php $melhorCom = comprimento($auto1->getComprimento(), $auto2->getComprimento(), $auto3->getComprimento(), $auto4->getComprimento());
            $com1 = $auto1->getComprimento();
            $com2 = $auto2->getComprimento();
            $com3 = $auto3->getComprimento();
            $com4 = $auto4->getComprimento();
            ?>

            <th><i id="com1" class="<?= ($com1 == $melhorCom) ? "large green checkmark icon" : "large red close icon"; ?>"></i><?= $auto1->getComprimento(); ?> mm</th>
            <th><i id="com2" class="<?= ($com2 == $melhorCom) ? "large green checkmark icon" : "large red close icon"; ?>"></i><?= $auto2->getComprimento(); ?> mm</th>
            <th><i id="com3" class="<?= ($com3 == $melhorCom) ? "large green checkmark icon" : "large red close icon"; ?>"></i><?= $auto3->getComprimento(); ?> mm</th>
            <th><i id="com4" class="<?= ($com4 == $melhorCom) ? "large green checkmark icon" : "large red close icon"; ?>"></i><?= $auto4->getComprimento(); ?> mm</th>
        </tr>
        <tr>


            <th>Largura</th>

            <?php $melhorLar = largura($auto1->getLargura(), $auto2->getLargura(), $auto3->getLargura(), $auto4->getLargura());
            $lar1 = $auto1->getLargura();
            $lar2 = $auto2->getLargura();
            $lar3 = $auto3->getLargura();
            $lar4 = $auto4->getLargura();
            ?>

            <th><i id="lar1" class="<?= ($lar1 == $melhorLar) ? "large green checkmark icon" : "large red close icon"; ?>"></i><?= $auto1->getLargura(); ?> mm</th>
            <th><i id="lar2" class="<?= ($lar2 == $melhorLar) ? "large green checkmark icon" : "large red close icon"; ?>"></i><?= $auto2->getLargura(); ?> mm</th>
            <th><i id="lar3" class="<?= ($lar3 == $melhorLar) ? "large green checkmark icon" : "large red close icon"; ?>"></i><?= $auto3->getLargura(); ?> mm</th>
            <th><i id="lar4" class="<?= ($lar4 == $melhorLar) ? "large green checkmark icon" : "large red close icon"; ?>"></i><?= $auto4->getLargura(); ?> mm</th>
        </tr>
        <tr>
            <th>Velocidade</th>

            <?php $melhorVel = velocidade($auto1->getVelocidade(), $auto2->getVelocidade(), $auto3->getVelocidade(), $auto4->getvelocidade());

            $vel1 = $auto1->getVelocidade();
            $vel2 = $auto2->getVelocidade();
            $vel3 = $auto3->getVelocidade();
            $vel4 = $auto4->getVelocidade();

            ?>

            <th><i id="vel1" class="<?= ($vel1 == $melhorVel) ? "large green checkmark icon" : "large red close icon"; ?>"></i><?= $auto1->getVelocidade(); ?> km/h</th>
            <th><i id="vel2" class="<?= ($vel2 == $melhorVel) ? "large green checkmark icon" : "large red close icon"; ?>"></i><?= $auto2->getVelocidade(); ?> km/h</th>
            <th><i id="vel3" class="<?= ($vel3 == $melhorVel) ? "large green checkmark icon" : "large red close icon"; ?>"></i><?= $auto3->getVelocidade(); ?> km/h</th>
            <th><i id="vel4" class="<?= ($vel4 == $melhorVel) ? "large green checkmark icon" : "large red close icon"; ?>"></i><?= $auto4->getVelocidade(); ?> km/h</th>
        </tr>
        <tr>
            <th>Tanque combustivel</th>

            <?php $melhorTqc = tq_combustivel($auto1->getTanqueCombustivel(), $auto2->getTanqueCombustivel(), $auto3->getTanqueCombustivel(), $auto4->getTanqueCombustivel());

            $tqc1 = $auto1->getTanqueCombustivel();
            $tqc2 = $auto2->getTanqueCombustivel();
            $tqc3 = $auto3->getTanqueCombustivel();
            $tqc4 = $auto4->getTanqueCombustivel();

            ?>

            <th><i id="tqc1" class="<?= ($tqc1 == $melhorTqc) ? "large green checkmark icon" : "large red close icon"; ?>"></i><?= $auto1->getTanqueCombustivel(); ?> litros</th>
            <th><i id="tqc2" class="<?= ($tqc2 == $melhorTqc) ? "large green checkmark icon" : "large red close icon"; ?>"></i><?= $auto2->getTanqueCombustivel(); ?> litros</th>
            <th><i id="tqc3" class="<?= ($tqc3 == $melhorTqc) ? "large green checkmark icon" : "large red close icon"; ?>"></i><?= $auto3->getTanqueCombustivel(); ?> litros</th>
            <th><i id="tqc4" class="<?= ($tqc4 == $melhorTqc) ? "large green checkmark icon" : "large red close icon"; ?>"></i><?= $auto4->getTanqueCombustivel(); ?> litros</th>
        </tr>
        <tr>
            <th>Tipo de direção</th>
            <?php $melhorDir = direcao($auto1->getTipDirecao(), $auto2->getTipDirecao(), $auto3->getTipDirecao(), $auto4->getTipDirecao());

            $d1 = $auto1->getTipDirecao();
            $d2 = $auto2->getTipDirecao();
            $d3 = $auto3->getTipDirecao();
            $d4 = $auto4->getTipDirecao();

            ?>

            <th><i id="d1" class="<?= ($d1 == $melhorDir) ? "large green checkmark icon" : "large red close icon"; ?>"></i><?= $auto1->getTipDirecao(); ?> </th>
            <th><i id="d2" class="<?= ($d2 == $melhorDir) ? "large green checkmark icon" : "large red close icon"; ?>"></i><?= $auto2->getTipDirecao(); ?> </th>
            <th><i id="d3" class="<?= ($d3 == $melhorDir) ? "large green checkmark icon" : "large red close icon"; ?>"></i><?= $auto3->getTipDirecao(); ?> </th>
            <th><i id="d4" class="<?= ($d4 == $melhorDir) ? "large green checkmark icon" : "large red close icon"; ?>"></i><?= $auto4->getTipDirecao(); ?> </th>

        </tr>
        <tr>
            <th>Tipo combustivel</th>
            <?php $melhorTpc = tp_combustivel($auto1->getTipCombustivel(), $auto2->getTipCombustivel(), $auto3->getTipCombustivel(), $auto4->getTipCombustivel());

            $tpc1 = $auto1->getTipCombustivel();
            $tpc2 = $auto2->getTipCombustivel();
            $tpc3 = $auto3->getTipCombustivel();
            $tpc4 = $auto4->getTipCombustivel();

            ?>

            <th><i id="tpc1" class="<?= ($tpc1 == $melhorTpc) ? "large green checkmark icon" : "large red close icon"; ?>"></i><?= $auto1->getTipCombustivel(); ?> </th>
            <th><i id="tpc2" class="<?= ($tpc2 == $melhorTpc) ? "large green checkmark icon" : "large red close icon"; ?>"></i><?= $auto2->getTipCombustivel(); ?> </th>
            <th><i id="tpc3" class="<?= ($tpc3 == $melhorTpc) ? "large green checkmark icon" : "large red close icon"; ?>"></i><?= $auto3->getTipCombustivel(); ?> </th>
            <th><i id="tpc4" class="<?= ($tpc4 == $melhorTpc) ? "large green checkmark icon" : "large red close icon"; ?>"></i><?= $auto4->getTipCombustivel(); ?> </th>

        </tr>
        <tr>
            <th>Porta malas</th>
            <?php $melhorPor = portaMalas($auto1->getPortaMalas(), $auto2->getPortaMalas(), $auto3->getPortaMalas(), $auto4->getPortaMalas());

            $por1 = $auto1->getPortaMalas();
            $por2 = $auto2->getPortaMalas();
            $por3 = $auto3->getPortaMalas();
            $por4 = $auto4->getPortaMalas();

            ?>

            <th><i id="por1" class="<?= ($por1 == $melhorPor) ? "large green checkmark icon" : "large red close icon"; ?>"></i><?= $auto1->getPortaMalas(); ?> litros </th>
            <th><i id="por2" class="<?= ($por2 == $melhorPor) ? "large green checkmark icon" : "large red close icon"; ?>"></i><?= $auto2->getPortaMalas(); ?> litros </th>
            <th><i id="por3" class="<?= ($por3 == $melhorPor) ? "large green checkmark icon" : "large red close icon"; ?>"></i><?= $auto3->getPortaMalas(); ?> litros </th>
            <th><i id="por4" class="<?= ($por4 == $melhorPor) ? "large green checkmark icon" : "large red close icon"; ?>"></i><?= $auto4->getPortaMalas(); ?> litros </th>
        </tr>

        <tr>
            <th>Consumo Urbano Gasolina</th>
            <?php $melhorconuG = consumoUrbGas($auto1->getConsumoUrbGas(), $auto2->getConsumoUrbGas(), $auto3->getConsumoUrbGas(), $auto4->getConsumoUrbGas());

            $conuG1 = $auto1->getConsumoUrbGas();
            $conuG2 = $auto2->getConsumoUrbGas();
            $conuG3 = $auto3->getConsumoUrbGas();
            $conuG4 = $auto4->getConsumoUrbGas();

            ?>

            <th><i id="conG1" class="<?= ($conuG1 == $melhorconuG) ? "large green checkmark icon" : "large red close icon"; ?>"></i><?= $auto1->getConsumoUrbGas();

                if ($conuG1 == null){
                    echo "Não utiliza esse combustivel!";
                } else {
                    echo " km/l (G)";
                }?></th>

            <th><i id="conG2" class="<?= ($conuG2 == $melhorconuG) ? "large green checkmark icon" : "large red close icon"; ?>"></i><?= $auto2->getConsumoUrbGas();

                if ($conuG2 == null){
                    echo "Não utiliza esse combustivel!";
                } else {
                    echo " km/l (G)";
                }?></th>

            <th><i id="conG3" class="<?= ($conuG3 == $melhorconuG) ? "large green checkmark icon" : "large red close icon"; ?>"></i><?= $auto3->getConsumoUrbGas();

                if ($conuG3 == null){
                    echo "Não utiliza esse combustivel!";
                } else {
                    echo " km/l (G)";
                }?></th>

            <th><i id="conG4" class="<?= ($conuG4 == $melhorconuG) ? "large green checkmark icon" : "large red close icon"; ?>"></i><?= $auto4->getConsumoUrbGas();

                if ($conuG4 == null){
                    echo "Não utiliza esse combustivel!";
                } else {
                    echo " km/l (G)";
                }?></th>

        </tr>
        <tr>
            <th>Consumo Urbano Alcool</th>
            <?php $melhorConuA = consumoUrbAlc($auto1->getConsumoUrbAlc(), $auto2->getConsumoUrbAlc(), $auto3->getConsumoUrbAlc(), $auto4->getConsumoUrbAlc());

            $conuA1 = $auto1->getConsumoUrbAlc();
            $conuA2 = $auto2->getConsumoUrbAlc();
            $conuA3 = $auto3->getConsumoUrbAlc();
            $conuA4 = $auto4->getConsumoUrbAlc();

            ?>

            <th><i id="conA1" class="<?= ($conuA1 == $melhorConuA) ? "large green checkmark icon" : "large red close icon"; ?>"></i><?= $auto1->getConsumoUrbAlc();

                if ($conuA1 == null){
                    echo "Não utiliza esse combustivel!";
                } else {
                    echo " km/l (A)";
                }?></th>

            <th><i id="conA2" class="<?= ($conuA2 == $melhorConuA) ? "large green checkmark icon" : "large red close icon"; ?>"></i><?= $auto2->getConsumoUrbAlc();

                if ($conuA2 == null){
                    echo "Não utiliza esse combustivel!";
                } else {
                    echo " km/l (A)";
                }?></th>

            <th><i id="conA3" class="<?= ($conuA3 == $melhorConuA) ? "large green checkmark icon" : "large red close icon"; ?>"></i><?= $auto3->getConsumoUrbAlc();

                if ($conuA3 == null){
                    echo "Não utiliza esse combustivel!";
                } else {
                    echo " km/l (A)";
                }?></th>

            <th><i id="conA4" class="<?= ($conuA4 == $melhorConuA) ? "large green checkmark icon" : "large red close icon"; ?>"></i><?= $auto4->getConsumoUrbAlc();

                if ($conuA4 == null){
                    echo "Não utiliza esse combustivel!";
                } else {
                    echo " km/l (A)";
                }?></th>

        </tr>
        <tr>
            <th>Consumo rodoviario Gasolina</th>
            <?php $melhorConrG = consumoRodGas($auto1->getConsumoRodGas(), $auto2->getConsumoRodGas(), $auto3->getConsumoRodGas(), $auto4->getConsumoRodGas());

            $conrG1 = $auto1->getConsumoRodGas();
            $conrG2 = $auto2->getConsumoRodGas();
            $conrG3 = $auto3->getConsumoRodGas();
            $conrG4 = $auto4->getConsumoRodGas();

            ?>

            <th><i id="rodG1" class="<?= ($conrG1 == $melhorConrG) ? "large green checkmark icon" : "large red close icon"; ?>"></i><?= $auto1->getConsumoRodGas();

            if ($conrG1 == null){
                    echo "Não utiliza esse combustivel!";
                } else {
                    echo " km/l (G)";
                }?></th>

            <th><i id="rodG2" class="<?= ($conrG2 == $melhorConrG) ? "large green checkmark icon" : "large red close icon"; ?>"></i><?= $auto2->getConsumoRodGas();

                if ($conrG2 == null){
                    echo "Não utiliza esse combustivel!";
                } else {
                    echo " km/l (G)";
                }?></th>

            <th><i id="rodG3" class="<?= ($conrG3 == $melhorConrG) ? "large green checkmark icon" : "large red close icon"; ?>"></i><?= $auto3->getConsumoRodGas();

            if ($conrG3 == null){
                    echo "Não utiliza esse combustivel!";
                } else {
                    echo " km/l (G)";
                }?></th>

            <th><i id="rodG4" class="<?= ($conrG4 == $melhorConrG) ? "large green checkmark icon" : "large red close icon"; ?>"></i><?= $auto4->getConsumoRodGas();

                if ($conrG4 == null){
                    echo "Não utiliza esse combustivel!";
                } else {
                    echo " km/l (G)";
                }?></th>

        </tr>
        <tr>
            <th>Consumo rodoviario Alcool</th>
            <?php $melhorConrA = consumoRodAlc($auto1->getConsumoRodAlc(), $auto2->getConsumoRodAlc(), $auto3->getConsumoRodAlc(), $auto4->getConsumoRodAlc());

            $conrA1 = $auto1->getConsumoRodAlc();
            $conrA2 = $auto2->getConsumoRodAlc();
            $conrA3 = $auto3->getConsumoRodAlc();
            $conrA4 = $auto4->getConsumoRodAlc();

            ?>

            <th><i id="rodA1" class="<?= ($conrA1 == $melhorConrA) ? "large green checkmark icon" : "large red close icon"; ?>"></i><?= $auto1->getConsumoRodAlc();

                if ($conrA1 == null){
                    echo "Não utiliza esse combustivel!";
                } else {
                    echo " km/l (A)";
                }?></th>

            <th><i id="rodA2" class="<?= ($conrA2 == $melhorConrA) ? "large green checkmark icon" : "large red close icon"; ?>"></i><?= $auto2->getConsumoRodAlc();

                if ($conrA2 == null){
                    echo "Não utiliza esse combustivel!";
                } else {
                    echo " km/l (A)";
                }?></th>

            <th><i id="rodA3" class="<?= ($conrA3 == $melhorConrA) ? "large green checkmark icon" : "large red close icon"; ?>"></i><?= $auto3->getConsumoRodAlc();

                if ($conrA3 == null){
                    echo "Não utiliza esse combustivel!";
                } else {
                    echo " km/l (A)";
                }?></th>

            <th><i id="rodA4" class="<?= ($conrA4 == $melhorConrA) ? "large green checkmark icon" : "large red close icon"; ?>"></i><?= $auto4->getConsumoRodAlc();

                if ($conrA4 == null){
                    echo "Não utiliza esse combustivel!";
                } else {
                    echo " km/l (A)";
                }?></th>

        </tr>
        <tr>
            <th>Marcha</th>
            <?php $melhorMar = marchas($auto1->getMarcha(), $auto2->getMarcha(), $auto3->getMarcha(), $auto4->getMarcha());

            $mar1 = $auto1->getMarcha();
            $mar2 = $auto2->getMarcha();
            $mar3 = $auto3->getMarcha();
            $mar4 = $auto4->getMarcha();

            ?>

            <th><i id="mar1" class="<?= ($mar1 == $melhorMar) ? "large green checkmark icon" : "large red close icon"; ?>"></i><?= $auto1->getMarcha(); ?> marchas</th>
            <th><i id="mar2" class="<?= ($mar2 == $melhorMar) ? "large green checkmark icon" : "large red close icon"; ?>"></i><?= $auto2->getMarcha(); ?> marchas</th>
            <th><i id="mar3" class="<?= ($mar3 == $melhorMar) ? "large green checkmark icon" : "large red close icon"; ?>"></i><?= $auto3->getMarcha(); ?> marchas</th>
            <th><i id="mar4" class="<?= ($mar4 == $melhorMar) ? "large green checkmark icon" : "large red close icon"; ?>"></i><?= $auto4->getMarcha(); ?> marchas</th>
        </tr>
        <tr>
            <th>Ocupantes</th>
            <?php $melhorOcu = ocupante($auto1->getOcupantes(), $auto2->getOcupantes(), $auto3->getOcupantes(), $auto4->getOcupantes());

            $ocu1 = $auto1->getOcupantes();
            $ocu2 = $auto2->getOcupantes();
            $ocu3 = $auto3->getOcupantes();
            $ocu4 = $auto4->getOcupantes();

            ?>

            <th><i id="ocu1" class="<?= ($ocu1 == $melhorOcu) ? "large green checkmark icon" : "large red close icon"; ?>"></i><?= $auto1->getOcupantes(); ?> passageiros</th>
            <th><i id="ocu2" class="<?= ($ocu2 == $melhorOcu) ? "large green checkmark icon" : "large red close icon"; ?>"></i><?= $auto2->getOcupantes(); ?> passageiros</th>
            <th><i id="ocu3" class="<?= ($ocu3 == $melhorOcu) ? "large green checkmark icon" : "large red close icon"; ?>"></i><?= $auto3->getOcupantes(); ?> passageiros</th>
            <th><i id="ocu4" class="<?= ($ocu4 == $melhorOcu) ? "large green checkmark icon" : "large red close icon"; ?>"></i><?= $auto4->getOcupantes(); ?> passageiros</th>
        </tr>
        <tr>
            <th>Câmbio</th>

            <th><i id="cam1"></i><?= $auto1->getCambio(); ?></th>
            <th><i id="cam2"></i><?= $auto2->getCambio(); ?> </th>
            <th><i id="cam3"></i><?= $auto3->getCambio(); ?> </th>
            <th><i id="cam4"></i><?= $auto4->getCambio(); ?> </th>
        </tr>
        <tr>
            <th>Tipo de freio</th>
            <th><i id="tipF1"></i><?= $auto1->getTipFreio(); ?></th>
            <th><i id="tipF2"></i><?= $auto2->getTipFreio(); ?> </th>
            <th><i id="tipF3"></i><?= $auto3->getTipFreio(); ?> </th>
            <th><i id="tipF4"></i><?= $auto4->getTipFreio(); ?> </th>
        </tr>
        <tr>
            <th>Tipo do veiculo</th>
            <th><i id="tipV1"></i><?= $auto1->getTipVeiculo(); ?></th>
            <th><i id="tipV2"></i><?= $auto2->getTipVeiculo(); ?> </th>
            <th><i id="tipV3"></i><?= $auto3->getTipVeiculo(); ?> </th>
            <th><i id="tipV4"></i><?= $auto4->getTipVeiculo(); ?> </th>
        </tr>
        <tr>
            <th>Tipo de tração</th>
            <th><i id="tipT1"></i><?= $auto1->getTipTracao(); ?></th>
            <th><i id="tipT2"></i><?= $auto2->getTipTracao(); ?> </th>
            <th><i id="tipT3"></i><?= $auto3->getTipTracao(); ?> </th>
            <th><i id="tipT4"></i><?= $auto4->getTipTracao(); ?> </th>
        </tr>
        <tr>
            <th>Porte</th>
            <th><i id="porte1"></i><?= $auto1->getPorte(); ?></th>
            <th><i id="porte2"></i><?= $auto2->getPorte(); ?> </th>
            <th><i id="porte3"></i><?= $auto3->getPorte(); ?> </th>
            <th><i id="porte4"></i><?= $auto4->getPorte(); ?> </th>
        </tr>
        </thead>
    </table>
</div>
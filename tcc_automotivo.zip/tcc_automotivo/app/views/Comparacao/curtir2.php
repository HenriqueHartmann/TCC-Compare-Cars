<th>Curtir</th>
<th>
    <button id="but1" class="circular ui icon button curtir1">
        <span class="qtdcurtida1"></span>
        <i class="icon thumbs up outline"></i>
    </button>
</th>
<th>
    <button id="but2" class="circular ui icon button curtir2">
        <span class="qtdcurtida2"></span>
        <i class="icon thumbs up outline"></i>
    </button>
</th>
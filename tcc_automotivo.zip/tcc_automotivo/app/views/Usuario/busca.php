<table class="ui celled padded table">
    <thead>
    <tr>
        <th>Modelos</th>
        <th>Montadora</th>

    </tr>
    </thead>
    <tbody>
    <h1 class="ui header centered" style="font-family: jellee">Resultados por: <?= $_POST['montadora'] ?></h1>
    <?php
    if($modelos != null) {

        foreach ($modelos as $modelo):
            $crud = new CrudMontadora();
            ?>

            <tr>
                <td><?= $modelo->getNomemodelo() ?></td>
                <td><?= $nome ?></td>
            </tr>

        <?php endforeach;

    }else{

        echo "<div class=\"ui middle aligned center aligned grid\">

        <div class=\"column\">
            <div class=\"content\">
                <h2 class='teal' \">Sem Modelos existentes</h2>
            </div>";

        $modelo = new Modelo();
    }
    ?>
    </tbody>
</table>
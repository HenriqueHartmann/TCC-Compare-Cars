<div class="ui container fluid index">
    <h1 class="ui header center aligned">Meus Favoritos<i class="paperclip icon green"></i></h1>
    <div class="reload-fav">

    </div>
</div>
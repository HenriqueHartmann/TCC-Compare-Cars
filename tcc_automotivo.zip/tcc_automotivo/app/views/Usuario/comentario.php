    <div style="padding-top: 2.7%!important;" id="container" class="ui container">
        <div class="ui comments small">
            <h1 class="ui header center aligned">Comentários <i class="comment outline icon primary"></i></h1>
            <form method="post" class="ui form" action="controladorUsuario.php?acao=comentar">
                <input type="hidden" name="acao" value="comentar" >
                <div class="field">
                    <textarea name="comentario_campo"></textarea>
                </div>
                <button id="coment" type="submit" class="ui primary submit labeled icon button" value="comentar">
                    <i class="icon edit" id="comentar"> </i>comentar
                </button>

            </form>
            <?php
            $comentarioo = new CrudComentario();
            $comentarios = $comentarioo->getComentarios();
            $pend = $comentarios[0]->getPendente();
            if($pend[0] == 3){
                echo('<h3 class="ui header center aligned"><i class="icon meh"></i>Sem comentários</h3>');
            }
            else {
                foreach ($comentarios as $comentario): ?>

                    <div class="ui divider"></div>
                    <div class="comment">
                        <div>
                            <?php $id = $comentario->getUsuarioIdusuario() ?>
                            <p><?= $comentarioo->getUsuarioEmail($id) ?></p>
                            <div class="metadata">
                                <p><?=$comentario->getData() ?></p>
                            </div>
                            <div class="text">
                                <p><?= $comentario->getTexto() ?></p>
                            </div>

                            <?php
                            if (esta_logado() && e_admin()) {
                                ?>
                                <a href="controladorAdmin.php?acao=excluircomentario&codigocom=<?=$comentario->getIdcomentario()?>&page=comum"
                                   class="ui submit icon labeled mini red button">
                                    <i class="trash alternate outline icon large"></i>Excluir
                                </a>
                                <?php
                            } ?>
                        </div>
                    </div>
                    <!---->
                    <!--        <!--    <form class="ui reply form">-->
                    <!--        <!--        <div class="field">-->
                    <!--        <!--            <textarea></textarea>-->
                    <!--        <!--        </div>-->
                    <!--        <!--        <div class="ui primary submit labeled icon button">-->
                    <!--        <!--            <i class="icon edit" id="comentar"> </i> responder-->
                    <!--        <!--        </div>-->
                    <!--        <!--    </form>-->
                    <!---->
                <?php endforeach;
            }   ?>

        </div>
    </div>
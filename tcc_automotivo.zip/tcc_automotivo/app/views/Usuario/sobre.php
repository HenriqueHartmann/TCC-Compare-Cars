    <div class="ui container index">
        <div class="ui middle aligned center aligned grid">
            <div class="column">
                <div class="content">
                    <h1 style="color: #000;">Sobre e Contatos</h1>
                </div>
            </div>
        </div>
        <div class="ui link cards middle aligned center aligned grid">
            <div class="card">
                <div class="image">
                    <img src="../../assets/images/christian.jpg">
                </div>
                <div class="content">
                    <div class="header">André Luiz Pacheco da Costa</div>
                    <div class="meta">
                        <a>Aluno</a>
                    </div>
                    <div class="description">
                        André é morador de São Francisco do Sul (SC) possui 18 anos, estudante IFC Araquari. Email para contato: <a>anddreluiz1@gmail.com</a>
                    </div>
                </div>
                <div class="extra content">
              <span class="right floated">
                Entrou na instituição em 2016
              </span>

                </div>
            </div>
            <div class="card">
                <div class="image">
                    <img src="../../assets/images/steve.jpg">
                </div>
                <div class="content">
                    <div class="header">Gean Carlos Santos da Silva</div>
                    <div class="meta">
                        <span class="date">Aluno</span>
                    </div>
                    <div class="description">
                        Gean é morador de São Francisco do Sul (SC) possui 18 anos, estudante do IFC Araquari. Email para contato: <a>torinoge@gmail.com</a>
                    </div>
                </div>
                <div class="extra content">
              <span class="right floated">
                Entrou na instituição em 2016

                </div>
            </div>
            <div class="card">
                <div class="image">
                    <img src="../../assets/images/mark.png">
                </div>
                <div class="content">
                    <div class="header">Henrique Luiz Hartmann</div>
                    <div class="meta">
                        <a>Aluno</a>
                    </div>
                    <div class="description">
                        Henrique é morador de Joinville (SC) possui 18 anos, estudante do IFC Araquari. Email para contato: <a>alemaohartmann@gmail.com</a>
                    </div>
                </div>
                <div class="extra content">
              <span class="right floated">
                  Entrou na instituição em 2016
              </span>

                </div>
            </div>
        </div>
            <br>
            <br>
            <div class="ui center aligned two column grid">
                <div class="column">
                    <div class="ui center aligned">
                        <h1>Com duvida em procurar um veiculo? </h1>
                        <p>Nós do <b>versus</b> te ajudaremos em achar a melhor opção para você</p>
                    </div>
                </div>
                <div class="column">
                    <div class="ui center aligned">
                        <h1>Para quem não nos conhece!</h1>
                        <p>Somos estudantes do instituto federal catarinense campus araquari na qual estamos desenvolvendo esse site para ajudar aqueles usuarios que possuem duvidas na hora de escolher o seu veiculo</p>
                    </div>
                </div>
            </div>
            <br>
        <div class="ui divider"></div>
            <div class="ui center aligned two column grid">
                <div class="column">
                    <div class="ui center aligned">
                        <h1>Nosso diferencial!</h1>
                        <p>Fizemos o site com base em outras aplicações, e colocamos itens que podem facilitar a sua vida</p>
                    </div>
                </div>

            <br>

                <div class="column">
                    <div class="ui center aligned">
                        <h1>Como Funciona?</h1>
                        <p>No site o usuario vai poder utilizar as colunas para escolher os veiculos que queira comparar, onde na qual deve se escolher dois de obrigação para a consulta funcionar!</p>
                    </div>
                </div>
            </div>
        <h1 class="ui header">Objetivo Geral</h1>
        <p>Compare Cars, possibilita que o usuário possa comparar diferentes modelos de veículos, auxiliando as pessos na tomada de
            decisão sobre troca ou compra de um novo veículo.</p>
        <h1 class="ui header">Tutorial</h1>
        <p>Então vamos começar com o nosso tutorial rápido e simples.</p>
        <p><span style="color: #21ba45;">1° Passo</span>, ir para a seleção da quantidade de veículos a serem comparados.
            Vá em qualquer uma das págians, basta você ir para o menu e clicar em cima de comparação.
            Pronto você está na página de seleção da quantidade de veículos a serem comparados.</p>
        <img class="ui centered large image rounded" data-src="../../../assets/images/tutorial1.png" src="../../assets/images/tut1.png">
        <p><span style="color: #21ba45;">2° Passo</span>, agora você está na página de seleção da quantidade de veículos a serem comparados.
            Então você tem a opção, de comparar 2,3 ou até 4 veículos.</p>
        <img class="ui centered large image rounded" data-src="../../../assets/images/tut2.png" src="../../assets/images/tut2.png">
        <p><span style="color: #21ba45;">3° Passo</span>, após a sua escolha você será direcionado a uma página de seleção dos modelos,
            você irá escolher a marca, modelo e o ano desejado, então clique em "Enviar".</p>
        <img class="ui centered large image rounded" data-src="../../../assets/images/tut3.png" src="../../assets/images/tut3.png">
        <p><span style="color: #21ba45;">4° Passo</span>, agora basta curtir a sua comparação.</p>
        <img class="ui centered large image rounded" data-src="../../../assets/images/tut4.png" src="../../assets/images/tut4.png">
    </div>
<!-- FOOTER -->
<!--<div class="space"></div>-->
<div class="ui inverted vertical footer segment">
    <div class="ui container">
        Compare Cars 2018. Todos direitos reservados
    </div>
</div>
</div>
</body>
</html>
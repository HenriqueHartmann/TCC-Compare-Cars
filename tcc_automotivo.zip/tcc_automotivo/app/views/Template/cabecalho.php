<!DOCTYPE html>
<html>
<head>
    <title>Compare Cars</title>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge,chrome=1">
    <meta name="viewport" content="width=device-width, initial-scale=1.0, maximum-scale=1.0">
    <link rel="stylesheet" href="https://netdna.bootstrapcdn.com/font-awesome/4.7.0/css/font-awesome.min.css">
    <link rel="stylesheet" type="text/css" href="../../node_modules/semantic-ui/dist/semantic.min.css">
    <link rel="stylesheet" href="../../assets/css/menureal.css">
    <link rel="stylesheet" href="../../assets/css/index.css">
    <link rel="stylesheet" href="../../assets/css/rodape.css">
    <script
        src="http://code.jquery.com/jquery-3.3.1.min.js"
        integrity="sha256-FgpCb/KJQlLNfOu91ta32o/NMZxltwRo8QtmkMRdAu8="
        crossorigin="anonymous"></script>
    <script src="../../node_modules/semantic-ui/dist/semantic.min.js"></script>
    <script src="../../assets/java script/sidebar.js"></script>
    <script src="../../assets/java script/autocomplete.js"></script>
    <script src="../../assets/java script/favoritos.js"></script>
    <script src="../../assets/java script/ranking.js"></script>
    <script src="../../assets/java script/background.js"></script>
    <script src="../../assets/java script/avisausuario.js"></script>

    <style type="text/css">
        @media only screen and (max-width: 700px) {
            .ui.fixed.menu {
                display: none !important;
            }
        }
    </style>
</head>
<body>
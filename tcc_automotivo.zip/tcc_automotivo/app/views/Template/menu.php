<!-- SIDE BAR -->
<div class="ui sidebar menu large compact container icon labeled vertical">
    <a class="active item" href="controladorUsuario.php"><img class="ui centered mini image" src="../../assets/images/icon.png"></a>
    <form class="ui form active item" method="POST" action="controladorUsuario.php?acao=busca">
        <div class="field">
            <div class="ui icon input">
                <input type="text" name="montadora" placeholder="Montadora">
                <i class="search icon"></i>
                <!--                            <button type="submit">Procurar</button>-->
            </div>
        </div>
    </form>
    <a class="item" href="controladorComparacao.php?acao=index">Comparar</a>
    <?php
    if(!esta_logado()){?>
        <a class="item" href="controladorUsuario.php?acao=pagcadastrar">Cadastrar</a>
        <a class="item" href="controladorUsuario.php?acao=paglogin">Login</a>
        <a class="item" href="controladorUsuario.php?acao=pagsobre">Sobre</a>
        <?php
    }
    if(esta_logado()){?>
        <a class="item" href="controladorUsuario.php?acao=pagcomentar">Comentários</a>
        <a class="item" href="controladorUsuario.php?acao=logout">Logout</a>
        <?php
        if (e_admin()){?>
            <a class="item" href="controladorAdmin.php?acao=decisao">Admin</a>
            <?php
        }
    }?>
</div>
<!-- MENU -->
<div class="pusher">
    <div class="ui container">
        <div class="ui secondary inverted top large pointing menu">
            <div class="left item">
                <a class="toc item">
                    <i style="color: #000000 !important;" class="sidebar icon"></i>
                </a>
                <a class="toc item" href="controladorUsuario.php?acao=busca"><h2>Compare cars</h2></a>
                <a class="active item" href="controladorUsuario.php"><img class="ui mini image" src="../../assets/images/icon.png"></a>
<!--                <form class="ui form toc item" method="POST" action="controladorUsuario.php?acao=busca">-->
<!--                    <div class="field">-->
<!--                        <div class="ui icon input">-->
<!--                            <input type="text" name="montadora" placeholder="Montadora">-->
<!--                            <i class="search icon"></i>-->
<!--<!--                            <button type="submit">Procurar</button>-->-->
<!--                        </div>-->
<!--                    </div>-->
<!--                </form>-->
                <form id="form-real" class="ui form active item focus" method="POST" action="controladorUsuario.php?acao=busca">
                    <div class="field">
                        <div class="ui massive icon input">
                            <input type="text" name="montadora" placeholder="Montadora">
                            <i class="search icon"></i>
<!--                            <button type="submit">Procurar</button>-->
                        </div>
                    </div>
                </form>
            </div>
            <div class="right item">
                <a class="item" href="controladorComparacao.php?acao=index">Comparar</a>
                <?php
                if(!esta_logado()){?>
                    <a class="item" href="controladorUsuario.php?acao=pagcadastrar">Cadastrar</a>
                    <a class="item" href="controladorUsuario.php?acao=paglogin">Login</a>
                    <a class="item" href="controladorUsuario.php?acao=pagsobre">Sobre</a>
                    <?php
                }
                if(esta_logado()){?>
                    <a class="item" href="controladorUsuario.php?acao=pagcomentar">Comentários</a>
                    <a class="item" href="controladorUsuario.php?acao=logout">Logout</a>
                    <?php
                    if (e_admin()){?>
                        <a class="item" href="controladorAdmin.php?acao=decisao">Admin</a>
                        <?php
                    }
                }?>
            </div>
        </div>
    </div>
<!-- SIDE BAR -->
<div class="ui sidebar menu large compact container icon labeled vertical">
    <a class="active item" href="controladorUsuario.php"><img class="ui centered mini image" src="../../assets/images/icon.png"></a>
    <form class="ui form active item" method="POST" action="controladorUsuario.php?acao=busca">
        <div class="field">
            <div class="ui icon input">
                <input type="text" name="montadora" placeholder="Montadora...">
                <i class="search icon"></i>
                <!--                            <button type="submit">Procurar</button>-->
            </div>
        </div>
    </form>
    <a class="item" href="controladorComparacao.php?acao=index">Comparar</a>
    <?php
    if(!esta_logado()){?>
        <a class="item" href="controladorUsuario.php?acao=pagcadastrar">Cadastrar</a>
        <a class="item" href="controladorUsuario.php?acao=paglogin">Login</a>
        <a class="item" href="controladorUsuario.php?acao=pagsobre">Sobre</a>
        <?php
    }
    if(esta_logado()){?>
        <a class="item" href="controladorUsuario.php?acao=pagcomentar">Comentários</a>
        <a class="item" href="controladorUsuario.php?acao=logout">Logout</a>
        <?php
        if (e_admin()){?>
            <a class="item" href="controladorAdmin.php?acao=decisao">Admin</a>
            <?php
        }
    }?>
</div>
<!-- MENU -->
<div class="pusher">
    <div class="ui container">
        <div class="ui secondary inverted top large pointing menu">
            <div class="left item">
                <a class="toc item">
                    <i style="color: #000000 !important;" class="sidebar icon"></i>
                </a>
                <a class="toc item" href="controladorUsuario.php?acao=busca"><h2>Compare cars</h2></a>
                <a class="active item" href="controladorUsuario.php"><img class="ui mini image" src="../../assets/images/icon.png"></a>
                <form id="form-real" class="ui search form active item focus" method="POST" action="controladorUsuario.php?acao=busca">
                    <div class="field">
                        <div class="ui massive icon input">
                            <input id="form-search" class="prompt" type="text" name="montadora" placeholder="Montadora...">
                            <i class="search icon"></i>
<!--                            <button type="submit">Procurar</button>-->
                        </div>
                    </div>
                </form>
                <script>
                    var content = [
                        { title: 'Acura' },
                        { title: 'Agrale' },
                        { title: 'Alfa Romeo' },
                        { title: 'AM Gean' },
                        { title: 'Asia Motors' },
                        { title: 'Audi' },
                        { title: 'BMW' },
                        { title: 'BRM' },
                        { title: 'Cadillac' },
                        { title: 'CBT Jipe' },
                        { title: 'Chrysler' },
                        { title: 'Citroën' },
                        { title: 'Cross Lander' },
                        { title: 'Daewoo' },
                        { title: 'Daihatsu' },
                        { title: 'Dodge' },
                        { title: 'Engesa' },
                        { title: 'Envemo' },
                        { title: 'Ferrari' },
                        { title: 'Fiat' },
                        { title: 'Ford' },
                        { title: 'GM - Chevrolet' },
                        { title: 'Gurgel' },
                        { title: 'Honda' },
                        { title: 'Hyundai' },
                        { title: 'Isuzu' },
                        { title: 'Jaguar' },
                        { title: 'Jeep' },
                        { title: 'JPX' },
                        { title: 'Kia Motors' },
                        { title: 'Lada' },
                        { title: 'Land Rover' },
                        { title: 'Lexus' },
                        { title: 'Lotus' },
                        { title: 'Maserati' },
                        { title: 'Matra' },
                        { title: 'Mazda' },
                        { title: 'Mercedes-Benz' },
                        { title: 'Mercury' },
                        { title: 'Mitsubishi' },
                        { title: 'Miura' },
                        { title: 'Nissan' },
                        { title: 'Peugeot' },
                        { title: 'Plymouth' },
                        { title: 'Pontiac' },
                        { title: 'Porsche' },
                        { title: 'Renault' },
                        { title: 'Rover' },
                        { title: 'Saab' },
                        { title: 'Saturn' },
                        { title: 'Seat' },
                        { title: 'Subaru' },
                        { title: 'Suzuki' },
                        { title: 'Toyota' },
                        { title: 'Troller' },
                        { title: 'Volvo' },
                        { title: 'VW - VolksWagen' },
                        { title: 'Walk' },
                        { title: 'Bugre' },
                        { title: 'SSANGYONG' },
                        { title: 'LOBINI' },
                        { title: 'CHANA' },
                        { title: 'Mahindra' },
                        { title: 'EFFA' },
                        { title: 'Fibravan' },
                        { title: 'HAFEI' },
                        { title: 'GREAT WALL' },
                        { title: 'JINBEI' },
                        { title: 'MINI' },
                        { title: 'Smart' },
                        { title: 'CHERY' },
                        { title: 'Wake' },
                        { title: 'TAC' },
                        { title: 'CHANGAN' },
                        { title: 'SHINERAY' },
                        { title: 'RAM' },
                        { title: 'Subaru' },
                        { title: 'Suzuki' },
                        { title: 'Toyota' },
                        { title: 'Troller' },
                        { title: 'Volvo' },
                        { title: 'VW - VolksWagen' },
                        { title: 'Walk' },
                        { title: 'Bugre' },
                        { title: 'SSANGYONG' },
                        { title: 'LOBINI' },
                        // etc
                    ];
                    $('.ui.search')
                        .search({
                            source: content,
                            searchFullText: false
                        });
                    var auto = document.getElementsByClassName('title');
                    auto.style.fontsize('15px !important');

                </script>
                </div>
            <div class="right item">
                <a class="item" href="controladorComparacao.php?acao=index">Comparar</a>
                <?php
                if(!esta_logado()){?>
                    <a class="item" href="controladorUsuario.php?acao=pagcadastrar">Cadastrar</a>
                    <a class="item" href="controladorUsuario.php?acao=paglogin">Login</a>
                    <a class="item" href="controladorUsuario.php?acao=pagsobre">Sobre</a>
                    <?php
                }
                if(esta_logado()){?>
                    <a class="item" href="controladorUsuario.php?acao=pagcomentar">Comentários</a>
                    <a class="item" href="controladorUsuario.php?acao=logout">Logout</a>
                    <?php
                    if (e_admin()){?>
                        <a class="item" href="controladorAdmin.php?acao=decisao">Admin</a>
                        <?php
                    }
                }?>
            </div>
        </div>
    </div>
<?php

require_once "../models/CrudMontadora.php";
require_once "../models/CrudModelo.php";
require_once "../models/CrudUsuario.php";
require_once "../models/CrudVeiculo.php";
require_once "../models/CrudComentario.php";
require_once "funcoes/sessao.php";

session_start();

if (esta_logado() and e_admin()) {
    if (isset($_GET['acao'])) {
        $acao = $_GET['acao'];
    } else {
        $acao = 'decisao';
    }

    switch ($acao) {
        case 'decisao':
            include_once "../views/Template/cabecalhoAdmin.php";
            include_once "../views/Template/menu.php";
            include_once "../views/Template/menuAdmin.php";
            include_once "../views/Template/rodapeAdmin.php";
            break;

        case 'lista':
            $crud = new CrudUsuario();
            $usuarios = $crud->getUsuarios();
            include_once "../views/Template/cabecalhoAdmin.php";
            include_once "../views/Template/menu.php";
            include_once "../views/Template/menuAdmin.php";
            include_once "../views/Admin/tabela usuario.php";
            include_once "../views/Template/rodapeAdmin.php";
            break;

        case 'cadastro':
            include_once "../views/Template/cabecalhoAdmin.php";
            include_once "../views/Template/menu.php";
            include_once "../views/Template/menuAdmin.php";
            include_once "../views/Admin/cadastraadmin.php";
            include_once "../views/Template/rodapeAdmin.php";
            break;

        case 'cadastrar':
            $user = new Usuario(null,$_POST['nome'], $_POST['email'], $_POST['senha'], $_POST['tipo']);
            $usercrud = new CrudUsuario();
            $usercrud->insertUsuario($user);
            header('location: ?acao=lista');
            break;

        case 'editar':
            $usercrud = new CrudUsuario();
            $codigo = $_GET['codigo'];
            $usuario = $usercrud->getUsuario($codigo);
            include_once "../views/Template/cabecalhoAdmin.php";
            include_once "../views/Template/menu.php";
            include_once "../views/Template/menuAdmin.php";
            include_once "../views/Admin/editaruser.php";
            include_once "../views/Template/rodapeAdmin.php";
            break;

        case 'updateuser':
            $usercrud = new CrudUsuario();
            $codigo = $_GET['codigo'];
            $user = new Usuario($codigo,$_POST['nome'], $_POST['email'], $_POST['senha'], $_POST['tipo']);
            $usercrud->updateUsuario($user);
            header('location: ?acao=lista');
            break;

        case 'excluiruser':
            $codigo = $_GET['codigo'];
            $usercrud = new CrudUsuario();
            $usercrud->excluirUsuario($codigo);
            header('location: controladorAdmin.php?acao=lista');
            break;

        case 'pagcomentario':
            include_once "../views/Template/cabecalhoAdmin.php";
            include_once "../views/Template/menu.php";
            include_once "../views/Template/menuAdmin.php";
            include_once '../views/Admin/comentarioAdmin.php';
            include_once "../views/Template/rodapeAdmin.php";
            break;

        case 'pagpendencias':
            include_once "../views/Template/cabecalhoAdmin.php";
            include_once "../views/Template/menu.php";
            include_once "../views/Template/menuAdmin.php";
            include_once "../views/Admin/comentpendente.php";
            include_once "../views/Template/rodapeAdmin.php";
            break;

        case 'ativarcomentario':
            $codigo = $_GET['codigocom'];
            $admincrud = new CrudComentario();
            $admincrud->ativarComentario($codigo);
            header('location: controladorAdmin.php?acao=pagcomentario');
            break;

        case 'excluircomentario':
            $codigo = $_GET['codigocom'];
            $admincrud = new CrudComentario();
            $admincrud->deleteComentario($codigo);
            header('location: controladorAdmin.php?acao=pagpendencias');
            break;

        case 'montadoras':
            $crud = new CrudMontadora();
            $montadoras = $crud->getMontadoras();
            include_once "../views/Template/cabecalhoAdmin.php";
            include_once "../views/Template/menu.php";
            include_once "../views/Template/menuAdmin.php";
            include_once "../views/Admin/tabela montadora.php";
            include_once "../views/Template/rodapeAdmin.php";
            break;

        case 'cadastromontadoras':
            include_once "../views/Template/cabecalhoAdmin.php";
            include_once "../views/Template/menu.php";
            include_once "../views/Template/menuAdmin.php";
            include_once "../views/Admin/cadastramontadora.php";
            include_once "../views/Template/rodapeAdmin.php";
            break;

        case 'cadastramontadora':
            $montadora = new Montadora($_POST['idmontadora'], $_POST['montadora']);
            $montadoracrud = new CrudMontadora();
            $montadoracrud->insertMontadora($montadora);
            header('location: ?acao=montadoras');

            break;

        case 'editarmontadora':
            $montcrud = new CrudMontadora();
            $codigo = $_GET['codigo'];
            $montadora = $montcrud->getMontadora($codigo);
            include_once "../views/Template/cabecalhoAdmin.php";
            include_once "../views/Template/menu.php";
            include_once "../views/Template/menuAdmin.php";
            include_once "../views/Admin/editarmontadora.php";
            include_once "../views/Template/rodapeAdmin.php";
            break;

        case 'excluirmontadora':
            $codigo = $_GET['codigo'];
            $montadora = new CrudMontadora();
            $montadora->deleteMontadora($codigo);
            header('Location: ?acao=montadoras');
            break;

        case 'updatemontadora':
            $crud = new CrudMontadora();
            $codigo = $_GET['codigo'];
            $montadora = new Montadora($_POST['idmontadora'], $_POST['montadora']);
            $crud->updateMontadora($montadora);
            header('Location: controladorAdmin.php?acao=montadoras');
            break;

        case 'modelo':
            $crud = new CrudModelo();
            $modelos = $crud->getModelos();
            include_once "../views/Template/cabecalhoAdmin.php";
            include_once "../views/Template/menu.php";
            include_once "../views/Template/menuAdmin.php";
            include_once "../views/Admin/tabela modelo.php";
            include_once "../views/Template/rodapeAdmin.php";
            break;

        case 'cadastramodelo':
            include_once "../views/Template/cabecalhoAdmin.php";
            include_once "../views/Template/menu.php";
            include_once "../views/Template/menuAdmin.php";
            include_once "../views/Admin/cadastrarmodelo.php";
            include_once "../views/Template/rodapeAdmin.php";
            break;

        case 'cadastrarmodelo':
            $modelo = new Modelo($_POST['idmodelo'],$_POST['nome_modelo'], $_POST['idmontadora'] );
            $crud = new CrudModelo();
            $modelocrud = $crud->insertModelo($modelo);
            header('location: controladorAdmin.php?acao=modelo');
            break;

        case 'editarmodelo':
            $modelcrud = new CrudModelo();
            $codigo = $_GET['codigo'];
            $modelo = $modelcrud->getModelo($codigo);
            include_once "../views/Template/cabecalhoAdmin.php";
            include_once "../views/Template/menu.php";
            include_once "../views/Template/menuAdmin.php";
            include_once "../views/Admin/editarmodelo.php";
            include_once "../views/Template/rodapeAdmin.php";
            break;

        case 'updatemodelo':
            $crud = new CrudModelo();
            $codigo = $_GET['codigo'];
//            echo $codigo;
//            echo "<br>";
//            echo $_POST['idmodelo'];
//            echo "<br>";
//            echo $_POST['nome_modelo'];
//            echo "<br>";
//            echo $_POST['idmontadora'];
            $modelo = new Modelo($_POST['idmodelo'], $_POST['nome_modelo'], $_POST['idmontadora']);
            $crud->updateModelo($modelo, $codigo);
            header('location: controladorAdmin.php?acao=modelo');
            break;

        case 'excluirmodelo':
            $codigo = $_GET['codigo'];
            $modelo = new CrudModelo();
            $modelo->deleteModelo($codigo);
            header('Location: controladorAdmin.php?acao=modelo');
            break;

            break;

        case 'especificacao':
            $crud = new CrudVeiculo();
            $veiculos = $crud->getVeiculos();
            include_once "../views/Template/cabecalhoAdmin.php";
            include_once "../views/Template/menu.php";
            include_once "../views/Template/menuAdmin.php";
            include_once "../views/Admin/tabela especificacao.php";
            include_once "../views/Template/rodapeAdmin.php";
            break;

        case 'pagcadastraespecificacao':
            include_once "../views/Template/cabecalhoAdmin.php";
            include_once "../views/Template/menu.php";
            include_once "../views/Template/menuAdmin.php";
            include_once "../views/Admin/cadastraespe.php";
            include_once "../views/Template/rodapeAdmin.php";
            break;

        case 'cadastraespec':

            $espec = new Veiculo($_POST['idveiculo'] ,$_POST['ano'], $_POST['potencia'], $_POST['portas'], $_POST['preco'], $_POST['altura'], $_POST['comprimento'], $_POST['largura'],
                $_POST['cambio'], $_POST['velocidade'], $_POST['tanque_combustivel'], $_POST['tip_combustivel'], $_POST['porta_malas'], $_POST['tip_direcao'], $_POST['consumo_urb_gas'], $_POST['consumo_urb_alc'],
                $_POST['consumo_rod_gas'], $_POST['consumo_rod_alc'], $_POST['marcha'], $_POST['tip_tracao'], $_POST['porte'], $_POST['ocupantes'], $_POST['tip_freio'], $_POST['tip_veiculo'], $_POST['idmodelo']);
            $crud = new CrudVeiculo();
            $especcrud = $crud->insertEspec($espec);
            header('location: controladorAdmin.php?acao=especificacao');
            break;

        case 'editarespec':
            $crudVeic = new CrudVeiculo();
            $codigo = $_GET['codigo'];
            $espec = $crudVeic->getVeiculo($codigo);
            include_once "../views/Template/cabecalhoAdmin.php";
            include_once "../views/Template/menu.php";
            include_once "../views/Template/menuAdmin.php";
            include_once "../views/Admin/editarespe.php";
            include_once "../views/Template/rodapeAdmin.php";
            break;

        case 'updateespec':
            $crud = new CrudVeiculo();
            $codigo = $_GET['codigo'];
            $veiculo = new Veiculo($_POST['idveiculo'], $_POST['ano'], $_POST['potencia'], $_POST['portas'], $_POST['preco'], $_POST['altura'], $_POST['comprimento'], $_POST['largura'],
                $_POST['cambio'], $_POST['velocidade'], $_POST['tanque_combustivel'], $_POST['tip_combustivel'], $_POST['porta_malas'], $_POST['tip_direcao'], $_POST['consumo_urb_gas'],
                $_POST['consumo_urb_alc'], $_POST['consumo_rod_gas'], $_POST['consumo_rod_alc'], $_POST['marcha'], $_POST['tip_tracao'], $_POST['porte'], $_POST['ocupantes'],
                $_POST['tip_freio'], $_POST['tip_veiculo']);

            $crud->updateEspec($veiculo);
            header('Location: controladorAdmin.php?acao=especificacao');
            break;

        case 'excluirespec':
            $codigo = $_GET['codigo'];
            $crudespec = new CrudVeiculo();
            $crudespec->deleteEspec($codigo);
            header('Location: controladorAdmin.php?acao=especificacao');
            break;

    }
}else{
    if(esta_logado()) {
        session_destroy();
    }
    header('location: controladorUsuario.php');
}
<?php
    require_once '../models/CrudComentario.php';
    require_once '../models/CrudUsuario.php';
    require_once '../models/CrudMontadora.php';
    require_once '../models/CrudModelo.php';
    require_once 'funcoes/sessao.php';

    session_start();

    if (isset($_GET['acao'])){
        $acao = $_GET['acao'];
    }else{
        $acao = 'index';
    }
    switch ($acao){

        case 'index':
            include_once "../views/Template/cabecalho.php";
            include_once "../views/Template/menu.php";
            include_once "../views/Pagina principal/index.php";
            include_once "../views/Template/rodape.php";
            break;

//        case 'menu decisao':
//            include_once "../views/Template/cabecalho.php";
//            include_once "";
//            include_once "../views/Usuario/decisão.php";
//            break;

        case 'pagsobre':
            include_once "../views/Template/cabecalho.php";
            include_once "../views/Template/menu.php";
            include_once "../views/Usuario/sobre.php";
            include_once "../views/Template/rodape.php";
            break;

        case 'pagcadastrar':
            include_once "../views/Template/cabecalho.php";
            include_once "../views/Template/menu.php";
            include_once "../views/Usuario/cadastro.php";
            include_once "../views/Template/rodape.php";
            break;

        case 'cadastrar':
            if (isset($_POST['nome']) and isset($_POST['email']) and isset($_POST['senha'])){
                $user = new Usuario(null,$_POST['nome'], $_POST['email'], $_POST['senha'], 'comum');
                $usercrud = new CrudUsuario();
                if($usercrud->existeUser($user)!= 1) {
                    $usercrud->insertUsuario($user);
                    header('location: controladorUsuario.php?acao=paglogin');
                }else{
                    header('location: controladorUsuario.php?acao=pagcadastrar&erro=2');
                }
            }else{
                header('location: controladorUsuario.php?acao=pagcadastrar&erro=1');
            }
            break;

        case 'paglogin':
            include_once "../views/Template/cabecalho.php";
            include_once "../views/Template/menu.php";
            include_once "../views/Usuario/login.php";
            include_once "../views/Template/rodape.php";
            break;

        case 'login':
            if(isset($_POST['email']) and isset($_POST['senha'])) {
            $user = new Usuario(null,null, $_POST['email'], $_POST['senha'], null);
            $usercrud = new CrudUsuario();
            if ($usercrud->loginUser($user) == 1){
                $_SESSION['logado'] = true;
                $id = $usercrud->descobreId($user);
                $_SESSION['id'] = $id;
                switch ($usercrud->verificaTipo($user)) {
                    case 'comum':
                        header('location: controladorUsuario.php?acao=index&id='.$_SESSION['id']);
                    break;

                    case 'admin':
                        $_SESSION['admin'] = true;
                        header('location: controladorUsuario.php?acao=index&id='.$_SESSION['id']);
                    break;
                }
            } else {
                header('location: controladorUsuario.php?acao=paglogin&erro=1');
            }
            }
            break;

        case 'logout':
            session_destroy();
            header('location: controladorUsuario.php?acao=index');
            break;

        case 'pagcomentar':
            include_once "../views/Template/cabecalho.php";
            include_once "../views/Template/menu.php";
            include_once "../views/Usuario/comentario.php";
            include_once "../views/Template/rodape.php";
            break;

        case 'comentar':
            $comentario = new Comentario(null,$_POST['comentario_campo'],null, 1, $_SESSION['id']);
            $crud = new CrudComentario();
            $crud->insertComentario($comentario);
            header('location: controladorUsuario.php?acao=pagcomentar');

        break;

        case 'busca':
            if(isset($_POST["montadora"])) {
                $nome = $_POST["montadora"];
                $crud = new CrudMontadora();
                $idmontadoras = $crud->getidMontadora($nome);
//                foreach ($idmontadoras as $idmontadora) {
//                    $modelo = new CrudModelo();
//                    $modelos = $modelo->getModelosPorMontadora($idmontadora);
////                    print_r($idmontadora);
////                    echo "<br>";
//                }
                include_once "../views/Template/cabecalho.php";
                include_once "../views/Template/menu.php";
                include_once "../views/Usuario/busca.php";
                include_once "../views/Template/rodape.php";
            }else{
                echo "NULL";
                header('location: controladorUsuario.php');
            }
            break;

            default :
                header('location: controladorUsuario.php?acao=index');
                break;
        }
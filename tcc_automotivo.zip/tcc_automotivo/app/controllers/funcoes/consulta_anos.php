<?php
require_once "../../models/CrudModelo.php";
require_once "../../models/DBConexao.php";

//recebe o parametro referente ao modelo via GET
$id_modelo = $_GET['idmodelo'];
//$id_modelo = 6171;
$crud = new CrudModelo();
$anos = $crud->getAnosPorModelo($id_modelo);
//print_r($anos);
//ALTEREI O ARQUIVO PARA QUE, EM VEZ DE ESCREVER UM ARQUIVO JSON, BUSQUE OS DADOS USANDO O MÉTODO E EXIBA O RESULTADO NA FORMA DE UM JSON

//altera o header do arquivo para json, em vez de HTML
header('Content-Type: application/json');
//o array retornado é convertido para JSON e exibido
echo json_encode($anos);


<?php
function esta_logado(){
    if (isset($_SESSION['logado']) && $_SESSION['logado'] == true){
        return true;
    } else {
        return false;
    }
}

function e_admin(){
    if (isset($_SESSION['admin']) && $_SESSION['admin'] == true){
        return true;
    } else {
        return false;
    }
}

//function getUserID(){
//    session_start();
//    $userid = 0;
//    if (!isset($_SESSION['id'])) {
//        $userid = $_SESSION['id'];
//    }
//
//    return $userid;
//}
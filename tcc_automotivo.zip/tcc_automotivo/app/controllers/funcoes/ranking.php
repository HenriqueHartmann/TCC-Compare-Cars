<?php

    require_once "../../models/CrudCurtidas.php";

    $crud = new CrudCurtidas();
    $ranking = $crud->ranking();
    ?>
    <table class="ui red celled striped table" >
        <thead>
            <tr>
                <th>Posição</th>
                <th>Quantidade de Curtidas</th>
                <th>Marca</th>
                <th>Nome</th>
                <th>Ano</th>
            </tr>
        </thead>
        <tbody>
            <tr>
                <td scope="row"><i class="icon trophy violet"></i> 1º Lugar</td>
                <td><?= $ranking[0]['qtd']; ?></td>
                <td><?= $ranking[0]['montadora']; ?></td>
                <td><?= $ranking[0]['nome_modelo']; ?></td>
                <td><?= $ranking[0]['ano']; ?></td>
            </tr>
            <tr>
                <td scope="row"><i class="icon trophy teal"></i> 2º Lugar</td>
                <td><?= $ranking[1]['qtd']; ?></td>
                <td><?= $ranking[1]['montadora']; ?></td>
                <td><?= $ranking[1]['nome_modelo']; ?></td>
                <td><?= $ranking[1]['ano']; ?></td>
            </tr>
            <tr>
                <td scope="row"><i class="icon trophy yellow"></i> 3º Lugar</td>
                <td><?= $ranking[2]['qtd']; ?></td>
                <td><?= $ranking[2]['montadora']; ?></td>
                <td><?= $ranking[2]['nome_modelo']; ?></td>
                <td><?= $ranking[2]['ano']; ?></td>
            </tr>
            <tr>
                <td scope="row"><i class="icon trophy grey"></i> 4º Lugar</td>
                <td><?= $ranking[3]['qtd']; ?></td>
                <td><?= $ranking[3]['montadora']; ?></td>
                <td><?= $ranking[3]['nome_modelo']; ?></td>
                <td><?= $ranking[3]['ano']; ?></td>
            </tr>
            <tr>
                <td scope="row"><i class="icon trophy orange"></i> 5º Lugar</td>
                <td><?= $ranking[4]['qtd']; ?></td>
                <td><?= $ranking[4]['montadora']; ?></td>
                <td><?= $ranking[4]['nome_modelo']; ?></td>
                <td><?= $ranking[4]['ano']; ?></td>
            </tr>
        </tbody>
    </table>
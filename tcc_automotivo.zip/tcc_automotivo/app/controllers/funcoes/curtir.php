<?php

    session_start();
    require_once "../../models/DBConexao.php";
    require_once "../../models/CrudCurtidas.php";
    $acao = $_POST['state'];
    switch ($acao) {


        case 'qtdcurtida':
            $idano = $_GET['idano'];
            $crud = new CrudCurtidas();
            $rlt = $crud->NCurtidas($idano);
            echo $rlt['COUNT(idcurtida)'];
            break;

        case 'verifica':
            $idano = $_GET['idano'];
            $iduser = $_SESSION['id'];
            $crud = new CrudCurtidas();
            $rlt = $crud->VerificaCurtida($idano, $iduser);
            echo $rlt['COUNT(idcurtida)'];
            break;

        case 'not':
            $idano = $_GET['idano'];
            $iduser = $_SESSION['id'];
            $crud = new CrudCurtidas();
            $rlt = $crud->InsertCurtida($idano, $iduser);
            break;

        case 'yes':
            $idano = $_GET['idano'];
            $iduser = $_SESSION['id'];
            $crud = new CrudCurtidas();
            $rlt = $crud->DeleteCurtida($idano, $iduser);
            break;

        case 'teste':
            $id = $_POST['id'];
            $iduser = $_SESSION['id'];
            $crud = new CrudCurtidas();
            $comprovar = $crud->VerificaCurtida($id, $iduser);
            $count = $comprovar['COUNT(idcurtida)'];

            if($count == 0){
                $crud->InsertCurtida($id, $iduser);
            }
            else{
                $crud->DeleteCurtida($id, $iduser);
            }

            $contar = $crud->NCurtidas($id);
            $cont = $contar['COUNT(idcurtida)'];

            if($count >=1){$gostou = 'Gostei'; $cont = $cont++;}else{$gostou = 'Não Gostei'; $cont = $cont--;}

            $dados = array('likes' =>$cont, 'text' =>$gostou);
            echo json_encode($dados);
            break;


    }
?>
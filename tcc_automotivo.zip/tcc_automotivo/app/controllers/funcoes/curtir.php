<?php

    session_start();
    require_once "../../models/DBConexao.php";
    require_once "../../models/CrudCurtidas.php";
    $idano = $_GET['idano'];
    $iduser = $_SESSION['id'];
    $crud = new CrudCurtidas();
    $acao = $_GET['state'];
    switch ($acao){
        case 'not':
            $rlt = $crud->InsertCurtida($idano, $iduser);
            break;

        case 'yes':
            $rlt = $crud->DeleteCurtida($idano, $iduser);
            break;
    }
?>
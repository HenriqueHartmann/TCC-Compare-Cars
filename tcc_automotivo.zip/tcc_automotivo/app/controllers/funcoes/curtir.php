<?php

    session_start();
    require_once "../../models/DBConexao.php";
    require_once "../../models/CrudCurtidas.php";
    $acao = $_GET['state'];
    switch ($acao) {


        case 'qtdcurtida':
            $idano = $_GET['idano'];
            $crud = new CrudCurtidas();
            $rlt = $crud->NCurtidas($idano);
            echo $rlt['COUNT(idcurtida)'];
            break;

        case 'verifica':
            $idano = $_GET['idano'];
            $iduser = $_SESSION['id'];
            $crud = new CrudCurtidas();
            $rlt = $crud->VerificaCurtida($idano, $iduser);
            echo $rlt['COUNT(idcurtida)'];
            break;

        case 'not':
            $idano = $_GET['idano'];
            $iduser = $_SESSION['id'];
            $crud = new CrudCurtidas();
            $rlt = $crud->InsertCurtida($idano, $iduser);
            break;

        case 'yes':
            $idano = $_GET['idano'];
            $iduser = $_SESSION['id'];
            $crud = new CrudCurtidas();
            $rlt = $crud->DeleteCurtida($idano, $iduser);
            break;


    }
?>
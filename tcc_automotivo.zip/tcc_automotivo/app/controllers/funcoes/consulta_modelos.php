<?php

    require_once "../../models/CrudModelo.php";
    require_once "../../models/DBConexao.php";

    $id_montadora = $_GET['idmontadora'];
    $crud = new CrudModelo();
    $modelos = $crud->getModelosPelaMontadora($id_montadora);
    header('Content-Type: application/json');
    echo json_encode($modelos);
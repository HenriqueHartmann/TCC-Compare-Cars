<?php

    session_start();
    require_once "../../models/DBConexao.php";
    require_once "../../models/CrudCurtidas.php";
    $idano = $_GET['idano'];
    $iduser = $_SESSION['id'];
    $crud = new CrudCurtidas();
    $rlt = $crud->VerificaCurtida($idano, $iduser);
    echo $rlt['COUNT(idcurtida)'];
?>
<?php
    require_once "../models/CrudMontadora.php";
    require_once "../models/DBConexao.php";

    function bla()
    {
        $crud = new CrudMontadora();
        $monts = $crud->getMontName();
        $data = json_encode($monts);
        return $data;
    }
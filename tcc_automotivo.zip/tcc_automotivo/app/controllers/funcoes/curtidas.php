<?php

    require_once "../../models/DBConexao.php";
    require_once "../../models/CrudModelo.php";
    require_once "../../models/CrudCurtidas.php";
    $id = $_POST['id'];
    $crud = new CrudCurtidas();
    $rlt = $crud->NCurtidas($id);
    header('Content-Type: application/json');
    echo json_encode($rlt);
//    print_r($olha);
?>
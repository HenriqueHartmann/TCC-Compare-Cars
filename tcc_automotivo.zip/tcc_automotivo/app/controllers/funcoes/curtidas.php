<?php

    require_once "../../models/DBConexao.php";
    require_once "../../models/CrudCurtidas.php";
    $id = $_GET['id'];
    $crud = new CrudCurtidas();
    $rlt = $crud->NCurtidas($id);
    echo $rlt['COUNT(idcurtida)'];
//    print_r($rlt);
?>
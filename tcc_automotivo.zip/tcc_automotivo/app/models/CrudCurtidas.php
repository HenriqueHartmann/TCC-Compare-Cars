<?php

require_once "DBConexao.php";
require_once "Curtida.php";

class CrudCurtidas
{

    private $conexao;

    public function __construct(){
        $this->conexao = DBConexao::getConexao();
    }

    public function NCurtidas($idmodelano){
        $sql = "SELECT count(idcurtida) FROM curtida, modelo_ano WHERE modelo_ano_idmodelo_ano = idmodelo_ano AND modelo_ano_idmodelo_ano =".$idmodelano;
        $result = $this->conexao->query($sql);
        $curtida = $result->fetch(PDO::FETCH_ASSOC);
        $objCurtida = new Curtida($curtida['idcurtida'], $curtida['modelo_ano_idmodelo_ano'], $curtida['usuario_idusuario']);
        return $objCurtida;
    }
}
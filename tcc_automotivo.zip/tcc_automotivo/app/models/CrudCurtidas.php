<?php

    require_once "DBConexao.php";
    require_once "Curtida.php";

class CrudCurtidas
{

    private $conexao;

    public function __construct(){
        $this->conexao = DBConexao::getConexao();
    }

    public function NCurtidas($idano){
        $sql = "SELECT COUNT(idcurtida) 
                FROM curtida 
                WHERE modelo_ano_idmodelo_ano =".$idano;
        $result = $this->conexao->query($sql);
        $curtida = $result->fetch(PDO::FETCH_ASSOC);
        return $curtida;
    }

    public function InsertCurtida($idano, $iduser){
        $sql = "INSERT 
                INTO curtida (modelo_ano_idmodelo_ano, usuario_idusuario) 
                VALUES ('{$idano}','{$iduser}')";
        try {
            $this->conexao->exec($sql);
        } catch (PDOException $e) {
            return $e->getMessage();
        }
    }

    public function DeleteCurtida($idano, $iduser){
        $sql = "DELETE 
                FROM curtida 
                WHERE modelo_ano_idmodelo_ano = '{$idano}' AND usuario_idusuario = '{$iduser}'";
        try {
            $this->conexao->exec($sql);
        } catch (PDOException $e) {
            return $e->getMessage();
        }
    }

    public function VerificaCurtida($idano, $iduser){
        $sql = "SELECT COUNT(idcurtida) 
                FROM curtida 
                WHERE modelo_ano_idmodelo_ano = '{$idano}' AND usuario_idusuario = '{$iduser}'";
        $result = $this->conexao->query($sql);
        $curtida = $result->fetch(PDO::FETCH_ASSOC);
        return $curtida;
    }

    public function Ranking() {
        $sql = "SELECT DISTINCT 
                (SELECT COUNT(idcurtida) FROM curtida WHERE modelo_ano_idmodelo_ano = idmodelo_ano) AS qtd
                , modelo_ano_idmodelo_ano, montadora, nome_modelo, ano
                FROM curtida
                INNER JOIN modelo_ano ON curtida.modelo_ano_idmodelo_ano = modelo_ano.idmodelo_ano
                INNER JOIN modelo ON modelo_ano.modelo_idmodelo = modelo.idmodelo
                INNER JOIN montadora ON modelo.montadora_idmontadora =  montadora.idmontadora
                ORDER BY qtd DESC LIMIT 5";
        $resultado = $this->conexao->query($sql);
        $ranking = $resultado->fetchAll(PDO::FETCH_ASSOC);
        return $ranking;
    }

    public function Favoritos($iduser){
        $sql = "SELECT modelo_ano_idmodelo FROM `curtida` WHERE usuario_idusuario = '{$iduser}'";
        $resultado = $this->conexao->query($sql);
        $favoritos = $resultado->fetchAll(PDO::FETCH_ASSOC);
        return $favoritos;
    }

    public function DetalhesCurtida($idano){
        $sql = "SELECT modelo_ano_idmodelo_ano, montadora, nome_modelo, ano
                FROM curtida
                INNER JOIN modelo_ano ON curtida.modelo_ano_idmodelo_ano = modelo_ano.idmodelo_ano
                INNER JOIN modelo ON modelo_ano.modelo_idmodelo = modelo.idmodelo
                INNER JOIN montadora ON modelo.montadora_idmontadora =  montadora.idmontadora
                WHERE modelo_ano_idmodelo_ano = '{$idano}'";
        $resultado = $this->conexao->query($sql);
        $detail = $resultado->fetch(PDO::FETCH_ASSOC);
        return $detail;
    }
}
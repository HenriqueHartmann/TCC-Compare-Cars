<?php

require_once "DBConexao.php";
require_once "Curtida.php";

class CrudCurtidas
{

    private $conexao;

    public function __construct(){
        $this->conexao = DBConexao::getConexao();
    }

    public function NCurtidas($idano){
        $sql = "SELECT COUNT(idcurtida) FROM curtida WHERE modelo_ano_idmodelo_ano =".$idano;
        $result = $this->conexao->query($sql);
        $curtida = $result->fetch(PDO::FETCH_ASSOC);
        return $curtida;
    }

    public function InsertCurtida($idano, $iduser){
        $sql = "INSERT INTO curtida (modelo_ano_idmodelo_ano, usuario_idusuario) VALUES ('{$idano}','{$iduser}')";
        try {
            $this->conexao->exec($sql);
        } catch (PDOException $e) {
            return $e->getMessage();
        }
    }

    public function DeleteCurtida($idano, $iduser){
        $sql = "DELETE FROM curtida WHERE modelo_ano_idmodelo_ano = '{$idano}' AND usuario_idusuario = '{$iduser}'";
        try {
            $this->conexao->exec($sql);
        } catch (PDOException $e) {
            return $e->getMessage();
        }
    }

    public function VerificaCurtida($idano, $iduser){
        $sql = "SELECT COUNT(idcurtida) FROM curtida WHERE modelo_ano_idmodelo_ano = '{$idano}' AND usuario_idusuario = '{$iduser}'";
        $result = $this->conexao->query($sql);
        $curtida = $result->fetch(PDO::FETCH_ASSOC);
        return $curtida;
    }
}
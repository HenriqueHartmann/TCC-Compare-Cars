<?php
/**
 * Created by PhpStorm.
 * User: aluno
 * Date: 25/10/18
 * Time: 17:15
 */

    require_once "DBConexao.php";
    require_once "Curtida.php";

class CrudCurtidas
{

    private $conexao;

    public function __construct(){
        $this->conexao = DBConexao::getConexao();
    }

}
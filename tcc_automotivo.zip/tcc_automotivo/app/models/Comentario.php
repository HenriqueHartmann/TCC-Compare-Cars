<?php

class Comentario
{
    private $idcomentario;
    private $texto;
    private $data;
    private $pendente;
    private $usuario_idusuario;

    public function __construct($idcomentario = null, $texto = null, $data = null, $pendente = null, $usuario_idusuario = null)
    {
        $this->idcomentario = $idcomentario;
        $this->texto = $texto;
        $this->data = $data;
        $this->pendente = $pendente;
        $this->usuario_idusuario = $usuario_idusuario;
    }

    /**
     * @return null
     */
    public function getIdcomentario()
    {
        return $this->idcomentario;
    }

    /**
     * @param null $idcomentario
     */
    public function setIdcomentario($idcomentario)
    {
        $this->idcomentario = $idcomentario;
    }

    /**
     * @return mixed
     */
    public function getTexto()
    {
        return $this->texto;
    }

    /**
     * @param mixed $texto
     */
    public function setTexto($texto)
    {
        $this->texto = $texto;
    }

    /**
     * @return mixed
     */
    public function getData()
    {
        return $this->data;
    }

    /**
     * @param mixed $data
     */
    public function setData($data)
    {
        $this->data = $data;
    }

    /**
     * @return mixed
     */
    public function getPendente()
    {
        return $this->pendente;
    }

    /**
     * @param mixed $pendente
     */
    public function setPendente($pendente): void
    {
        $this->pendente = $pendente;
    }

    /**
     * @return mixed
     */
    public function getUsuarioIdusuario()
    {
        return $this->usuario_idusuario;
    }

    /**
     * @param mixed $usuario_idusuario
     */
    public function setUsuarioIdusuario($usuario_idusuario)
    {
        $this->usuario_idusuario = $usuario_idusuario;
    }

}
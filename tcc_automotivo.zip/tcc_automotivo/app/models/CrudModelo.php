<?php

    require_once "DBConexao.php";
    require_once "Modelo.php";

class CrudModelo
{
    private $conexao;

    public function __construct(){
        $this->conexao = DBConexao::getConexao();
    }

    public function getModelo($idmodelo){
        $sql = "SELECT * FROM modelo WHERE idmodelo = '{$idmodelo}'";
        $resultado = $this->conexao->query($sql);
        $modelo = $resultado->fetch(PDO::FETCH_ASSOC);
        $idmod = $modelo['idmodelo'];
        $nomemod = $modelo['nome_modelo'];
        $idmontmod = $modelo['montadora_idmontadora'];
        $objMod = new Modelo($idmod, $nomemod, $idmontmod);
        return $objMod;
    }

    public function getModelos(){
        $sql = "SELECT * FROM modelo";
        $resultado = $this->conexao->query($sql);
        $modelos = $resultado->fetchAll(PDO::FETCH_ASSOC);
        foreach ($modelos as $modelo) {
            $idmodelo = $modelo['idmodelo'];
            $nomemodelo = $modelo['nome_modelo'];
            $montadora_idmontadora = $modelo['montadora_idmontadora'];
            $obj = new Modelo($idmodelo, $nomemodelo, $montadora_idmontadora);
            $listaModelos[] = $obj;
        }
        return $listaModelos;
    }

    public function getModelName(){
        $sql = "SELECT * FROM modelo";
        $resultado = $this->conexao->query($sql);
        $modelos = $resultado->fetchAll(PDO::FETCH_ASSOC);
        return $modelos;
    }

//    public function getModelId($nome){
//        $sql = "SELECT idmodelo FROM modelo WHERE nome_modelo = '{$nome}'";
//        $resultado = $this->conexao->query($sql);
//        $idmodelo = $resultado->fetch(PDO::FETCH_ASSOC);
//        return $idmodelo;
//    }

    public function insertModelo(Modelo $modelo){

        $this->conexao = DBConexao::getConexao();

        $sql = "INSERT INTO `modelo`(`idmodelo`, `nome_modelo`, `montadora_idmontadora`) VALUES (null, '{$modelo->getNomemodelo()}', {$modelo->getMontadoraIdmontadora()})";
        try{
            $this->conexao->exec($sql);
        }catch (PDOException $e){
            return $e->getMessage();
        }
    }

    public function updateModelo(Modelo $modelo, $id){

        $sql = "UPDATE modelo SET idmodelo ='{$modelo->getIdmodelo()}', nome_modelo ='{$modelo->getNomemodelo()}', montadora_idmontadora ='{$modelo->getMontadoraIdmontadora()}' WHERE idmodelo=".$id;
        try{
            $this->conexao->exec($sql);
        }catch (PDOException $e){
            return $e->getMessage();
        }
    }

    public function  deleteModelo($id){
        $sql = "DELETE FROM modelo WHERE idmodelo =".$id;
        try{
            $this->conexao->exec($sql);
        }catch (PDOException $e){
            return $e->getMessage();
        }

    }

////SPERONI - criei função para buscar os anos de um modelo
    public function getAnosPorModelo($id_modelo){
        $sql = "SELECT idmodelo_ano, ano FROM modelo_ano where modelo_idmodelo = ".$id_modelo;
        $resultado = $this->conexao->query($sql);
        $modelos = $resultado->fetchAll(PDO::FETCH_ASSOC);
        return $modelos;
    }

//André - criei função para buscar os modelos de uma marca
    public function getModelosPorMontadora(Montadora $id_montadora){//ANDRE-BUSCA
        $sql = "SELECT * FROM modelo WHERE montadora_idmontadora = '{$id_montadora->getIdMontadora()}' ORDER BY FIELD(idmodelo,7456,5724,6174,7456,7659,6431,7184,1115,5637,840,839,6164,6693,6171,7187,7190,7191,7760,7762,5455,7185,6936,6937,7173,6940,6278,6600,6602) desc, idmodelo";
        $resultado = $this->conexao->query($sql);
        $modelos = $resultado->fetchAll(PDO::FETCH_ASSOC);
        foreach ($modelos as $modelo) {
            $idmodelo = $modelo['idmodelo'];
            $nomemodelo = $modelo['nome_modelo'];
            $montadora_idmontadora = $modelo['montadora_idmontadora'];
            $obj = new Modelo($idmodelo, $nomemodelo, $montadora_idmontadora);
            $listaModelos[] = $obj;
        }
        return $listaModelos;
        }
    public function getModelosPelaMontadora($id_montadora){//SPERONI-SELECT
        $sql = "SELECT * FROM modelo WHERE montadora_idmontadora = '{$id_montadora}' ORDER BY FIELD(idmodelo,7456,5724,6174,7456,7659,6431,7184,1115,5637,840,839,6164,6693,6171,7187,7190,7191,7760,7762,5455,7185,6936,6937,7173,6940,6278,6600,6602) desc, idmodelo";
        $resultado = $this->conexao->query($sql);
        $modelos = $resultado->fetchAll(PDO::FETCH_ASSOC);
        return $modelos;
    }
}
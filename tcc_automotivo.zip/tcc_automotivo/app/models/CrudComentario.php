<?php

    require_once 'DBConexao.php';
    require_once 'Comentario.php';

class CrudComentario
{
    private $conexao;

    public function __construct(){
        $this->conexao = DBConexao::getConexao();
    }

    public function getComentariopend($id){
        $sql = "SELECT * FROM comentario WHERE idcomentario= '{$id}' and pendente= 1";
        $result = $this->conexao->query($sql);
        $coment = $result->fetch(PDO::FETCH_ASSOC);
        $objcoment = new Comentario($coment['idcomentario'], $coment['texto'], $coment['data'], $coment['pendente'], $coment['usuario_idusuario']);
        return $objcoment;
    }

    public function getComentariospend(){
        $sql = "SELECT * FROM comentario WHERE pendente= 1";
        $result = $this->conexao->query($sql);
        $comentarios = $result->fetchAll(PDO::FETCH_ASSOC);
        $tamanho = count($comentarios);
        if($tamanho == 0){
            $array = [ '1', 'sem comentários', '09/11/2018', '1', '1'];
            $obj = new Comentario($array[0], $array[1], $array[2], $array[3], $array[4]);
            $listacomentarios[] = $obj;
        }
        else {

            foreach ($comentarios as $comentario) {
                $idcoment = $comentario['idcomentario'];
                $texto = $comentario['texto'];
                $data = $comentario['data'];
                $pend = $comentario['pendente'];
                $iduser = $comentario['usuario_idusuario'];
                $obj = new Comentario($idcoment, $texto, $data, $pend, $iduser);
                $listacomentarios[] = $obj;
            }
        }
        return $listacomentarios;
    }

    public function getComentario($id){
        $sql = "SELECT * FROM comentario WHERE idcomentario= '{$id}' and pendente= 2";
        $result = $this->conexao->query($sql);
        $coment = $result->fetch(PDO::FETCH_ASSOC);
        $objcoment = new Comentario($coment['idcomentario'], $coment['texto'], $coment['data'], $coment['pendente'], $coment['usuario_idusuario']);
        return $objcoment;
    }

    public function getComentarios(){
        $sql = "SELECT * FROM comentario WHERE pendente= 2";
        $result = $this->conexao->query($sql);
        $comentarios = $result->fetchAll(PDO::FETCH_ASSOC);
        $tamanho = count($comentarios);
        if($tamanho == 0){
            $array = [ '1', 'sem comentários', '09/11/2018', '2', '1'];
            $obj = new Comentario($array[0], $array[1], $array[2], $array[3], $array[4]);
            $listacomentarios[] = $obj;
        }
        foreach ($comentarios as $comentario){
            $idcoment = $comentario['idcomentario'];
            $texto = $comentario['texto'];
            $data = $comentario['data'];
            $pend = $comentario['pendente'];
            $iduser = $comentario['usuario_idusuario'];
            $obj = new Comentario($idcoment, $texto, $data, $pend, $iduser);
            $listacomentarios[] = $obj;

        }
        return $listacomentarios;
    }

    public function getUsuarioEmail($id){
        $sql = "SELECT email FROM usuario WHERE idusuario =".$id;
        $result = $this->conexao->query($sql)->fetch(PDO::FETCH_ASSOC);
            $autor = $result['email'];
            $obj = new Usuario(null,null,$autor,null,$id);
        return $obj->getEmail();

    }

    public function insertComentario(Comentario $comentario){
        $sql = "INSERT INTO comentario (texto, pendente, usuario_idusuario) VALUES ('{$comentario->getTexto()}', '{$comentario->getPendente()}', '{$comentario->getUsuarioIdusuario()}')";
        try{
            $this->conexao->exec($sql);
        }catch (PDOException $e){
            return $e->getMessage();
        }
    }

    public function ativarComentario($id){
        $sql = "UPDATE comentario SET pendente= 2 WHERE idcomentario=".$id;
        try{
            $this->conexao->exec($sql);
        }catch (PDOException $e){
            return $e->getMessage();
        }
    }

    public function deleteComentario($id){
        $sql = "DELETE FROM comentario WHERE idcomentario=".$id;
        try{
            $this->conexao->exec($sql);
        }catch (PDOException $e){
            return $e->getMessage();
        }
    }

    public function verificaComentario(Comentario $comentario){
        if (strlen($comentario->getNome()) >=5 && strlen($comentario->getNome()) <= 50){
            if (strlen($comentario->setTexto()) >=1 && strlen($comentario->getTexto()) <=500){
                return $this->getComentario($comentario);
            }else{
                return false;
            }
        }else{
            return false;
        }
    }

}
$(document).ready(function () {

    if ($(window).width() > 768 && $(window).width() <= 1024){

        $('.divImg').attr('style','margin-bottom: 40px; height: 500px');
        $('#imagemCarros').attr('style','width: 100%; height: 600px');
    }

    else if ($(window).width() > 1024 && $(window).width() < 1440){

        $('.divImg').attr('style','margin-bottom: 40px; height: 600px');
        $('#imagemCarros').attr('style','width: 100%; height: 700px');
    }

    else if ($(window).width() >= 1440){
        $('.divImg').attr('style','margin-bottom: 15px; height: 700px');
        $('#imagemCarros').attr('style','width: 100%; height: 800px');
    }



    $(window).resize(function () {
        if ($(window).width() > 768 && $(window).width() <= 1024){

            $('.divImg').attr('style','margin-bottom: 40px; height: 500px');
            $('#imagemCarros').attr('style','width: 100%; height: 600px');
        }

        else if ($(window).width() > 1024 && $(window).width() < 1440){

            $('.divImg').attr('style','margin-bottom: 40px; height: 600px');
            $('#imagemCarros').attr('style','width: 100%; height: 700px');
        }

        else if ($(window).width() >= 1440){
            $('.divImg').attr('style','margin-bottom: 15px; height: 700px');
            $('#imagemCarros').attr('style','width: 100%; height: 800px');
        }

        else {
            $('#imagemCarros').attr("style", " ");
            $('.divImg').attr("style", " ");
        }

    });

});
$(document).ready(function () {
    $("#coment").click(function () {
        alert("Seu comentario será ativado pelo o adminstrador!");
    });
});
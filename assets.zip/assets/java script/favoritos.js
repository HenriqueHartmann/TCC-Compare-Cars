$(document).ready(function () {
    favoritos();
});


function favoritos() {
    $.ajax({
            url:'../views/Comparacao/linhacurtir.php',
            type:'POST',
            data:'page:favoritos',

            success: function (data) {
                $(".reload").html(data);
            }
        }
    );
}
$(document).ready(function () {
    favoritos();
});

function desfavoritar() {
    $.ajax({
        url:'../views/Comparacao/linhacurtir.php',
        type:'POST',
        data:{page:'favoritos'},

        success: function (data) {
            $(".reload-fav").html(data);
            $(".like").click(function () {
                var id = this.id;
                $.ajax({
                    url:'funcoes/curtir.php',
                    type:'POST',
                    data:{id:id},
                    datatype:'json',

                    success:function(data){
                        desfavoritar();
                    }
                });
            });
        }
    });
}

function favoritos() {
    $.ajax({
            url:'../views/Comparacao/linhacurtir.php',
            type:'POST',
            data:{page:'favoritos'},

            success: function (data) {
                $(".reload-fav").html(data);
                $(".like").click(function () {
                    var id = this.id;
                    $.ajax({
                        url:'funcoes/curtir.php',
                        type:'POST',
                        data:{id:id},
                        datatype:'json',

                        success:function(data){
                            desfavoritar();
                        }
                    });
                });
            }
        });
        setTimeout('favoritos()', 5000);
}
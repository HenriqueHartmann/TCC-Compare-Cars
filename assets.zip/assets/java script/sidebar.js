//sidebar//
$(document).ready(function () {
    $('.ui.sidebar').sidebar('attach events','.toc.item');
});
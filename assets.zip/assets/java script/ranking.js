$(document).ready(function (){
    atualiza();
});


function atualiza() {
    $.ajax({
       url:'../views/Comparacao/linhacurtir.php',
        type:'POST',
        data:{page:'ranking'},

        success: function (data) {
            $(".reload-rank").html(data);
        }
    });
    setTimeout('atualiza()', 5000);
}
$(document).ready(function (){
    atualiza();
});


function atualiza() {
    $.ajax({
       url:'../views/Comparacao/linhacurtir.php',
        type:'POST',
        data:{page:'ranking'},

        success: function (data) {
            $(".reload").html(data);
        }
    });
    setTimeout('atualiza()', 10000);
}
$(document).ready(function () {
    // $(".tabela1").hide();
    var id = $("#carro1").text();
    function num() {
        $.get("funcoes/curtidas.php", {id: id}, function (data) {
            $(".qtdcurtida1").text(data);
        });
    }
    function curtiu() {
        return $.get("funcoes/verificacurtidas.php", {idano: id}, function (data) {
        });
    }
    curtiu();
    num();
    if(curtiu() == 0){
        $("#but1").addClass('green');
        $(".curtir1").click(function () {
            $.get("funcoes/curtir.php", {idano: id, state: 'not'}, function (data) {
                curtiu();
                num();
                // $(".reload").load("../views/Comparacao/curtir2.php");
            });
        });
    }else if(curtiu() == 1){
        $("#but1").addClass('red');
        $(".curtir1").click(function () {
            $.get("funcoes/curtir.php", {idano: id, state: 'yes'}, function (data) {
                curtiu();
                num();
                // $(".reload").load("../views/Comparacao/curtir2.php");
            });
        });
    }
});
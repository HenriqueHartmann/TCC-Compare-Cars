$(document).ready(function (){
    atualiza();
});


function atualizaagora(){
    var idveiculo1 = $("#carro1").text();
    var idveiculo2 = $("#carro2").text();
    var idveiculo3 = $("#carro3").text();
    var idveiculo4 = $("#carro4").text();
    var url_atual = window.location.href;
    var parametroDaUrl = url_atual.split("=")[1];
    $.ajax({
        url:'../views/Comparacao/linhacurtir.php',
        type:'POST',
        data:{idveiculo1:idveiculo1,idveiculo2:idveiculo2,idveiculo3:idveiculo3,idveiculo4:idveiculo4,state:parametroDaUrl,page:'curtidas'},

        success: function (data) {
            $(".reload-curt").html(data);
            $(".like").click(function () {
                var id = this.id;
                $.ajax({
                    url:'funcoes/curtir.php',
                    type:'POST',
                    data:{id:id},
                    datatype:'json',

                    success:function(data){
                        var likes = data['likes'];
                        var text  = data['text'];

                        $("#likes_"+id).text(likes);
                        $("#likes_"+id).html(text);

                        atualizaagora();
                    }
                });
            });
        }
    });
}


function atualiza() {
    var idveiculo1 = $("#carro1").text();
    var idveiculo2 = $("#carro2").text();
    var idveiculo3 = $("#carro3").text();
    var idveiculo4 = $("#carro4").text();
    var url_atual = window.location.href;
    var parametroDaUrl = url_atual.split("=")[1];
    $.ajax({
        url:'../views/Comparacao/linhacurtir.php',
        type:'POST',
        data:{idveiculo1:idveiculo1,idveiculo2:idveiculo2,idveiculo3:idveiculo3,idveiculo4:idveiculo4,state:parametroDaUrl,page:'curtidas'},

        success: function (data) {
                $(".reload-curt").html(data);
                $(".like").click(function () {
                    var id = this.id;
                    $.ajax({
                        url:'funcoes/curtir.php',
                        type:'POST',
                        data:{id:id},
                        datatype:'json',

                        success:function(data){
                            var likes = data['likes'];
                            var text  = data['text'];

                            $("#likes_"+id).text(likes);
                            $("#likes_"+id).html(text);

                            atualizaagora();
                        }
                    });
                });
        }
    });
    setTimeout('atualiza()', 5000);
}
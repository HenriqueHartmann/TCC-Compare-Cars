$(document).ready(function () {
    // $(".tabela1").hide();

    function num() {
        var id = $("#carro1").text();
        $.get("funcoes/curtir.php", {idano: id, state: 'qtdcurtida'}, function (data) {
            $(".qtdcurtida1").text(data);
        });
    }

    function curti() {
        var id = $("#carro1").text();
        var obj;
        $.get("funcoes/curtir.php", {idano: id, state: 'verifica'}, function (data) {
            obj = JSON.parse(data);
            alert(obj);
            $("#opa1").text(obj);
            // $("#opa1").hide();
        });

    }


    num();
    curti();
    var rlt = $("#opa1").text();
    alert(rlt);
    if(rlt == 0){
        $("#but1").removeClass('red');
        $("#but1").addClass('green');
        $(".curtir1").click(function () {
            var id = $("#carro1").text();
            $.get("funcoes/curtir.php", {idano: id, state: 'not'}, function (data) {
                num();
                curti();

            });
        });
    }else if(rlt != 0){
        $("#but1").removeClass('green');
        $("#but1").addClass('red');
        $(".curtir1").click(function () {
            var id = $("#carro1").text();
            $.get("funcoes/curtir.php", {idano: id, state: 'yes'}, function (data) {
                num();
                curti();

            });
        });
    }


});
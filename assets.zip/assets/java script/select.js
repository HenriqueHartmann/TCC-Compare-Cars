$(function(){
    $(".carregando").hide();
    $(".select-marca").change(function () {
        if ($(this).val()){
            var elemPai = $(this).parent();
            elemPai.find(".select-modelo").hide();
            elemPai.find(".carregando").show();
            //SPERONI - alterado para chamar o consulta_modelos.php passando o id da mmontadora
            $.getJSON('funcoes/consulta_modelos.php?idmontadora='+$(this).val(), function(j){ // estou tentando selecionar os meu arquivos modelos(id da montadora).json, mas ele somente esconde o select-modelo//
                var options = '<option value="">Selecione...</option>';
                for (var i = 0; i < j.length; i++) {
                    options += '<option value="' +
                        j[i].idmodelo + '">' +
                        j[i].nome_modelo + '</option>';
                }
                elemPai.find(".select-modelo").html(options);
                elemPai.find(".select-modelo").show();
                elemPai.find(".carregando").hide();
            });

        }else {
            $('.select-modelo').html(
                '<option value="">-- Escolha uma montadora --</option>'
            );
        }
    });

    $('.select-modelo').change(function(){
        if( $(this).val() ) {
            var elemPai = $(this).parent();
            var marca = elemPai.find('.select-marca').val();
            elemPai.find('.select-ano').hide();
            elemPai.find('.carregando').show();
            //SPERONI - alterado para chamar um arquivo PHP que faz a consulta por anos, a partir de um id_modelo
            $.getJSON('funcoes/consulta_anos.php?idmodelo='+$(this).val(), function(j){
                var options = '<option value="">Selecione...</option>';
                for (var i = 0; i < j.length; i++) {
                    options += '<option value="' +
                        j[i].ano + '">' +
                        j[i].ano + '</option>';
                }
                elemPai.find('.select-ano').html(options).show();
                elemPai.find('.carregando').hide();
            });
        } else {
            $('.select-ano').html(
                '<option value="">-- Escolha um modelo --</option>'
            );
        }
    });
// SPERONI - criada função de teste para exibir os detalhes quando escolhe um ano

    // $('.select-ano').change(function(){
    //     if( $(this).val() ) {
    //         elemPai = $(this).parent();
    //         elemPai.find('.carregando').show();
    //         //SPERONI - alterado para chamar um arquivo PHP que faz a consulta por anos, a partir de um id_modelo
    //         $.getJSON(
    //             'funcoes/consulta_detalhes.php?idveiculo='+$(this).val(), function(carro){
    //                 var detalhes = '<ul>';
    //                 detalhes += '<li> Potência: '+carro.potencia+'</li>';
    //                 detalhes += '<li> Portas: '+carro.portas+'</li>';
    //                 detalhes += '<li> Preço: '+carro.preco+'</li>';
    //                 //aqui é possível usar todos os demais atributos
    //                 elemPai.find('.carregando').hide();
    //                 $('#detalhes-carro').html(detalhes);
    //             });
    //     } else {
    //         $('#detalhes-carro').html(
    //             '<p>Nenhum detalhe...</p>'
    //         );
    //     }
    // });




    $('#ano').change(function(){

        if ($(this).val() !== "Selecione o Ano:" && $('#ano1').val() !== "Selecione o Ano:"){
            $("#comparar_coches").prop('disabled', false);
        }
    });

    $('#ano1').change(function(){

        if ($(this).val() !== "Selecione o Ano:" && $('#ano').val() !== "Selecione o Ano:"){
            $("#comparar_coches").prop('disabled', false);
        }
    });

});